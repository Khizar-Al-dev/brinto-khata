# Brinto Khata — Android Code (LOCAL-ONLY variant)

Bhai, ye **Brinto Khata** ka poora Android code hai — Brinto Washing Powder ke wholesalers ka khata / ledger app.

> **⚠️ LOCAL-ONLY VARIANT — saaf baat pehle:**
> Is variant mein **Firebase NAHI hai** (is liye koi google-services.json nahi chahiye).
> - Login / users sirf **is phone par** save hote hain (password hash ke saath).
> - Customers, stock aur udhaar ka data sirf **is phone par** hai (Room database).
> - **App delete ho jaye to data khatam ho jayega** — wapas nahi aayega.
> - **Cloud / Gmail sync NAHI hai.** Agar data Gmail login se wapas chahiye to asal Firebase wala project (`brinto-khata-android`, original) use karein aur Firebase setup karein (uske README mein steps hain).
>
> Ye variant is liye banaya gaya kyunki is phone/server par koi asal Firebase project nahi tha aur google-services.json ke baghair original project ka APK build nahi hota. Baqi saari features (login, admin, customer form, stock, udhaar, search) is mein waisi hi hain.

## Ye app kya karti hai

- **Login compulsory hai:** Email (Gmail) + password se Sign Up / Login. Password aap khud chunte hain.
- **Sirf khizaralam243@gmail.com Admin hai.** Baqi har account user hota hai. Admin user accounts bana sakta hai (Admin screen > Users).
- **Customer add karein:** Name, Location, Phone (optional), Dozens purchased, Amount Paid. 1 dozen = 12 packets; 3 likhne par 3 dozen = 36 packets ka hisaab hota hai.
- **Analytics All Time:** Custom date range ki jagah ab "All Time" hai — aik tap par start se aaj tak ki poori sales (Total Sale, Profit, Udhaar, Dozens, KG, Orders) dikhti hai. Koi date likhne ya chunne ki zaroorat nahi.
- **Total aur Remaining auto:** Total = dozens × price-per-dozen, Remaining = Total − Paid.
- **Stock auto-deduct:** Order add hote hi stock se dozens (x 12 packets) kam ho jate hain aur sale total mein add ho jata hai. Stock bhi dozens mein save hota hai.
- **Save ek baar:** Save dabate hi button band ho jata hai aur save hote hi screen khud band ho jati hai — dobara dabane se duplicate order nahi banta.
- **Udhaar section:** Jin customers ka Remaining > 0 hai, wo alag list mein dikhte hain.
- **Search:** Upar search bar — Name ya Location se search karein, type karte hi list filter hoti hai.
- **Customer detail (tap karein):** Kisi saved customer par tap karein to uski detail khulti hai — Saved on / Paid on dates aur baaki details dikhti hain.
- **Long-press Edit / Delete:** Customer card ko long-press karein to Edit order aur Delete customer dono options milte hain — Delete par Yes se delete, Cancel se safe.
- **Dates:** Har card ke neeche chhota sa "Saved: dd/MM/yyyy" likha hota hai. Detail mein Saved on aur Paid on dono dates dikhti hain.
- **History (hamburger menu):** Saved aur Deleted orders ki list, dates ke saath. Deleted customer bhi yahan dikhta hai — row par tap karein to purana order khul jata hai.
- **Profit per dozen:** Stock mein "Profit per dozen" set karein (pencil edit). Har order mein neeche "Profit in this order: Rs X" dikhta hai (X = packets / 12 × profit per dozen).
- **Data sirf is phone par hai:** is variant mein cloud sync NAHI hai. App delete ho jaye to data khatam ho jayega — Gmail se dobara login par wapas NAHI aayega.

## Logo

Logo file is project mein hai:
- `logo.jpg` — project root mein
- `app/src/main/res/drawable/brinto_logo.jpg` — login / splash / header mein use hota hai (`R.drawable.brinto_logo`)
- Dono files square centre crop hain (1014x1014, asal image se y 270–1284) taake "Brinto" word poora dikhe aur header mein sides empty na lagein.

## Firebase setup — IS VARIANT MEIN NAHI HAI

Is local-only variant mein Firebase NAHI hai, is liye google-services.json ki zaroorat nahi hai aur Firebase setup karne ki zaroorat nahi hai. Cloud sync chahiye to asal Firebase wala project (`brinto-khata-android`, original) use karein — uske README mein Firebase setup ke steps hain: Firebase Console par project banao, Android app `com.brinto.khata` add karo, `google-services.json` ko `app/` folder mein dalo, Email/Password auth aur Firestore ON karo.

## Android Studio mein kaise kholein

1. Computer par **Android Studio** install karein (free hai, developer.android.com/studio).
2. Is folder `brinto-khata-android` ko **zip se extract** karein.
3. Android Studio kholein → **Open** → `brinto-khata-android` folder chunein. Ya: **New Project → Empty Activity (Compose)**, naam `Brinto Khata`, package `com.brinto.khata`, Minimum SDK **API 26** — phir is project ki files us naye project mein copy kar dein (neeche file list dekhein).
4. **Gradle sync** karein (upar Sync Now). Pehli baar internet chahiye — Gradle dependencies download hongi. App chalane ke liye baad mein internet nahi chahiye (is variant mein cloud sync hai hi nahi).
5. Phone ko USB se connect karein (USB Debugging ON) ya emulator use karein → **Run ▶** dabayein.

## APK kaise banayein

1. Android Studio mein: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
2. APK yahan milegi: **`app/build/outputs/apk/debug/app-debug.apk`**
3. Us APK ko phone par install karein. Install karte waqt phone "Unknown sources / Play Protect" ka warning dega — **Install anyway** chunna parega, kyunki ye Play Store se nahi hai. Kaam ho jaye to Play Protect dobara **ON** kar dena.

## Test kaise karein (2 steps mein)

1. **Sign Up karein** apni Gmail + password se — khizaralam243@gmail.com se login par aap **Admin** hain, baqi har email user hota hai.
2. **Hamburger menu (upar left, three lines) → Stock** kholein → pencil (edit) icon par tap karein → Dozens in Stock likhein (e.g. 10 dozen = 120 packets) aur Price per dozen (12 packets) likhein (e.g. 600) → Save Stock.
3. **Home → + button → Add Customer:** Name, Location likhein, Dozens e.g. 2, Paid e.g. 500 likhein → Save.
   - Check karein: Total = 2 dozen × Rs 600 = Rs 1200, Remaining = 1200 − 500 = Rs 700.
   - Stock check karein: 10 − 2 = 8 dozen (96 packets) reh gaye, Total sale = Rs 1200.
4. **Udhaar** kholein — ye customer wahan dikhna chahiye (Remaining 700 > 0).
5. **Search** mein uska naam ya location type karein — list filter honi chahiye.
6. **Admin → Users** mein naya user banayein, phir us email se login karke check karein.

## File list — har feature kahan hai

| Feature | File | Function / Screen |
|---|---|---|
| Login / Sign Up (email + password) | `ui/screens/AuthScreen.kt` | `AuthScreen()` |
| Login compulsory, drawer + navigation | `MainActivity.kt` | `BrintoKhataAppContent()` |
| Admin sirf khizaralam243@gmail.com, user accounts | `data/FirestoreRepository.kt` | `signUp()`, `createUserByAdmin()`, `getAllUsers()` |
| Admin screen (users list, role, create user) | `ui/screens/AdminScreen.kt` | `AdminScreen()` |
| Customer form: Name, Location, Phone (optional), Packets, Paid | `ui/screens/AddCustomerScreen.kt` | `AddCustomerScreen()` |
| Total / Remaining auto | `ui/screens/AddCustomerScreen.kt` + `data/KhataRepository.kt` | `total = packets * unitPrice`, `remaining = total - paid` in `addCustomer()` |
| Price per dozen → per-packet, order price override | `data/Models.kt` (`StockSettings.pricePerPacket`) + `AddCustomerScreen.kt` (price field) | `pricePerPacket = pricePerDozen / 12` |
| Permissions (Camera, gallery) runtime | `ui/screens/AddCustomerScreen.kt` + `AndroidManifest.xml` | `requestCamera()`, `requestGallery()`, `RequestPermission()` |
| Cloud sync | IS VARIANT MEIN NAHI HAI — `data/FirestoreRepository.kt` mein cloud save/load no-op hain |
| Data survives app deletion | NAHI — app delete par data khatam ho jata hai |
| Local database (Room) — data ki asal jagah | `data/AppDatabase.kt`, `data/Models.kt` | `CustomerDao`, `StockDao`, `AppDatabase` |
| Hamburger menu (top-left, three lines) | `MainActivity.kt` | `ModalNavigationDrawer`, `HomeScreen` TopAppBar menu icon |
| Stock: packets + price per dozen, pencil edit | `ui/screens/StockScreen.kt` | `StockScreen()`, pencil `IconButton` → `editing` mode |
| Stock auto-deduct + sale total | `data/KhataRepository.kt` | `addCustomer()` — stock deduct, `totalPacketsSold`, `totalSalesAmount` |
| Customers list (home) | `ui/screens/HomeScreen.kt` | `HomeScreen()`, `CustomerCard()` |
| Search by Name / Location | `ui/screens/HomeScreen.kt` | search bar + `FilterChip` Name / Location, `filtered` list |
| Udhaar / Borrowed section | `ui/screens/UdhaarScreen.kt` | `UdhaarScreen()` — `remaining > 0` (`KhataRepository.udhaar`) |
| Logo | `app/src/main/res/drawable/brinto_logo.jpg`, `logo.jpg` | `AuthScreen`, `MainActivity` header — `R.drawable.brinto_logo` |
| App theme (blue/red, logo colours) | `ui/theme/Theme.kt` | `BrintoKhataTheme()` |
| Permissions in manifest | `app/src/main/AndroidManifest.xml` | CAMERA, READ_MEDIA_IMAGES, READ_EXTERNAL_STORAGE |

## Tech

Kotlin, Jetpack Compose, Material 3, minSdk 26, targetSdk 34, Room 2.6.1, Navigation Compose. Is variant mein Firebase NAHI hai. Bluetooth ki zaroorat nahi hai.

## Limits — dobara saaf lafzon mein

- Ye **code hai, ready APK nahi**. Yahan compile nahi hua (Android SDK nahi hai). APK Android Studio ya GitHub Actions mein banegi.
- **Cloud sync NAHI hai** — data sirf phone mein local rahega, app delete par khatam ho jayega. Cloud sync ke liye asal Firebase wala project use karein.
