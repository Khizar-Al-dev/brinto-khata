package com.brinto.khata.data

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest

/**
 * LOCAL-ONLY build variant (brinto-khata-android-local).
 *
 * Is variant mein Firebase NAHI hai — na Auth, na Firestore, na
 * google-services.json. Login / users sirf is phone par save hote
 * hain (SharedPreferences mein, password SHA-256 hash ke saath —
 * plain text mein nahi).
 *
 * Collections ki jagah local store:
 *   users  -> SharedPreferences "brinto_local_users"
 *   session -> SharedPreferences "brinto_local_session" (current uid)
 *
 * API bilkul waisi hi hai jaisi Firebase wale FirestoreRepository
 * ki thi, taake KhataRepository / KhataViewModel / screens mein
 * koi change na karna pare:
 *   signUp / signIn -> Result<LocalUser>
 *   getProfile / getAllUsers / setUserRole / createUserByAdmin
 *   saveCustomer / loadCustomers / saveStock / loadStock
 *     -> local mein ye no-op hain: Room hi source of truth hai.
 *
 * LIMIT: Data sirf is phone par hai. App delete ho jaye to data
 * khatam ho jayega. Cloud / Gmail sync ke liye asal Firebase
 * project aur google-services.json chahiye (original project
 * brinto-khata-android dekhein).
 */
data class LocalUser(val uid: String, val email: String)

class FirestoreRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("brinto_local_users", Context.MODE_PRIVATE)
    private val sessionPrefs: SharedPreferences =
        context.getSharedPreferences("brinto_local_session", Context.MODE_PRIVATE)

    private fun hash(password: String): String {
        val bytes = MessageDigest.getInstance("SHA-256")
            .digest(password.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun userKey(uid: String) = "user_$uid"

    private fun readUser(uid: String): UserProfile? {
        val raw = prefs.getString(userKey(uid), null) ?: return null
        // stored as: email|role|passwordHash
        val parts = raw.split("|")
        if (parts.size < 3) return null
        return UserProfile(uid = uid, email = parts[0], role = parts[1])
    }

    private fun readPasswordHash(uid: String): String? {
        val raw = prefs.getString(userKey(uid), null) ?: return null
        val parts = raw.split("|")
        return if (parts.size >= 3) parts[2] else null
    }

    private fun writeUser(profile: UserProfile, passwordHash: String) {
        prefs.edit()
            .putString(userKey(profile.uid), "${profile.email}|${profile.role}|$passwordHash")
            .apply()
    }

    private fun allUids(): List<String> =
        prefs.all.keys.filter { it.startsWith("user_") }.map { it.removePrefix("user_") }

    private fun findByEmail(email: String): UserProfile? =
        allUids().mapNotNull { readUser(it) }.firstOrNull { it.email.equals(email, ignoreCase = true) }

    val currentUser: LocalUser?
        get() {
            val uid = sessionPrefs.getString("current_uid", null) ?: return null
            val profile = readUser(uid) ?: return null
            return LocalUser(uid = profile.uid, email = profile.email)
        }

    suspend fun signUp(email: String, password: String): Result<LocalUser> = runCatching {
        val cleanEmail = email.trim()
        if (findByEmail(cleanEmail) != null) throw IllegalStateException("Is email se account pehle se hai")
        // First registered user becomes Admin, everyone after is a normal user.
        val role = if (allUids().isEmpty()) "admin" else "user"
        val uid = java.util.UUID.randomUUID().toString()
        writeUser(UserProfile(uid = uid, email = cleanEmail, role = role), hash(password))
        sessionPrefs.edit().putString("current_uid", uid).apply()
        LocalUser(uid = uid, email = cleanEmail)
    }

    suspend fun signIn(email: String, password: String): Result<LocalUser> = runCatching {
        val profile = findByEmail(email.trim())
            ?: throw IllegalStateException("Login failed — email / password check karein")
        if (readPasswordHash(profile.uid) != hash(password)) {
            throw IllegalStateException("Login failed — email / password check karein")
        }
        sessionPrefs.edit().putString("current_uid", profile.uid).apply()
        LocalUser(uid = profile.uid, email = profile.email)
    }

    fun signOut() {
        sessionPrefs.edit().remove("current_uid").apply()
    }

    suspend fun getProfile(uid: String): UserProfile? = readUser(uid)

    suspend fun getAllUsers(): List<UserProfile> =
        allUids().mapNotNull { readUser(it) }

    suspend fun setUserRole(uid: String, role: String) {
        val profile = readUser(uid) ?: return
        val passwordHash = readPasswordHash(uid) ?: return
        writeUser(profile.copy(role = role), passwordHash)
    }

    /** Admin creates / issues another user account (local only, admin stays signed in). */
    suspend fun createUserByAdmin(email: String, password: String): Result<Unit> = runCatching {
        val cleanEmail = email.trim()
        if (findByEmail(cleanEmail) != null) throw IllegalStateException("Is email se account pehle se hai")
        val uid = java.util.UUID.randomUUID().toString()
        writeUser(UserProfile(uid = uid, email = cleanEmail, role = "user"), hash(password))
    }

    // Cloud sync — local variant mein no-op: Room hi source of truth hai.
    suspend fun saveCustomer(customer: Customer) { /* local only */ }

    suspend fun loadCustomers(): List<Customer> = emptyList()

    suspend fun saveStock(stock: StockSettings) { /* local only */ }

    suspend fun loadStock(): StockSettings? = null
}
