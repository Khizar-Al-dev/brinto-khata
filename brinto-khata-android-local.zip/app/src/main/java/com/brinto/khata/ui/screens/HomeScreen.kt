package com.brinto.khata.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.TextButton
import androidx.compose.material3.DrawerState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.brinto.khata.data.Customer
import com.brinto.khata.ui.KhataViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.io.File

/**
 * Home = customers list.
 * Top search bar with a Name / Location filter: typing filters the
 * list by the chosen field, matching letters as typed.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: KhataViewModel,
    drawerState: DrawerState,
    scope: CoroutineScope,
    onAddCustomer: () -> Unit
) {
    val customers by viewModel.customers.collectAsState()
    var query by remember { mutableStateOf("") }
    var searchByLocation by remember { mutableStateOf(false) }
    // Long-press a customer card to ask for delete confirmation.
    var customerToDelete by remember { mutableStateOf<Customer?>(null) }

    val filtered = customers.filter { customer ->
        if (query.isBlank()) true
        else if (searchByLocation) customer.location.contains(query, ignoreCase = true)
        else customer.name.contains(query, ignoreCase = true)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Brinto Khata") },
                navigationIcon = {
                    IconButton(onClick = { scope.launch { drawerState.open() } }) {
                        Icon(Icons.Default.Menu, contentDescription = "Menu — three lines")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddCustomer) {
                Icon(Icons.Default.Add, contentDescription = "Add customer")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text(if (searchByLocation) "Search by Location" else "Search by Name") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.material3.FilterChip(
                    selected = !searchByLocation,
                    onClick = { searchByLocation = false },
                    label = { Text("Name") }
                )
                Spacer(Modifier.width(8.dp))
                androidx.compose.material3.FilterChip(
                    selected = searchByLocation,
                    onClick = { searchByLocation = true },
                    label = { Text("Location") }
                )
                Spacer(Modifier.width(8.dp))
                Text("${filtered.size} customers", style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filtered, key = { it.id }) { customer ->
                    CustomerCard(customer, onLongClick = { customerToDelete = customer })
                }
            }
            // Delete confirmation — long-press first, delete only after Yes.
            customerToDelete?.let { toDelete ->
                AlertDialog(
                    onDismissRequest = { customerToDelete = null },
                    title = { Text("Delete customer?") },
                    text = { Text("Delete ${toDelete.name} (${toDelete.location})? This cannot be undone.") },
                    confirmButton = {
                        TextButton(onClick = {
                            viewModel.deleteCustomer(toDelete)
                            customerToDelete = null
                        }) { Text("Yes, delete") }
                    },
                    dismissButton = {
                        TextButton(onClick = { customerToDelete = null }) { Text("Cancel") }
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CustomerCard(customer: Customer, onLongClick: (() -> Unit)? = null) {
    Card(
        modifier = Modifier.fillMaxWidth().combinedClickable(
            onClick = {},
            onLongClick = onLongClick
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (customer.photoPath.isNotBlank()) {
                AsyncImage(
                    model = File(customer.photoPath),
                    contentDescription = "Customer photo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(56.dp).clip(CircleShape)
                )
            } else {
                Icon(
                    Icons.Default.Person,
                    contentDescription = "No photo",
                    modifier = Modifier.size(56.dp).clip(CircleShape)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(customer.name, style = MaterialTheme.typography.titleMedium)
                Text("Location: ${customer.location}", style = MaterialTheme.typography.bodyMedium)
                if (customer.phone.isNotBlank()) {
                    Text("Phone: ${customer.phone}", style = MaterialTheme.typography.bodySmall)
                }
                Text(
                    "Packets: ${customer.packets}  |  Total: Rs ${customer.total.toInt()}",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    "Paid: Rs ${customer.paid.toInt()}  |  Remaining: Rs ${customer.remaining.toInt()}",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (customer.remaining > 0) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}
