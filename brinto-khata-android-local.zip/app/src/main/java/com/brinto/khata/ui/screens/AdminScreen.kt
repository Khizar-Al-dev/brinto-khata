package com.brinto.khata.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.brinto.khata.ui.KhataViewModel

/**
 * Admin screen (hamburger menu > Users — admin only).
 * Lists all user accounts with their role (admin / user).
 * Admin can issue a new user account (email + password) and can
 * change a user's role. The first registered user is Admin.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(viewModel: KhataViewModel, onBack: () -> Unit) {
    val users by viewModel.users.collectAsState()
    val message by viewModel.message.collectAsState()
    var newEmail by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Users (Admin)") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Issue a new user account", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = newEmail, onValueChange = { newEmail = it },
                label = { Text("New user Email (Gmail)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = newPassword, onValueChange = { newPassword = it },
                label = { Text("Password (user ke liye set karein)") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            if (error.isNotEmpty()) {
                Text(error, color = MaterialTheme.colorScheme.error)
            }
            Button(
                onClick = {
                    if (newEmail.isBlank() || newPassword.length < 6) {
                        error = "Valid email likhein, password kam se kam 6 characters ho."
                        return@Button
                    }
                    viewModel.createUserByAdmin(newEmail.trim(), newPassword)
                    newEmail = ""
                    newPassword = ""
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Create User Account") }
            if (message.isNotEmpty()) {
                Text(message, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(4.dp))
            Text("All users", style = MaterialTheme.typography.titleMedium)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(users, key = { it.uid }) { user ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(user.email, style = MaterialTheme.typography.titleMedium)
                            Text("Role: ${user.role}", style = MaterialTheme.typography.bodyMedium)
                            Row {
                                TextButton(onClick = { viewModel.changeRole(user.uid, "admin") }) {
                                    Text("Make Admin")
                                }
                                TextButton(onClick = { viewModel.changeRole(user.uid, "user") }) {
                                    Text("Make User")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
