package com.brinto.khata.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Brinto brand colours: deep blue + red (same as the logo).
private val BrintoBlue = Color(0xFF0B4ED8)
private val BrintoRed = Color(0xFFE31B23)
private val BrintoLightBlue = Color(0xFFE8F0FE)

private val LightColors = lightColorScheme(
    primary = BrintoBlue,
    secondary = BrintoRed,
    tertiary = BrintoBlue,
    background = Color(0xFFF6F8FC),
    surface = Color.White
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7FA8F5),
    secondary = Color(0xFFFF6B6B),
    background = Color(0xFF101418),
    surface = Color(0xFF1A1F27)
)

@Composable
fun BrintoKhataTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
