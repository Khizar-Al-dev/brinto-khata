package com.brinto.khata.data

import kotlinx.coroutines.flow.Flow

/**
 * Single place the UI talks to for data.
 *
 * Rule: Room is the source of truth on the phone (works offline).
 * Firestore is the cloud copy: every save also goes to Firestore,
 * and on login we pull the cloud copy down into Room, so data
 * survives app deletion — sign in again with the same Gmail and
 * the khata comes back.
 */
class KhataRepository(
    private val db: AppDatabase,
    private val cloud: FirestoreRepository
) {
    val customers: Flow<List<Customer>> = db.customerDao().getAll()
    val udhaar: Flow<List<Customer>> = db.customerDao().getUdhaar()
    val stock: Flow<StockSettings?> = db.stockDao().getStock()

    suspend fun refreshFromCloud() {
        val cloudCustomers = cloud.loadCustomers()
        if (cloudCustomers.isNotEmpty()) {
            db.customerDao().insertAll(cloudCustomers)
        }
        cloud.loadStock()?.let { db.stockDao().save(it) }
    }

    suspend fun getStockOnce(): StockSettings =
        db.stockDao().getStockOnce() ?: StockSettings()

    suspend fun saveStock(stock: StockSettings) {
        db.stockDao().save(stock)
        cloud.saveStock(stock)
    }

    /**
     * Add a customer order:
     *  - total = packets * unitPrice, remaining = total - paid
     *  - stock packets are deducted automatically
     *  - sale totals are updated (packets sold + sale amount)
     */
    /** Delete a customer (long-press on their card, then confirm). */
    suspend fun deleteCustomer(customer: Customer): Result<Unit> = runCatching {
        db.customerDao().deleteById(customer.id)
        cloud.deleteCustomer(customer.id)
    }

    suspend fun addCustomer(customer: Customer): Result<Unit> = runCatching {
        val stock = getStockOnce()
        val total = customer.packets * customer.unitPrice
        val finalCustomer = customer.copy(
            total = total,
            remaining = total - customer.paid
        )
        db.customerDao().insert(finalCustomer)
        cloud.saveCustomer(finalCustomer)

        val newStock = stock.copy(
            packetsInStock = (stock.packetsInStock - customer.packets).coerceAtLeast(0),
            totalPacketsSold = stock.totalPacketsSold + customer.packets,
            totalSalesAmount = stock.totalSalesAmount + total
        )
        db.stockDao().save(newStock)
        cloud.saveStock(newStock)
    }
}
