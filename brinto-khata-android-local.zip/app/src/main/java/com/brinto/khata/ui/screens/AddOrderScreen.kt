package com.brinto.khata.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.brinto.khata.data.Customer
import com.brinto.khata.data.UNIT_BOTH
import com.brinto.khata.data.UNIT_DOZEN
import com.brinto.khata.data.UNIT_KG
import com.brinto.khata.ui.KhataViewModel
import com.brinto.khata.util.dozensToPackets
import com.brinto.khata.util.formatDozensValue
import com.brinto.khata.util.formatKgValue

/**
 * Add Order — the short order form from the Orders screen.
 * Required: Name. Optional: Phone.
 * Quantity is Dozens and/or KG — both sections are always shown, so
 * one order can carry dozen packets AND loose KG together.
 * Price per dozen defaults to the stock price, but can be overridden
 * for this order; KG has its own price per KG (no stock default).
 * total = dozens * price-per-dozen + KG * price-per-KG.
 * No payment is taken here: Paid stays 0, so the order shows as
 * Remaining in Udhaar until it is paid (edit the order to add a
 * payment). Saving does everything the customer flow does: dozen
 * packets leave the stock, a SAVED event is written to History, and
 * the order is synced to the cloud.
 * Save runs only once: the button is disabled while saving, and on
 * success the screen closes automatically (no duplicate saves).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddOrderScreen(viewModel: KhataViewModel, onBack: () -> Unit, onSaved: () -> Unit) {
    val stock by viewModel.stock.collectAsState()

    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var dozensText by remember { mutableStateOf("") }
    var kgText by remember { mutableStateOf("") }
    var kgPriceText by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("") }
    var priceEdited by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    // True from the first Save tap until the save finishes. Blocks
    // repeated taps from creating duplicate orders.
    var isSaving by remember { mutableStateOf(false) }

    val defaultPricePerDozen = stock?.pricePerDozen ?: 0.0
    val dozens = dozensText.toDoubleOrNull() ?: 0.0
    val kg = kgText.toDoubleOrNull() ?: 0.0
    // Stored quantity: dozens x 12 packets (0 when no dozens given).
    val packets = dozensToPackets(dozens)
    // If the user has not typed a price, use the stock price; otherwise use theirs.
    val pricePerDozen = if (priceEdited) (priceText.toDoubleOrNull() ?: defaultPricePerDozen) else defaultPricePerDozen
    // KG orders have their own price per KG (no stock default).
    val pricePerKg = kgPriceText.toDoubleOrNull() ?: 0.0
    // Per-packet price is kept for storage; totals match the repository (packets x unitPrice).
    // KG part totals as KG x price-per-KG; dozen part as packets x unitPrice.
    val unitPrice = if (dozens > 0) pricePerDozen / 12.0 else 0.0
    val total = packets * unitPrice + kg * pricePerKg
    // Unit for this order: "both" when dozens and KG are both given.
    val unit = if (dozens > 0 && kg > 0) UNIT_BOTH else if (kg > 0) UNIT_KG else UNIT_DOZEN

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Add Order") },
                navigationIcon = {
                    IconButton(onClick = onBack, enabled = !isSaving) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("Name *") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = phone, onValueChange = { phone = it },
                label = { Text("Phone (optional)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text("Dozens (packets) — kitne dozen diye?", style = MaterialTheme.typography.bodyMedium)
            OutlinedTextField(
                value = dozensText, onValueChange = { dozensText = it },
                label = { Text("Dozens") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            if (dozens > 0) {
                Text(
                    "${formatDozensValue(dozens)} dozen = $packets packets (1 dozen = 12 packets).",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            OutlinedTextField(
                value = if (priceEdited) priceText else if (defaultPricePerDozen > 0) defaultPricePerDozen.toString() else "",
                onValueChange = { priceText = it; priceEdited = true },
                label = { Text("Price per dozen (Rs) — stock se auto, yahan change kar sakte hain") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Stock price: Rs ${stock?.pricePerDozen?.toInt() ?: 0} per dozen " +
                    "(Rs ${String.format("%.2f", stock?.pricePerPacket ?: 0.0)} per packet). " +
                    "Upar wali price change kar dein to is order par wahi price lagegi.",
                style = MaterialTheme.typography.bodySmall
            )
            Text("KG (khula) — kitne KG diye?", style = MaterialTheme.typography.bodyMedium)
            OutlinedTextField(
                value = kgText, onValueChange = { kgText = it },
                label = { Text("KG") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            if (kg > 0) {
                Text(
                    "${formatKgValue(kg)} KG.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            OutlinedTextField(
                value = kgPriceText, onValueChange = { kgPriceText = it },
                label = { Text("Price per KG (Rs)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "KG ki price yahan likhein — ye stock price se nahi aati, har KG order ki apni price hoti hai.",
                style = MaterialTheme.typography.bodySmall
            )

            // Live total — auto calculated as the user types.
            Text("Total Bill: Rs ${String.format("%.2f", total)}", style = MaterialTheme.typography.titleMedium)
            Text(
                "Payment yahan nahi li jati — ye order Udhaar mein Remaining dikhega, payment baad mein edit karke add kar sakte hain.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary
            )

            if (error.isNotEmpty()) {
                Text(error, color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(4.dp))
            Button(
                onClick = {
                    if (isSaving) return@Button
                    if (name.isBlank()) {
                        error = "Name zaroori hai."
                        return@Button
                    }
                    if (dozens <= 0 && kg <= 0) {
                        error = "Dozens ya KG mein se kam se kam aik (0 se zyada) zaroori hai."
                        return@Button
                    }
                    if (kg > 0 && pricePerKg <= 0) {
                        error = "KG likha hai to Price per KG (0 se zyada) zaroori hai."
                        return@Button
                    }
                    isSaving = true
                    error = ""
                    val ownerUid = viewModel.profile.value?.uid ?: ""
                    viewModel.addCustomer(
                        Customer(
                            name = name.trim(),
                            location = "",
                            phone = phone.trim(),
                            packets = packets,
                            unitPrice = unitPrice,
                            unit = unit,
                            kgQuantity = kg,
                            pricePerKg = pricePerKg,
                            total = total,
                            paid = 0.0,
                            remaining = total,
                            paidDate = System.currentTimeMillis(),
                            ownerUid = ownerUid
                        ),
                        onDone = { onSaved() },
                        onError = {
                            isSaving = false
                            error = "Save nahi ho saka. Dobara try karein."
                        }
                    )
                },
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (isSaving) "Saving..." else "Save Order")
            }
            Text(
                "Save karte hi order History mein aa jayega — dozen wale packets stock se deduct ho jayenge, KG wale nahi. Save ke baad screen khud band ho jayegi.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
