package com.brinto.khata.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.brinto.khata.data.HistoryEvent
import com.brinto.khata.ui.KhataViewModel
import com.brinto.khata.util.formatDate

/**
 * History (hamburger menu > History).
 * Every SAVED and DELETED customer order is listed here with its
 * date. Deleted customers stay visible here even after they are
 * gone from Home. Tapping a row opens the full old order.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(viewModel: KhataViewModel, onBack: () -> Unit) {
    val history by viewModel.history.collectAsState()
    var selected by remember { mutableStateOf<HistoryEvent?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("History") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(
                "${history.size} events — saved aur deleted orders, dates ke saath.",
                style = MaterialTheme.typography.bodyMedium
            )
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(history, key = { it.id }) { event ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { selected = event },
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(event.customerName, style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (event.action == "DELETED") "Deleted" else "Saved",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (event.action == "DELETED") MaterialTheme.colorScheme.error
                                else MaterialTheme.colorScheme.primary
                            )
                            Text(
                                formatDate(event.eventDate),
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(event.details, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            if (history.isEmpty()) {
                Text(
                    "Abhi koi history nahi hai — jab koi customer save ya delete hoga, wo yahan dikhega.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }

    // Full old order — tap a row to see it.
    selected?.let { event ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(event.customerName) },
            text = {
                Column {
                    Text(if (event.action == "DELETED") "Deleted" else "Saved")
                    Text("Location: ${event.location}")
                    Text("Packets: ${event.packets}")
                    Text("Total: Rs ${event.total.toInt()}")
                    Text("Paid: Rs ${event.paid.toInt()}")
                    Text("Remaining: Rs ${event.remaining.toInt()}")
                    Text("Date: ${formatDate(event.eventDate)}")
                    Text(event.details)
                }
            },
            confirmButton = {
                TextButton(onClick = { selected = null }) { Text("Close") }
            }
        )
    }
}
