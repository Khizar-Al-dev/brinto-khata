package com.brinto.khata.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.brinto.khata.data.HistoryEvent
import com.brinto.khata.ui.KhataViewModel
import com.brinto.khata.util.formatDate
import com.brinto.khata.util.isSameDay
import com.brinto.khata.util.parseDate

/**
 * History (hamburger menu > History).
 * Every SAVED, UPDATED and DELETED customer order is listed here with
 * its date. Edited orders are saved here too: saving an edit writes
 * an UPDATED event with the new values and the edit date. Deleted
 * customers stay visible here even after they are gone from Home.
 * Tapping a row opens the full old order. Search works exactly like
 * Home: a search bar with Name / Location filter chips — plus a Date
 * chip: tapping Date switches the keypad to numbers, and typing an
 * exact date (e.g. 2/3/2026) shows only that day's events.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(viewModel: KhataViewModel, onBack: () -> Unit) {
    val history by viewModel.history.collectAsState()
    var selected by remember { mutableStateOf<HistoryEvent?>(null) }
    var query by remember { mutableStateOf("") }
    // Search mode: "name" (default), "location" or "date".
    var searchMode by remember { mutableStateOf("name") }

    // Same search as Home: Name (default) or Location, matching letters as typed.
    // Date mode: the keypad switches to numbers; an exact date (2/3/2026 or
    // 02/03/2026) shows only that calendar day's SAVED / UPDATED / DELETED events.
    val filtered = history.filter { event ->
        if (query.isBlank()) true
        else when (searchMode) {
            "location" -> event.location.contains(query, ignoreCase = true)
            "date" -> {
                val dayStart = parseDate(query)
                dayStart != null && isSameDay(event.eventDate, dayStart)
            }
            else -> event.customerName.contains(query, ignoreCase = true)
        }
    }

    fun actionLabel(action: String): String = when (action) {
        "DELETED" -> "Deleted"
        "UPDATED" -> "Updated"
        else -> "Saved"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("History") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = {
                    Text(
                        when (searchMode) {
                            "location" -> "Search by Location"
                            "date" -> "Date — dd/MM/yyyy (e.g. 2/3/2026)"
                            else -> "Search by Name"
                        }
                    )
                },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                keyboardOptions = KeyboardOptions(
                    keyboardType = if (searchMode == "date") KeyboardType.Number else KeyboardType.Text
                ),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.material3.FilterChip(
                    selected = searchMode == "name",
                    onClick = { searchMode = "name" },
                    label = { Text("Name") }
                )
                Spacer(Modifier.width(8.dp))
                androidx.compose.material3.FilterChip(
                    selected = searchMode == "location",
                    onClick = { searchMode = "location" },
                    label = { Text("Location") }
                )
                Spacer(Modifier.width(8.dp))
                androidx.compose.material3.FilterChip(
                    selected = searchMode == "date",
                    onClick = { searchMode = "date" },
                    label = { Text("Date") }
                )
                Spacer(Modifier.width(8.dp))
                Text("${filtered.size} events", style = MaterialTheme.typography.bodySmall)
            }
            if (searchMode == "date" && query.isNotBlank() && parseDate(query) == null) {
                Text(
                    "Poori date likhein — e.g. 2/3/2026",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
            Text(
                "${history.size} events — saved, updated aur deleted orders, dates ke saath.",
                style = MaterialTheme.typography.bodyMedium
            )
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filtered, key = { it.id }) { event ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { selected = event },
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(event.customerName, style = MaterialTheme.typography.titleMedium)
                            Text(
                                actionLabel(event.action),
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (event.action == "DELETED") MaterialTheme.colorScheme.error
                                else MaterialTheme.colorScheme.primary
                            )
                            Text(
                                formatDate(event.eventDate),
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(event.details, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            if (filtered.isEmpty()) {
                Text(
                    if (history.isEmpty()) "Abhi koi history nahi hai — jab koi customer save, update ya delete hoga, wo yahan dikhega."
                    else "Is search se koi history nahi mili.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }

    // Full old order — tap a row to see it.
    selected?.let { event ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(event.customerName) },
            text = {
                Column {
                    Text(actionLabel(event.action))
                    Text("Location: ${event.location}")
                    Text("Packets: ${event.packets}")
                    Text("Total: Rs ${event.total.toInt()}")
                    Text("Paid: Rs ${event.paid.toInt()}")
                    Text("Remaining: Rs ${event.remaining.toInt()}")
                    Text("Date: ${formatDate(event.eventDate)}")
                    Text(event.details)
                }
            },
            confirmButton = {
                TextButton(onClick = { selected = null }) { Text("Close") }
            }
        )
    }
}
