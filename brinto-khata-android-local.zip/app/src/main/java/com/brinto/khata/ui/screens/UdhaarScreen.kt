package com.brinto.khata.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.brinto.khata.ui.KhataViewModel

/**
 * Borrowed / Udhaar section (hamburger menu > Udhaar).
 * Only customers with remaining > 0 are shown, with name,
 * location and remaining amount.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UdhaarScreen(viewModel: KhataViewModel, onBack: () -> Unit) {
    val udhaar by viewModel.udhaar.collectAsState()
    val totalUdhaar = udhaar.sumOf { it.remaining }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Udhaar (Borrowed)") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(
                "Total Udhaar: Rs ${String.format("%.2f", totalUdhaar)}  •  ${udhaar.size} persons",
                style = MaterialTheme.typography.titleMedium
            )
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(udhaar, key = { it.id }) { customer ->
                    CustomerCard(customer)
                }
            }
            if (udhaar.isEmpty()) {
                Text(
                    "Koi udhaar nahi hai — sab customers ne poora pay kar diya hai.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}
