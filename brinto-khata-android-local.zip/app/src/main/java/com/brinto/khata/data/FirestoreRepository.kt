package com.brinto.khata.data

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest

/**
 * LOCAL-ONLY build variant (brinto-khata-android-local).
 *
 * Is variant mein Firebase NAHI hai — na Auth, na Firestore, na
 * google-services.json. Login / users sirf is phone par save hote
 * hain (SharedPreferences mein, password SHA-256 hash ke saath —
 * plain text mein nahi).
 *
 * Collections ki jagah local store:
 *   users  -> SharedPreferences "brinto_local_users"
 *   session -> SharedPreferences "brinto_local_session" (current uid)
 *
 * API bilkul waisi hi hai jaisi Firebase wale FirestoreRepository
 * ki thi, taake KhataRepository / KhataViewModel / screens mein
 * koi change na karna pare:
 *   signUp / signIn -> Result<LocalUser>
 *   getProfile / getAllUsers / createUserByAdmin
 *   saveCustomer / loadCustomers / saveStock / loadStock /
 *   saveHistoryEvent / loadHistory, aur sync helpers
 *   (currentUid / cloudAvailable / Strict / Legacy / migration)
 *     -> local mein ye no-op hain: Room hi source of truth hai.
 *
 * LIMIT: Data sirf is phone par hai. App delete ho jaye to data
 * khatam ho jayega. Cloud / Gmail sync ke liye asal Firebase
 * project aur google-services.json chahiye (original project
 * brinto-khata-android dekhein).
 */
data class LocalUser(val uid: String, val email: String)

class FirestoreRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("brinto_local_users", Context.MODE_PRIVATE)
    private val sessionPrefs: SharedPreferences =
        context.getSharedPreferences("brinto_local_session", Context.MODE_PRIVATE)

    private fun hash(password: String): String {
        val bytes = MessageDigest.getInstance("SHA-256")
            .digest(password.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun userKey(uid: String) = "user_$uid"

    private fun readUser(uid: String): UserProfile? {
        val raw = prefs.getString(userKey(uid), null) ?: return null
        // stored as: email|role|passwordHash
        val parts = raw.split("|")
        if (parts.size < 3) return null
        // Role is fixed by email: a stored "admin" for any other email
        // is ignored, so nobody else can ever be admin.
        return UserProfile(uid = uid, email = parts[0], role = roleForEmail(parts[0]))
    }

    private fun readPasswordHash(uid: String): String? {
        val raw = prefs.getString(userKey(uid), null) ?: return null
        val parts = raw.split("|")
        return if (parts.size >= 3) parts[2] else null
    }

    private fun writeUser(profile: UserProfile, passwordHash: String) {
        prefs.edit()
            .putString(userKey(profile.uid), "${profile.email}|${profile.role}|$passwordHash")
            .apply()
    }

    private fun allUids(): List<String> =
        prefs.all.keys.filter { it.startsWith("user_") }.map { it.removePrefix("user_") }

    private fun findByEmail(email: String): UserProfile? =
        allUids().mapNotNull { readUser(it) }.firstOrNull { it.email.equals(email, ignoreCase = true) }

    val currentUser: LocalUser?
        get() {
            val uid = sessionPrefs.getString("current_uid", null) ?: return null
            val profile = readUser(uid) ?: return null
            return LocalUser(uid = profile.uid, email = profile.email)
        }

    suspend fun signUp(email: String, password: String): Result<LocalUser> = runCatching {
        val cleanEmail = email.trim()
        if (findByEmail(cleanEmail) != null) throw IllegalStateException("Is email se account pehle se hai")
        // Only the admin email becomes Admin; everyone else is a normal user.
        val role = roleForEmail(cleanEmail)
        val uid = java.util.UUID.randomUUID().toString()
        writeUser(UserProfile(uid = uid, email = cleanEmail, role = role), hash(password))
        sessionPrefs.edit().putString("current_uid", uid).apply()
        LocalUser(uid = uid, email = cleanEmail)
    }

    suspend fun signIn(email: String, password: String): Result<LocalUser> = runCatching {
        val profile = findByEmail(email.trim())
            ?: throw IllegalStateException("Login failed — email / password check karein")
        if (readPasswordHash(profile.uid) != hash(password)) {
            throw IllegalStateException("Login failed — email / password check karein")
        }
        sessionPrefs.edit().putString("current_uid", profile.uid).apply()
        LocalUser(uid = profile.uid, email = profile.email)
    }

    fun signOut() {
        sessionPrefs.edit().remove("current_uid").apply()
    }

    suspend fun getProfile(uid: String): UserProfile? = readUser(uid)

    suspend fun getAllUsers(): List<UserProfile> =
        allUids().mapNotNull { readUser(it) }

    /** Admin creates / issues another user account (local only, admin stays signed in). */
    suspend fun createUserByAdmin(email: String, password: String): Result<Unit> = runCatching {
        val cleanEmail = email.trim()
        if (findByEmail(cleanEmail) != null) throw IllegalStateException("Is email se account pehle se hai")
        val uid = java.util.UUID.randomUUID().toString()
        writeUser(UserProfile(uid = uid, email = cleanEmail, role = roleForEmail(cleanEmail)), hash(password))
    }


    // Cloud sync — local variant mein no-op: Room hi source of truth hai.
    // cloudAvailable false hai, is liye refreshFromCloud foran wapas
    // aa jata hai aur Room ko kabhi nahi chheerta.

    /** UID of the signed-in local user, or null when signed out. */
    val currentUid: String? get() = currentUser?.uid

    /** False: no cloud backend in the local-only variant. */
    val cloudAvailable: Boolean = false

    suspend fun saveCustomer(customer: Customer) { /* local only */ }

    suspend fun saveCustomerStrict(customer: Customer) { /* local only */ }

    suspend fun deleteCustomer(customerId: String) { /* local only */ }

    suspend fun saveOrder(order: ShopOrder) { /* local only */ }

    suspend fun saveOrderStrict(order: ShopOrder) { /* local only */ }

    suspend fun deleteOrder(orderId: String) { /* local only */ }

    suspend fun loadOrders(): List<ShopOrder> = emptyList()

    suspend fun loadCustomers(): List<Customer> = emptyList()

    suspend fun loadLegacyCustomers(): List<Customer> = emptyList()

    suspend fun saveHistoryEvent(event: HistoryEvent) { /* local only */ }

    suspend fun saveHistoryEventStrict(event: HistoryEvent) { /* local only */ }

    suspend fun loadHistory(): List<HistoryEvent> = emptyList()

    suspend fun loadLegacyHistory(): List<HistoryEvent> = emptyList()

    suspend fun saveStock(stock: StockSettings) { /* local only */ }

    suspend fun saveStockStrict(stock: StockSettings) { /* local only */ }

    suspend fun loadStock(): StockSettings? = null

    suspend fun loadLegacyStock(): StockSettings? = null

    suspend fun isLegacyMigrated(): Boolean = false

    suspend fun markLegacyMigrated() { /* local only */ }
}
