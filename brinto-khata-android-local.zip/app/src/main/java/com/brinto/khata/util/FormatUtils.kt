package com.brinto.khata.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Formats a millis timestamp as dd/MM/yyyy, e.g. 02/02/2026. */
fun formatDate(millis: Long): String {
    if (millis == 0L) return "-"
    return SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(millis))
}

/**
 * Parses a date typed by the user, e.g. "2/3/2026" or "02/03/2026"
 * (also accepts "-" or "." as separator). Returns the start of that
 * day in millis, or null if the text is not a valid exact date.
 */
fun parseDate(text: String): Long? {
    val parts = text.trim().split('/', '-', '.')
    if (parts.size != 3) return null
    val day = parts[0].toIntOrNull() ?: return null
    val month = parts[1].toIntOrNull() ?: return null
    val year = parts[2].toIntOrNull() ?: return null
    if (year < 1900 || year > 2100 || month < 1 || month > 12 || day < 1 || day > 31) return null
    return try {
        val cal = java.util.Calendar.getInstance()
        cal.isLenient = false
        cal.set(java.util.Calendar.YEAR, year)
        cal.set(java.util.Calendar.MONTH, month - 1)
        cal.set(java.util.Calendar.DAY_OF_MONTH, day)
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        cal.timeInMillis
    } catch (e: Exception) {
        null
    }
}

/** True if [millis] falls on the same calendar day as [dayStartMillis] (start of day). */
fun isSameDay(millis: Long, dayStartMillis: Long): Boolean {
    val cal = java.util.Calendar.getInstance()
    cal.timeInMillis = millis
    val day = cal.get(java.util.Calendar.DAY_OF_MONTH)
    val month = cal.get(java.util.Calendar.MONTH)
    val year = cal.get(java.util.Calendar.YEAR)
    cal.timeInMillis = dayStartMillis
    return day == cal.get(java.util.Calendar.DAY_OF_MONTH)
        && month == cal.get(java.util.Calendar.MONTH)
        && year == cal.get(java.util.Calendar.YEAR)
}
