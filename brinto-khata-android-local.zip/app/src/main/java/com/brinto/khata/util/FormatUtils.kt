package com.brinto.khata.util

import com.brinto.khata.data.UNIT_BOTH
import com.brinto.khata.data.UNIT_KG
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** One dozen = 12 packets. Quantities are entered and shown in dozens; packets are stored. */
const val PACKETS_PER_DOZEN: Int = 12

/** Dozens (may be fractional for old orders) for a stored packets count. */
fun packetsToDozens(packets: Int): Double = packets / 12.0

/** Stored packets count for a dozens quantity entered by the user. */
fun dozensToPackets(dozens: Double): Int = (dozens * 12.0).roundToInt()

/** Dozens as text without trailing zeros, e.g. 36 packets -> "3", 18 packets -> "1.5". */
fun formatDozens(packets: Int): String = formatDozensValue(packets / 12.0)

/** A dozens value as text without trailing zeros, e.g. 3.0 -> "3", 1.5 -> "1.5". */
fun formatDozensValue(dozens: Double): String {
    val text = String.format(Locale.getDefault(), "%.2f", dozens)
    return text.trimEnd('0').trimEnd('.').ifEmpty { "0" }
}

/** A KG quantity as text without trailing zeros, e.g. 2.5 -> "2.5", 2.0 -> "2". */
fun formatKgValue(kg: Double): String = formatDozensValue(kg)

/**
 * One-line quantity label for an order: "KG: 2.5 KG" for KG orders,
 * "Dozens: 3 (36 packets)" for dozen orders, and both parts joined
 * for combined orders ("Dozens: 2 (24 packets) + KG: 2 KG").
 */
fun quantityLine(unit: String, packets: Int, kg: Double): String =
    when {
        unit == UNIT_KG -> "KG: ${formatKgValue(kg)} KG"
        unit == UNIT_BOTH -> "Dozens: ${formatDozens(packets)} (${packets} packets) + KG: ${formatKgValue(kg)} KG"
        else -> "Dozens: ${formatDozens(packets)} (${packets} packets)"
    }

/** Formats a millis timestamp as dd/MM/yyyy, e.g. 02/02/2026. */
fun formatDate(millis: Long): String {
    if (millis == 0L) return "-"
    return SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(millis))
}

/**
 * Parses a date typed by the user, e.g. "2/3/2026" or "02/03/2026"
 * (also accepts "-" or "." as separator). Returns the start of that
 * day in millis, or null if the text is not a valid exact date.
 */
fun parseDate(text: String): Long? {
    val parts = text.trim().split('/', '-', '.')
    if (parts.size != 3) return null
    val day = parts[0].toIntOrNull() ?: return null
    val month = parts[1].toIntOrNull() ?: return null
    val year = parts[2].toIntOrNull() ?: return null
    if (year < 1900 || year > 2100 || month < 1 || month > 12 || day < 1 || day > 31) return null
    return try {
        val cal = java.util.Calendar.getInstance()
        cal.isLenient = false
        cal.set(java.util.Calendar.YEAR, year)
        cal.set(java.util.Calendar.MONTH, month - 1)
        cal.set(java.util.Calendar.DAY_OF_MONTH, day)
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        cal.timeInMillis
    } catch (e: Exception) {
        null
    }
}

/** True if [millis] falls on the same calendar day as [dayStartMillis] (start of day). */
fun isSameDay(millis: Long, dayStartMillis: Long): Boolean {
    val cal = java.util.Calendar.getInstance()
    cal.timeInMillis = millis
    val day = cal.get(java.util.Calendar.DAY_OF_MONTH)
    val month = cal.get(java.util.Calendar.MONTH)
    val year = cal.get(java.util.Calendar.YEAR)
    cal.timeInMillis = dayStartMillis
    return day == cal.get(java.util.Calendar.DAY_OF_MONTH)
        && month == cal.get(java.util.Calendar.MONTH)
        && year == cal.get(java.util.Calendar.YEAR)
}
