package com.brinto.khata.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.brinto.khata.ui.KhataViewModel
import com.brinto.khata.util.formatDate
import com.brinto.khata.util.quantityLine

/**
 * Customer Detail — opened by tapping a saved customer card on Home.
 * Shows the same details as the card, plus:
 *  - "Saved on" and "Paid on" dates
 *  - three-dots menu (top-right): "Edit order" opens the edit form,
 *    "Delete customer" asks for confirmation and deletes (same as
 *    the long-press delete on Home).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerDetailScreen(
    viewModel: KhataViewModel,
    customerId: String,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onDeleted: () -> Unit
) {
    val customers by viewModel.customers.collectAsState()
    val customer = customers.firstOrNull { it.id == customerId }

    // Three-dots menu and delete confirmation.
    var menuExpanded by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    if (showDeleteConfirm && customer != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete customer?") },
            text = { Text("Delete ${customer.name} (${customer.location})? This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirm = false
                    viewModel.deleteCustomer(customer)
                    onDeleted()
                }) { Text("Yes, delete") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(customer?.name ?: "Customer") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Three-dots menu: Edit order / Delete customer.
                    IconButton(onClick = { menuExpanded = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More options")
                    }
                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Edit order") },
                            onClick = {
                                menuExpanded = false
                                onEdit()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Delete customer") },
                            onClick = {
                                menuExpanded = false
                                showDeleteConfirm = true
                            }
                        )
                    }
                }
            )
        }
    ) { padding ->
        if (customer == null) {
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Customer not found — ye customer delete ho chuka ho sakta hai.")
            }
        } else {
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Same details as the Home card.
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(customer.name, style = MaterialTheme.typography.titleLarge)
                Text("Location: ${customer.location}", style = MaterialTheme.typography.bodyLarge)
                if (customer.phone.isNotBlank()) {
                    Text("Phone: ${customer.phone}", style = MaterialTheme.typography.bodyMedium)
                }
                Text(quantityLine(customer.unit, customer.packets, customer.kgQuantity), style = MaterialTheme.typography.bodyMedium)
                Text(
                    "Total: Rs ${customer.total.toInt()}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    "Paid: Rs ${customer.paid.toInt()}  |  Remaining: Rs ${customer.remaining.toInt()}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (customer.remaining > 0) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary
                )
                if (customer.orderProfit > 0) {
                    Text(
                        "Profit in this order: Rs ${String.format("%.2f", customer.orderProfit)}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                Text(
                    "Saved on: ${formatDate(customer.createdAt)}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    "Paid on: ${formatDate(customer.paidDate)}",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

        }
        }
    }
}
