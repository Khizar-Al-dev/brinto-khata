package com.brinto.khata.ui.screens

import android.view.LayoutInflater
import android.widget.DatePicker
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.brinto.khata.R
import com.brinto.khata.data.Customer
import com.brinto.khata.ui.KhataViewModel
import com.brinto.khata.util.formatDate
import com.brinto.khata.util.formatDozens
import com.brinto.khata.util.formatKgValue
import com.brinto.khata.util.parseDate
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Analytics (hamburger menu > Analytics).
 * All numbers come from LOCAL Room data only (customers list, by saved
 * date Customer.createdAt). History events are NOT used here, so a
 * deleted order is never double counted. Nothing is synced to Firestore.
 *
 * Three modes:
 * - Month: selected month (arrows to move) + a "Last 30 days" summary.
 * - Year: selected year (arrows to move), whole-year totals.
 * - Custom: From / To dates picked from a wheel (day / month / year
 *   spinner): tap a date, scroll the wheels up-down, OK. From defaults
 *   to the 1st of this month, To defaults to today. + Show button.
 *
 * Each period shows: Total Sale, Total Profit, Total Borrowed/Udhaar,
 * Total Dozens Sold, Number of Orders.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyticsScreen(viewModel: KhataViewModel, onBack: () -> Unit) {
    val customers by viewModel.customers.collectAsState()
    var mode by remember { mutableStateOf("month") } // "month", "year" or "custom"

    val now = Calendar.getInstance()
    var monthYear by remember { mutableStateOf(now.get(Calendar.YEAR)) }
    var month by remember { mutableStateOf(now.get(Calendar.MONTH)) } // 0-11
    var year by remember { mutableStateOf(now.get(Calendar.YEAR)) }

    var fromText by remember { mutableStateOf("") }
    var toText by remember { mutableStateOf("") }
    var customFrom by remember { mutableStateOf<Long?>(null) }
    var customTo by remember { mutableStateOf<Long?>(null) }
    var customError by remember { mutableStateOf("") }
    // Which date the wheel dialog is picking: "from" / "to" / null (closed).
    var wheelTarget by remember { mutableStateOf<String?>(null) }

    fun applyCustom() {
        val from = parseDate(fromText)
        val to = parseDate(toText)
        when {
            from == null || to == null -> customError = "Dono dates chunein — From aur To par tap karke wheel se select karein."
            from > to -> customError = "From date, To date se pehle honi chahiye."
            else -> {
                customError = ""
                customFrom = from
                customTo = to
            }
        }
    }

    fun monthName(y: Int, m: Int): String {
        val cal = Calendar.getInstance()
        cal.set(Calendar.YEAR, y)
        cal.set(Calendar.MONTH, m)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        return SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(cal.time)
    }

    fun inMonth(c: Customer): Boolean {
        val cal = Calendar.getInstance()
        cal.timeInMillis = c.createdAt
        return cal.get(Calendar.YEAR) == monthYear && cal.get(Calendar.MONTH) == month
    }

    fun inYear(c: Customer): Boolean {
        val cal = Calendar.getInstance()
        cal.timeInMillis = c.createdAt
        return cal.get(Calendar.YEAR) == year
    }

    fun inLast30Days(c: Customer): Boolean =
        c.createdAt >= System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000

    fun inCustom(c: Customer): Boolean {
        val from = customFrom ?: return false
        val to = customTo ?: return false
        // To-date is inclusive: up to the end of that day.
        return c.createdAt in from..(to + 24L * 60 * 60 * 1000 - 1)
    }

    val periodCustomers = when (mode) {
        "year" -> customers.filter { inYear(it) }
        "custom" -> customers.filter { inCustom(it) }
        else -> customers.filter { inMonth(it) }
    }
    val last30 = customers.filter { inLast30Days(it) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Analytics") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Mode tabs.
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                androidx.compose.material3.FilterChip(
                    selected = mode == "month",
                    onClick = { mode = "month" },
                    label = { Text("Month") }
                )
                androidx.compose.material3.FilterChip(
                    selected = mode == "year",
                    onClick = { mode = "year" },
                    label = { Text("Year") }
                )
                androidx.compose.material3.FilterChip(
                    selected = mode == "custom",
                    onClick = { mode = "custom" },
                    label = { Text("Custom") }
                )
            }

            when (mode) {
                "month" -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = {
                            if (month == 0) { month = 11; monthYear -= 1 } else month -= 1
                        }) { Icon(Icons.Default.ChevronLeft, contentDescription = "Previous month") }
                        Text(monthName(monthYear, month), style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        IconButton(onClick = {
                            if (month == 11) { month = 0; monthYear += 1 } else month += 1
                        }) { Icon(Icons.Default.ChevronRight, contentDescription = "Next month") }
                    }
                    StatsCard(title = monthName(monthYear, month), orders = periodCustomers)
                    StatsCard(title = "Last 30 days", orders = last30)
                }
                "year" -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { year -= 1 }) { Icon(Icons.Default.ChevronLeft, contentDescription = "Previous year") }
                        Text("Year $year", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        IconButton(onClick = { year += 1 }) { Icon(Icons.Default.ChevronRight, contentDescription = "Next year") }
                    }
                    StatsCard(title = "Year $year", orders = periodCustomers)
                }
                "custom" -> {
                    OutlinedTextField(
                        value = fromText,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("From date") },
                        placeholder = { Text("Tap karein — wheel se chunein") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().clickable { wheelTarget = "from" }
                    )
                    OutlinedTextField(
                        value = toText,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("To date (aaj tak)") },
                        placeholder = { Text("Tap karein — wheel se chunein") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().clickable { wheelTarget = "to" }
                    )
                    Button(
                        onClick = { applyCustom() },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Show") }
                    if (customError.isNotEmpty()) {
                        Text(customError, color = MaterialTheme.colorScheme.error)
                    }
                    if (customFrom != null && customTo != null) {
                        StatsCard(
                            title = "${formatDate(customFrom!!)} to ${formatDate(customTo!!)}",
                            orders = periodCustomers
                        )
                    } else {
                        Text(
                            "Date par tap karein — wheel se day, month, year upar-neeche karke chunein. To date aaj tak ki rakh sakte hain.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    // Wheel date picker dialog (native spinner DatePicker:
                    // day / month / year wheels, scrolled up-down).
                    if (wheelTarget != null) {
                        val isFrom = wheelTarget == "from"
                        val initialMillis = if (isFrom) {
                            parseDate(fromText) ?: Calendar.getInstance()
                                .apply { set(Calendar.DAY_OF_MONTH, 1) }.timeInMillis
                        } else {
                            parseDate(toText) ?: System.currentTimeMillis()
                        }
                        val picked = remember(wheelTarget) {
                            Calendar.getInstance().apply {
                                timeInMillis = initialMillis
                                set(Calendar.HOUR_OF_DAY, 0)
                                set(Calendar.MINUTE, 0)
                                set(Calendar.SECOND, 0)
                                set(Calendar.MILLISECOND, 0)
                            }
                        }
                        AlertDialog(
                            onDismissRequest = { wheelTarget = null },
                            title = { Text(if (isFrom) "From date chunein" else "To date chunein") },
                            text = {
                                AndroidView(
                                    factory = { ctx ->
                                        (LayoutInflater.from(ctx).inflate(
                                            R.layout.date_picker_spinner, null
                                        ) as DatePicker).apply {
                                            init(
                                                picked.get(Calendar.YEAR),
                                                picked.get(Calendar.MONTH),
                                                picked.get(Calendar.DAY_OF_MONTH)
                                            ) { _, y, m, d -> picked.set(y, m, d) }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            },
                            confirmButton = {
                                TextButton(onClick = {
                                    val text = formatDate(picked.timeInMillis)
                                    if (isFrom) fromText = text else toText = text
                                    wheelTarget = null
                                    // Show the result at once when both dates are set.
                                    if (fromText.isNotBlank() && toText.isNotBlank()) applyCustom()
                                }) { Text("OK") }
                            },
                            dismissButton = {
                                TextButton(onClick = { wheelTarget = null }) { Text("Cancel") }
                            }
                        )
                    }
                }
            }
            Text(
                "Numbers sirf saved customers se bante hain (saved date ke hisaab se). Deleted orders yahan nahi gine jate.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun StatsCard(title: String, orders: List<Customer>) {
    val totalSale = orders.sumOf { it.total }
    val totalProfit = orders.sumOf { it.orderProfit }
    val totalBorrowed = orders.sumOf { it.remaining }
    val totalPackets = orders.sumOf { it.packets }
    val totalKg = orders.sumOf { it.kgQuantity }
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text("Total Sale: Rs ${String.format("%.2f", totalSale)}", style = MaterialTheme.typography.bodyLarge)
            Text("Total Profit: Rs ${String.format("%.2f", totalProfit)}", style = MaterialTheme.typography.bodyLarge)
            Text("Total Borrowed / Udhaar: Rs ${String.format("%.2f", totalBorrowed)}", style = MaterialTheme.typography.bodyLarge)
            Text("Total Dozens Sold: ${formatDozens(totalPackets)} ($totalPackets packets)", style = MaterialTheme.typography.bodyLarge)
            if (totalKg > 0) {
                Text("Total KG Sold: ${formatKgValue(totalKg)} KG", style = MaterialTheme.typography.bodyLarge)
            }
            Text("Number of Orders: ${orders.size}", style = MaterialTheme.typography.bodyLarge)
        }
    }
}
