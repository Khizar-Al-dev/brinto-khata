package com.brinto.khata.util

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

/**
 * Photos: only images are accepted (the pickers below use "image/*").
 * A picked / taken photo is copied into the app's private folder, so
 * the thumbnail still shows after the gallery app is closed.
 */
object ImageUtils {
    fun copyImageToInternalStorage(context: Context, uri: Uri): String? {
        return try {
            val dir = File(context.filesDir, "customer_photos").apply { mkdirs() }
            val file = File(dir, "photo_${System.currentTimeMillis()}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            }
            file.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    fun createCameraImageFile(context: Context): File {
        val dir = File(context.getExternalFilesDir("Pictures"), "BrintoKhata").apply { mkdirs() }
        return File(dir, "photo_${System.currentTimeMillis()}.jpg")
    }
}
