package com.brinto.khata.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.brinto.khata.R
import com.brinto.khata.ui.KhataViewModel

/**
 * Login is compulsory. Email + password chosen by the user.
 * First user to sign up becomes Admin (see FirestoreRepository).
 */
@Composable
fun AuthScreen(viewModel: KhataViewModel, onLoggedIn: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isSignUp by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.brinto_logo),
            contentDescription = "Brinto logo",
            modifier = Modifier.size(180.dp).clip(RoundedCornerShape(16.dp))
        )
        Spacer(Modifier.height(16.dp))
        Text("Brinto Khata", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Wholesaler khata — Brinto Washing Powder",
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(24.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email (Gmail)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password (apna password chunein)") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        if (error.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text(error, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                if (email.isBlank() || password.length < 6) {
                    error = "Valid email likhein, password kam se kam 6 characters ho."
                    return@Button
                }
                if (isSignUp) {
                    viewModel.signUp(email.trim(), password) { ok ->
                        if (ok) onLoggedIn() else error = "Sign up nahi ho saka — email / password check karein."
                    }
                } else {
                    viewModel.signIn(email.trim(), password) { ok ->
                        if (ok) onLoggedIn() else error = "Login nahi ho saka — email / password check karein."
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (isSignUp) "Create Account" else "Login")
        }
        TextButton(onClick = { isSignUp = !isSignUp; error = "" }) {
            Text(if (isSignUp) "Account hai? Login karein" else "Naya account banayein (Sign Up)")
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Pehla user Admin hota hai. LOCAL-ONLY version: data sirf is phone par save hota hai — app delete ho jaye to data khatam ho jayega. Cloud sync ke liye Firebase wala version chahiye.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
