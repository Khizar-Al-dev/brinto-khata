package com.brinto.khata.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.brinto.khata.data.Customer
import com.brinto.khata.data.UNIT_DOZEN
import com.brinto.khata.data.UNIT_BOTH
import com.brinto.khata.data.UNIT_KG
import com.brinto.khata.ui.KhataViewModel
import com.brinto.khata.util.dozensToPackets
import com.brinto.khata.util.formatDozensValue
import com.brinto.khata.util.formatKgValue

/**
 * Add Customer (Khata entry) form.
 * Required: Name, Location, Quantity, Amount Paid.
 * Optional: Phone.
 * Quantity is Dozens and/or KG — both sections are always shown, so
 * one order can carry dozen packets AND loose KG together. Dozen:
 * entered in DOZENS (1 dozen = 12 packets) and stored as packets
 * (dozens x 12); total = dozens * price-per-dozen + KG * price-per-KG.
 * KG part never touches the dozen stock and earns no profit; profit
 * comes only from the dozen part.
 * Remaining = total - paid (auto).
 * Price per dozen defaults to the stock price, but can be overridden
 * for this order (discount / lower price) — the order keeps its own price.
 * Save runs only once: the button is disabled while saving, and on
 * success the screen closes automatically (no duplicate saves).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddCustomerScreen(viewModel: KhataViewModel, onBack: () -> Unit, onSaved: () -> Unit) {
    val stock by viewModel.stock.collectAsState()

    var name by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var dozensText by remember { mutableStateOf("") }
    var kgText by remember { mutableStateOf("") }
    var kgPriceText by remember { mutableStateOf("") }
    var paidText by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("") }
    var priceEdited by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    // True from the first Save tap until the save finishes. Blocks
    // repeated taps from creating duplicate orders.
    var isSaving by remember { mutableStateOf(false) }

    val defaultPricePerDozen = stock?.pricePerDozen ?: 0.0
    val dozens = dozensText.toDoubleOrNull() ?: 0.0
    val kg = kgText.toDoubleOrNull() ?: 0.0
    // Stored quantity: dozens x 12 packets (0 when no dozens given).
    val packets = dozensToPackets(dozens)
    val paid = paidText.toDoubleOrNull() ?: 0.0
    // If the user has not typed a price, use the stock price; otherwise use theirs.
    val pricePerDozen = if (priceEdited) (priceText.toDoubleOrNull() ?: defaultPricePerDozen) else defaultPricePerDozen
    // KG orders have their own price per KG (no stock default).
    val pricePerKg = kgPriceText.toDoubleOrNull() ?: 0.0
    // Per-packet price is kept for storage; totals match the repository (packets x unitPrice).
    // KG part totals as KG x price-per-KG; dozen part as packets x unitPrice.
    val unitPrice = if (dozens > 0) pricePerDozen / 12.0 else 0.0
    val total = packets * unitPrice + kg * pricePerKg
    val remaining = total - paid
    // Unit for this order: "both" when dozens and KG are both given.
    val unit = if (dozens > 0 && kg > 0) UNIT_BOTH else if (kg > 0) UNIT_KG else UNIT_DOZEN
    // Profit in this order, matching the repository: (packets / 12) * profit per dozen.
    // KG part earns no profit (no profit-per-KG setting exists); profit comes from dozens only.
    val orderProfit = (packets / 12.0) * (stock?.profitPerDozen ?: 0.0)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Add Customer") },
                navigationIcon = {
                    IconButton(onClick = onBack, enabled = !isSaving) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("Name *") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = location, onValueChange = { location = it },
                label = { Text("Location *") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = phone, onValueChange = { phone = it },
                label = { Text("Phone (optional)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text("Dozens (packets) — kitne dozen diye?", style = MaterialTheme.typography.bodyMedium)
            OutlinedTextField(
                value = dozensText, onValueChange = { dozensText = it },
                label = { Text("Dozens purchased") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            if (dozens > 0) {
                Text(
                    "${formatDozensValue(dozens)} dozen = $packets packets (1 dozen = 12 packets).",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            OutlinedTextField(
                value = if (priceEdited) priceText else if (defaultPricePerDozen > 0) defaultPricePerDozen.toString() else "",
                onValueChange = { priceText = it; priceEdited = true },
                label = { Text("Price per dozen (Rs) — stock se auto, yahan change kar sakte hain") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Stock price: Rs ${stock?.pricePerDozen?.toInt() ?: 0} per dozen " +
                    "(Rs ${String.format("%.2f", stock?.pricePerPacket ?: 0.0)} per packet). " +
                    "Upar wali price change kar dein to is order par wahi price lagegi.",
                style = MaterialTheme.typography.bodySmall
            )
            Text("KG (khula) — kitne KG diye?", style = MaterialTheme.typography.bodyMedium)
            OutlinedTextField(
                value = kgText, onValueChange = { kgText = it },
                label = { Text("KG purchased") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            if (kg > 0) {
                Text(
                    "${formatKgValue(kg)} KG.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            OutlinedTextField(
                value = kgPriceText, onValueChange = { kgPriceText = it },
                label = { Text("Price per KG (Rs)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "KG ki price yahan likhein — ye stock price se nahi aati, har KG order ki apni price hoti hai.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedTextField(
                value = paidText, onValueChange = { paidText = it },
                label = { Text("Amount Paid (Rs) *") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Live totals — auto calculated as the user types.
            Text("Total Bill: Rs ${String.format("%.2f", total)}", style = MaterialTheme.typography.titleMedium)
            Text("Remaining: Rs ${String.format("%.2f", remaining)}", style = MaterialTheme.typography.titleMedium)
            if (dozens == 0.0 && kg > 0) {
                Text(
                    "KG wali sale ka profit nahi gina jata aur stock se kuch deduct nahi hota.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            } else {
                Text(
                    "Profit in this order: Rs ${String.format("%.2f", orderProfit)}",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (error.isNotEmpty()) {
                Text(error, color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(4.dp))
            Button(
                onClick = {
                    if (isSaving) return@Button
                    if (name.isBlank() || location.isBlank()) {
                        error = "Name aur Location zaroori hain."
                        return@Button
                    }
                    if (dozens <= 0 && kg <= 0) {
                        error = "Dozens ya KG mein se kam se kam aik (0 se zyada) zaroori hai."
                        return@Button
                    }
                    if (kg > 0 && pricePerKg <= 0) {
                        error = "KG likha hai to Price per KG (0 se zyada) zaroori hai."
                        return@Button
                    }
                    isSaving = true
                    error = ""
                    val ownerUid = viewModel.profile.value?.uid ?: ""
                    viewModel.addCustomer(
                        Customer(
                            name = name.trim(),
                            location = location.trim(),
                            phone = phone.trim(),
                            packets = packets,
                            unitPrice = unitPrice,
                            unit = unit,
                            kgQuantity = kg,
                            pricePerKg = pricePerKg,
                            total = total,
                            paid = paid,
                            remaining = remaining,
                            paidDate = System.currentTimeMillis(),
                            orderProfit = orderProfit,
                            ownerUid = ownerUid
                        ),
                        onDone = { onSaved() },
                        onError = {
                            isSaving = false
                            error = "Save nahi ho saka. Dobara try karein."
                        }
                    )
                },
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (isSaving) "Saving..." else "Save")
            }
            Text(
                "Save karte hi total sale amount mein add ho jayega — dozen wale packets stock se deduct ho jayenge, KG wale nahi. Save ke baad screen khud band ho jayegi.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
