package com.brinto.khata.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.brinto.khata.data.Customer
import com.brinto.khata.ui.KhataViewModel
import com.brinto.khata.util.ImageUtils
import java.io.File

/**
 * Add Customer (Khata entry) form.
 * Required: Name, Location, Packets, Amount Paid.
 * Optional: Phone, Photo.
 * Total = packets * unit price. Remaining = total - paid (auto).
 * Unit price defaults to stock price-per-6 / 6, but can be overridden
 * for this order (discount / lower price) — the order keeps its own price.
 * Photo: camera icon = take photo, + icon = gallery, images only.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddCustomerScreen(viewModel: KhataViewModel, onBack: () -> Unit, onSaved: () -> Unit) {
    val context = LocalContext.current
    val stock by viewModel.stock.collectAsState()

    var name by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var packetsText by remember { mutableStateOf("") }
    var paidText by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("") }
    var priceEdited by remember { mutableStateOf(false) }
    var photoPath by remember { mutableStateOf("") }
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    var error by remember { mutableStateOf("") }
    var permissionNote by remember { mutableStateOf("") }

    val defaultUnitPrice = stock?.pricePerPacket ?: 0.0
    val packets = packetsText.toIntOrNull() ?: 0
    val paid = paidText.toDoubleOrNull() ?: 0.0
    // If the user has not typed a price, use the stock price; otherwise use theirs.
    val unitPrice = if (priceEdited) (priceText.toDoubleOrNull() ?: defaultUnitPrice) else defaultUnitPrice
    val total = packets * unitPrice
    val remaining = total - paid

    var cameraFile by remember { mutableStateOf<File?>(null) }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            // "image/*" only — see the launcher call below.
            ImageUtils.copyImageToInternalStorage(context, uri)?.let { photoPath = it }
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success: Boolean ->
        if (success) {
            cameraFile?.let { photoPath = it.absolutePath }
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted: Boolean ->
        if (granted) {
            val file = ImageUtils.createCameraImageFile(context)
            cameraFile = file
            val uri = FileProvider.getUriForFile(
                context, "com.brinto.khata.fileprovider", file
            )
            photoUri = uri
            cameraLauncher.launch(uri)
        } else {
            permissionNote = "Camera permission ke baghair photo nahi le sakte. Settings se Camera allow karein."
        }
    }

    val galleryPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted: Boolean ->
        if (granted) {
            galleryLauncher.launch("image/*")
        } else {
            // Android 13+ (API 33+) does not need READ_MEDIA_IMAGES for the
            // system photo picker, but on older phones this permission is needed.
            galleryLauncher.launch("image/*")
        }
    }

    fun requestCamera() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            val file = ImageUtils.createCameraImageFile(context)
            cameraFile = file
            val uri = FileProvider.getUriForFile(
                context, "com.brinto.khata.fileprovider", file
            )
            photoUri = uri
            cameraLauncher.launch(uri)
        } else {
            permissionNote = "Camera se photo lene ke liye Camera permission chahiye."
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    fun requestGallery() {
        val permission = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (ContextCompat.checkSelfPermission(context, permission) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            galleryLauncher.launch("image/*")
        } else {
            permissionNote = "Gallery se photo chunne ke liye gallery / photos permission chahiye. Sirf images allowed hain."
            galleryPermissionLauncher.launch(permission)
        }
    }

    if (permissionNote.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { permissionNote = "" },
            title = { Text("Permission") },
            text = { Text(permissionNote) },
            confirmButton = {
                TextButton(onClick = { permissionNote = "" }) { Text("OK") }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Add Customer") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("Name *") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = location, onValueChange = { location = it },
                label = { Text("Location *") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = phone, onValueChange = { phone = it },
                label = { Text("Phone (optional)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = packetsText, onValueChange = { packetsText = it },
                label = { Text("Packets purchased *") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = if (priceEdited) priceText else if (defaultUnitPrice > 0) defaultUnitPrice.toString() else "",
                onValueChange = { priceText = it; priceEdited = true },
                label = { Text("Price per packet (Rs) — stock se auto, yahan change kar sakte hain") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Stock price: Rs ${String.format("%.2f", defaultUnitPrice)} per packet " +
                    "(Rs ${stock?.pricePer6Packets?.toInt() ?: 0} per 6 packets). " +
                    "Upar wali price change kar dein to is order par wahi price lagegi.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedTextField(
                value = paidText, onValueChange = { paidText = it },
                label = { Text("Amount Paid (Rs) *") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Live totals — auto calculated as the user types.
            Text("Total Bill: Rs ${String.format("%.2f", total)}", style = MaterialTheme.typography.titleMedium)
            Text("Remaining: Rs ${String.format("%.2f", remaining)}", style = MaterialTheme.typography.titleMedium)

            // Photo: camera icon + gallery (+) icon, images only.
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (photoPath.isNotBlank()) {
                    AsyncImage(
                        model = File(photoPath),
                        contentDescription = "Customer photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(72.dp).clip(CircleShape)
                    )
                }
                Spacer(Modifier.size(12.dp))
                OutlinedButton(onClick = { requestCamera() }) {
                    Icon(Icons.Default.CameraAlt, contentDescription = "Camera")
                    Text(" Camera")
                }
                Spacer(Modifier.size(8.dp))
                OutlinedButton(onClick = { requestGallery() }) {
                    Icon(Icons.Default.Add, contentDescription = "Gallery")
                    Text(" + Gallery")
                }
            }
            Text(
                "Photo optional hai — location / dukaan yaad rakhne ke liye. Sirf images allowed hain.",
                style = MaterialTheme.typography.bodySmall
            )

            if (error.isNotEmpty()) {
                Text(error, color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(4.dp))
            Button(
                onClick = {
                    if (name.isBlank() || location.isBlank() || packets <= 0) {
                        error = "Name, Location aur Packets (0 se zyada) zaroori hain."
                        return@Button
                    }
                    val ownerUid = viewModel.profile.value?.uid ?: ""
                    viewModel.addCustomer(
                        Customer(
                            name = name.trim(),
                            location = location.trim(),
                            phone = phone.trim(),
                            packets = packets,
                            unitPrice = unitPrice,
                            total = total,
                            paid = paid,
                            remaining = remaining,
                            photoPath = photoPath,
                            ownerUid = ownerUid
                        )
                    ) { onSaved() }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save")
            }
            Text(
                "Save karte hi stock se $packets packets deduct ho jayenge aur sale total mein add ho jayega.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
