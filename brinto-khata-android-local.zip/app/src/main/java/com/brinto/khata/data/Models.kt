package com.brinto.khata.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One khata entry = one wholesaler customer + one order.
 *
 * total    = packets * unitPrice   (unitPrice = price-per-dozen / 12, unless
 *                                   the price was overridden for this order)
 * remaining = total - paid
 */
@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val name: String = "",
    val location: String = "",
    val phone: String = "",
    val packets: Int = 0,
    /** Price charged for ONE packet on this order (Rs). */
    val unitPrice: Double = 0.0,
    val total: Double = 0.0,
    val paid: Double = 0.0,
    val remaining: Double = 0.0,
    /** Local file path of the customer photo (empty = no photo). */
    val photoPath: String = "",
    val ownerUid: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any> = mapOf(
        "id" to id,
        "name" to name,
        "location" to location,
        "phone" to phone,
        "packets" to packets,
        "unitPrice" to unitPrice,
        "total" to total,
        "paid" to paid,
        "remaining" to remaining,
        "photoPath" to photoPath,
        "ownerUid" to ownerUid,
        "createdAt" to createdAt
    )

    companion object {
        fun fromMap(map: Map<String, Any>): Customer = Customer(
            id = map["id"] as? String ?: java.util.UUID.randomUUID().toString(),
            name = map["name"] as? String ?: "",
            location = map["location"] as? String ?: "",
            phone = map["phone"] as? String ?: "",
            packets = (map["packets"] as? Number)?.toInt() ?: 0,
            unitPrice = (map["unitPrice"] as? Number)?.toDouble() ?: 0.0,
            total = (map["total"] as? Number)?.toDouble() ?: 0.0,
            paid = (map["paid"] as? Number)?.toDouble() ?: 0.0,
            remaining = (map["remaining"] as? Number)?.toDouble() ?: 0.0,
            photoPath = map["photoPath"] as? String ?: "",
            ownerUid = map["ownerUid"] as? String ?: "",
            createdAt = (map["createdAt"] as? Number)?.toLong() ?: 0L
        )
    }
}

/** Single-row stock settings. Kept in Room (id = 0) and in Firestore. */
@Entity(tableName = "stock")
data class StockSettings(
    @PrimaryKey val id: Int = 0,
    val packetsInStock: Int = 0,
    /** Master price for one dozen (12 packets) (Rs). Per-packet price = this / 12. */
    val pricePerDozen: Double = 0.0,
    val totalPacketsSold: Int = 0,
    val totalSalesAmount: Double = 0.0
) {
    val pricePerPacket: Double get() = if (pricePerDozen > 0) pricePerDozen / 12.0 else 0.0

    fun toMap(): Map<String, Any> = mapOf(
        "packetsInStock" to packetsInStock,
        "pricePerDozen" to pricePerDozen,
        "totalPacketsSold" to totalPacketsSold,
        "totalSalesAmount" to totalSalesAmount
    )

    companion object {
        fun fromMap(map: Map<String, Any>): StockSettings = StockSettings(
            packetsInStock = (map["packetsInStock"] as? Number)?.toInt() ?: 0,
            pricePerDozen = (map["pricePerDozen"] as? Number)?.toDouble() ?: 0.0,
            totalPacketsSold = (map["totalPacketsSold"] as? Number)?.toInt() ?: 0,
            totalSalesAmount = (map["totalSalesAmount"] as? Number)?.toDouble() ?: 0.0
        )
    }
}

/** A user account. The FIRST registered user is Admin. */
data class UserProfile(
    val uid: String = "",
    val email: String = "",
    val role: String = "user" // "admin" or "user"
) {
    fun toMap(): Map<String, Any> = mapOf(
        "uid" to uid, "email" to email, "role" to role
    )

    companion object {
        fun fromMap(map: Map<String, Any>): UserProfile = UserProfile(
            uid = map["uid"] as? String ?: "",
            email = map["email"] as? String ?: "",
            role = map["role"] as? String ?: "user"
        )
    }
}
