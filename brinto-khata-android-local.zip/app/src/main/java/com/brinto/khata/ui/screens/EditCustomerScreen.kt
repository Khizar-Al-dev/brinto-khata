package com.brinto.khata.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.brinto.khata.data.UNIT_DOZEN
import com.brinto.khata.data.UNIT_BOTH
import com.brinto.khata.data.UNIT_KG
import com.brinto.khata.ui.KhataViewModel
import com.brinto.khata.util.dozensToPackets
import com.brinto.khata.util.formatDozens
import com.brinto.khata.util.formatDozensValue
import com.brinto.khata.util.formatKgValue

/**
 * Edit Order — opened from the Customer Detail screen's three-dots
 * menu ("Edit order") or from the Home long-press menu. Same layout as
 * AddCustomerScreen, pre-filled with the existing customer's data:
 * info fields first, then Total /
 * Remaining calculation and "Profit in this order". Quantity is
 * entered in DOZENS (1 dozen = 12 packets) and stored as packets,
 * and/or in KG with its own price per KG — one order can carry
 * both. KG part never touches the dozen stock and earns no profit.
 * Changing quantity / price / paid
 * live-updates the totals. "Update"
 * saves the edited order: total, remaining and profit are recomputed,
 * stock is adjusted for the difference only, and an UPDATED event is
 * written to History. Update runs only once: the button is disabled
 * while updating, and on success the screen closes automatically.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditCustomerScreen(
    viewModel: KhataViewModel,
    customerId: String,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val stock by viewModel.stock.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val customer = customers.firstOrNull { it.id == customerId }

    // Pre-filled from the existing customer. remember(customer) resets
    // the fields if a different customer is opened.
    var name by remember(customer) { mutableStateOf(customer?.name ?: "") }
    var location by remember(customer) { mutableStateOf(customer?.location ?: "") }
    var phone by remember(customer) { mutableStateOf(customer?.phone ?: "") }
    var dozensText by remember(customer) { mutableStateOf(customer?.let { if (it.packets > 0) formatDozens(it.packets) else "" } ?: "") }
    var kgText by remember(customer) {
        mutableStateOf(customer?.let { if (it.kgQuantity > 0) formatKgValue(it.kgQuantity) else "" } ?: "")
    }
    var kgPriceText by remember(customer) {
        mutableStateOf(
            customer?.let {
                if (it.kgQuantity > 0) {
                    if (it.pricePerKg % 1.0 == 0.0) it.pricePerKg.toInt().toString() else it.pricePerKg.toString()
                } else ""
            } ?: ""
        )
    }
    var paidText by remember(customer) { mutableStateOf(customer?.paid?.let { if (it % 1.0 == 0.0) it.toInt().toString() else it.toString() } ?: "") }
    var priceText by remember(customer) {
        mutableStateOf(
            customer?.let {
                if (it.packets > 0) {
                    val perDozen = it.unitPrice * 12.0
                    if (perDozen % 1.0 == 0.0) perDozen.toInt().toString() else perDozen.toString()
                } else ""
            } ?: ""
        )
    }
    var error by remember { mutableStateOf("") }
    // True from the first Update tap until the update finishes. Blocks
    // repeated taps from writing duplicate UPDATED events / stock moves.
    var isUpdating by remember { mutableStateOf(false) }

    val defaultPricePerDozen = stock?.pricePerDozen ?: 0.0
    val dozens = dozensText.toDoubleOrNull() ?: 0.0
    val kg = kgText.toDoubleOrNull() ?: 0.0
    val packets = dozensToPackets(dozens)
    val paid = paidText.toDoubleOrNull() ?: 0.0
    val pricePerDozen = priceText.toDoubleOrNull() ?: defaultPricePerDozen
    val pricePerKg = kgPriceText.toDoubleOrNull() ?: 0.0
    val unitPrice = if (dozens > 0) pricePerDozen / 12.0 else 0.0
    val total = packets * unitPrice + kg * pricePerKg
    val remaining = total - paid
    // Unit for this order: "both" when dozens and KG are both given.
    val unit = if (dozens > 0 && kg > 0) UNIT_BOTH else if (kg > 0) UNIT_KG else UNIT_DOZEN
    // Profit in this order, matching the repository: (packets / 12) * profit per dozen.
    // KG part earns no profit (no profit-per-KG setting exists); profit comes from dozens only.
    val orderProfit = (packets / 12.0) * (stock?.profitPerDozen ?: 0.0)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Edit Order") },
                navigationIcon = {
                    IconButton(onClick = onBack, enabled = !isUpdating) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        if (customer == null) {
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Customer not found — ye customer delete ho chuka ho sakta hai.")
            }
        } else {
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("Name *") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = location, onValueChange = { location = it },
                label = { Text("Location *") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = phone, onValueChange = { phone = it },
                label = { Text("Phone (optional)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text("Dozens (packets) — kitne dozen diye?", style = MaterialTheme.typography.bodyMedium)
            OutlinedTextField(
                value = dozensText, onValueChange = { dozensText = it },
                label = { Text("Dozens purchased") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            if (dozens > 0) {
                Text(
                    "${formatDozensValue(dozens)} dozen = $packets packets (1 dozen = 12 packets).",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            OutlinedTextField(
                value = priceText, onValueChange = { priceText = it },
                label = { Text("Price per dozen (Rs) — stock se auto, yahan change kar sakte hain") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Stock price: Rs ${stock?.pricePerDozen?.toInt() ?: 0} per dozen " +
                    "(Rs ${String.format("%.2f", stock?.pricePerPacket ?: 0.0)} per packet). " +
                    "Upar wali price change kar dein to is order par wahi price lagegi.",
                style = MaterialTheme.typography.bodySmall
            )
            Text("KG (khula) — kitne KG diye?", style = MaterialTheme.typography.bodyMedium)
            OutlinedTextField(
                value = kgText, onValueChange = { kgText = it },
                label = { Text("KG purchased") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            if (kg > 0) {
                Text(
                    "${formatKgValue(kg)} KG.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            OutlinedTextField(
                value = kgPriceText, onValueChange = { kgPriceText = it },
                label = { Text("Price per KG (Rs)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "KG ki price yahan likhein — ye stock price se nahi aati, har KG order ki apni price hoti hai.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedTextField(
                value = paidText, onValueChange = { paidText = it },
                label = { Text("Amount Paid (Rs) *") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Live totals — auto calculated as the user types.
            Text("Total Bill: Rs ${String.format("%.2f", total)}", style = MaterialTheme.typography.titleMedium)
            Text("Remaining: Rs ${String.format("%.2f", remaining)}", style = MaterialTheme.typography.titleMedium)
            if (dozens == 0.0 && kg > 0) {
                Text(
                    "KG wali sale ka profit nahi gina jata aur stock se kuch deduct nahi hota.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            } else {
                Text(
                    "Profit in this order: Rs ${String.format("%.2f", orderProfit)}",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (error.isNotEmpty()) {
                Text(error, color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(4.dp))
            Button(
                onClick = {
                    if (isUpdating) return@Button
                    if (name.isBlank() || location.isBlank()) {
                        error = "Name aur Location zaroori hain."
                        return@Button
                    }
                    if (dozens <= 0 && kg <= 0) {
                        error = "Dozens ya KG mein se kam se kam aik (0 se zyada) zaroori hai."
                        return@Button
                    }
                    if (kg > 0 && pricePerKg <= 0) {
                        error = "KG likha hai to Price per KG (0 se zyada) zaroori hai."
                        return@Button
                    }
                    isUpdating = true
                    error = ""
                    // paidDate / createdAt are handled by the repository:
                    // paidDate changes only if the paid amount changed,
                    // createdAt never changes. An UPDATED event is logged
                    // to History with the new values and today's date.
                    viewModel.updateCustomer(
                        customer.copy(
                            name = name.trim(),
                            location = location.trim(),
                            phone = phone.trim(),
                            packets = packets,
                            unitPrice = unitPrice,
                            unit = unit,
                            kgQuantity = kg,
                            pricePerKg = pricePerKg,
                            total = total,
                            paid = paid,
                            remaining = remaining,
                            orderProfit = orderProfit
                        ),
                        onDone = { onSaved() },
                        onError = {
                            isUpdating = false
                            error = "Update nahi ho saka. Dobara try karein."
                        }
                    )
                },
                enabled = !isUpdating,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (isUpdating) "Updating..." else "Update")
            }
            Text(
                "Update karte hi total sale amount ke farq ke hisaab se adjust ho jayega — dozen wale packets stock se adjust ho jayenge, KG wale nahi — aur History mein UPDATED event save ho jayega. Update ke baad screen khud band ho jayegi.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        }
    }
}
