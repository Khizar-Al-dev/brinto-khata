package com.brinto.khata

import android.app.Application
import com.brinto.khata.data.AppDatabase

/**
 * Application class: creates the Room database once and keeps it
 * available for the whole app (offline cache / fallback).
 */
class BrintoKhataApp : Application() {
    val database: AppDatabase by lazy {
        AppDatabase.getInstance(this)
    }
}
