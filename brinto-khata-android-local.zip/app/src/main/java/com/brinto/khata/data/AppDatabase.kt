package com.brinto.khata.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY createdAt DESC")
    fun getAll(): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE remaining > 0 ORDER BY createdAt DESC")
    fun getUdhaar(): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun getById(id: String): Customer?

    /** Whole table in one shot — used by cloud sync (push then pull). */
    @Query("SELECT * FROM customers")
    suspend fun getAllOnce(): List<Customer>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(customer: Customer)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(customers: List<Customer>)

    @Update
    suspend fun update(customer: Customer)

    @Query("DELETE FROM customers WHERE id = :id")
    suspend fun deleteById(id: String)

    /** Clear the whole table — used by the cloud sync replace step. */
    @Query("DELETE FROM customers")
    suspend fun deleteAll()
}

@Dao
interface StockDao {
    @Query("SELECT * FROM stock WHERE id = 0")
    fun getStock(): Flow<StockSettings?>

    @Query("SELECT * FROM stock WHERE id = 0")
    suspend fun getStockOnce(): StockSettings?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(stock: StockSettings)

    /** Clear the stock row — used by the cloud sync replace step. */
    @Query("DELETE FROM stock")
    suspend fun clear()
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history ORDER BY eventDate DESC")
    fun getAll(): Flow<List<HistoryEvent>>

    /** Whole table in one shot — used by cloud sync (push then pull). */
    @Query("SELECT * FROM history")
    suspend fun getAllOnce(): List<HistoryEvent>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(event: HistoryEvent)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(events: List<HistoryEvent>)

    /** Clear the whole table — used by the cloud sync replace step. */
    @Query("DELETE FROM history")
    suspend fun deleteAll()
}

@Database(
    entities = [Customer::class, StockSettings::class, HistoryEvent::class],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun customerDao(): CustomerDao
    abstract fun stockDao(): StockDao
    abstract fun historyDao(): HistoryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "brinto_khata.db"
                )
                    // Schema changes (per-dozen price, history table,
                    // new customer fields, KG unit) clear old test data
                    // on upgrade. Cloud sync restores the data afterwards.
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
    }
}
