package com.brinto.khata.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY createdAt DESC")
    fun getAll(): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE remaining > 0 ORDER BY createdAt DESC")
    fun getUdhaar(): Flow<List<Customer>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(customer: Customer)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(customers: List<Customer>)

    @Query("DELETE FROM customers WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface StockDao {
    @Query("SELECT * FROM stock WHERE id = 0")
    fun getStock(): Flow<StockSettings?>

    @Query("SELECT * FROM stock WHERE id = 0")
    suspend fun getStockOnce(): StockSettings?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(stock: StockSettings)
}

@Database(entities = [Customer::class, StockSettings::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun customerDao(): CustomerDao
    abstract fun stockDao(): StockDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "brinto_khata.db"
                ).build().also { INSTANCE = it }
            }
    }
}
