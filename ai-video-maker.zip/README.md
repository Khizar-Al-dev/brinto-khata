# AI Video Maker

Free AI image + video maker app (Android WebView wrapper, `com.aivideo.maker`).

The start page (`app/src/main/assets/start.html`) links to free services:
- Wan 2.1 video generation (SweetPrompt, free shared GPU, no signup)
- Wan 2.2 video generation (wan2.video, free, no signup)
- Free AI image generation (Pollinations)

Push the zip to GitHub to build the debug APK with GitHub Actions.
