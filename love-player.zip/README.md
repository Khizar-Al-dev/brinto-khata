# Love Player

Chota sa video player — "Videos Chuno" se apni videos select karo, phir
"Shuffle All" dabao: saari videos random order mein aik ke baad aik
khud chalti rahengi. Aik khatam hote hi agli direct lag jati hai.

- Package: com.love.player
- Start page: app/src/main/assets/player.html (offline, koi internet nahi chahiye)
- Logo: dil + play button (app/src/main/assets/logo.png, launcher icon mipmap)
- MP3 style player: app ke upar aik chhota player bar hai (title +
  timeline/seek bar + waqt + play/pause/next/prev); notification mein
  bhi media player aata hai (MediaSession + framework MediaStyle) —
  timeline chalti hai, lock screen aur notification se control hota hai.
  Background playback: PlaybackService (foreground service) + PiP
  floating window (Home dabate hi chhoti window ban jati hai).
