# Love Player

Chota sa video player — "Videos Chuno" se apni videos select karo, phir
"Shuffle All" dabao: saari videos random order mein aik ke baad aik
khud chalti rahengi. Aik khatam hote hi agli direct lag jati hai.

- Package: com.love.player
- Start page: app/src/main/assets/player.html (offline, koi internet nahi chahiye)
- Logo: dil + play button (app/src/main/assets/logo.png, launcher icon mipmap)
- File chooser: MainActivity mein WebChromeClient.onShowFileChooser — isi se
  phone ki gallery/storage se videos select hoti hain.
