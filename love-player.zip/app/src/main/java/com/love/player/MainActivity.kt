package com.love.player

import android.Manifest
import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/**
 * Love Player: a WebView wrapper around assets/player.html.
 * The file chooser support below is what makes the "Videos Chuno"
 * button work — without onShowFileChooser the <input type="file">
 * in the page would do nothing.
 */
class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var isPlaying = false

    private val pickFiles = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris: Array<Uri>? = when {
            result.resultCode != RESULT_OK -> null
            result.data?.clipData != null -> {
                val clip = result.data!!.clipData!!
                Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
            }
            result.data?.data != null -> arrayOf(result.data!!.data!!)
            else -> null
        }
        filePathCallback?.onReceiveValue(uris)
        filePathCallback = null
    }

    private val requestNotificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* denied bhi ho to service chalti hai; notification system dikhata hai */ }

    /**
     * Page se bridge: player.html playback shuru hote hi
     * startBackground() aur rukte hi stopBackground() bulata hai.
     */
    inner class PlayerBridge {
        @JavascriptInterface
        fun startBackground() {
            val intent = Intent(this@MainActivity, PlaybackService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        }

        @JavascriptInterface
        fun stopBackground() {
            val intent = Intent(this@MainActivity, PlaybackService::class.java).apply {
                action = PlaybackService.ACTION_STOP
            }
            startService(intent)
        }

        /**
         * Page batata hai video chal rahi hai ya ruki — PiP isi par
         * chalta hai: chal rahi ho to Home dabate hi chhoti floating
         * window ban jati hai, ruki ho to nahi.
         */
        @JavascriptInterface
        fun setPlaying(playing: Boolean) {
            isPlaying = playing
            updatePipParams()
        }

        /**
         * Page har 2 second mein position bhejta hai — MediaSession /
         * notification ki timeline isi se chalti hai.
         */
        @JavascriptInterface
        fun updatePosition(posMs: Long, durMs: Long, playing: Boolean, title: String) {
            PlaybackService.updatePlayback(
                this@MainActivity, title, posMs, durMs, playing
            )
        }
    }

    /** Notification / lock screen se aane wale play/pause/next/prev/seek. */
    private val controlReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (!::webView.isInitialized) return
            val cmd = intent?.getStringExtra("cmd") ?: return
            val js = when (cmd) {
                "toggle" -> "var p=document.getElementById('player');" +
                    "if(p.paused){p.play()}else{p.pause()}"
                "play" -> "document.getElementById('player').play()"
                "pause" -> "document.getElementById('player').pause()"
                "next" -> "next()"
                "prev" -> "prev()"
                "seek" -> "document.getElementById('player').currentTime=" +
                    (intent.getLongExtra("pos", 0L) / 1000.0)
                else -> return
            }
            webView.evaluateJavascript(js, null)
        }
    }

    /** API 31+: Home dabate hi auto PiP (sirf jab video chal rahi ho). */
    private fun updatePipParams() {
        if (Build.VERSION.SDK_INT >= 31) {
            setPictureInPictureParams(
                PictureInPictureParams.Builder()
                    .setAutoEnterEnabled(isPlaying)
                    .build()
            )
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
        ) {
            requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        webView = WebView(this)
        setContentView(webView)
        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.allowUniversalAccessFromFileURLs = true
        settings.allowFileAccessFromFileURLs = true
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(PlayerBridge(), "LovePlayer")
        val controlFilter = IntentFilter(PlaybackService.CONTROL_ACTION)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(controlReceiver, controlFilter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(controlReceiver, controlFilter)
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback
                val intent = fileChooserParams.createIntent()
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                return try {
                    pickFiles.launch(intent)
                    true
                } catch (e: Exception) {
                    this@MainActivity.filePathCallback = null
                    false
                }
            }
        }
        webView.loadUrl("file:///android_asset/player.html")
    }

    override fun onDestroy() {
        try { unregisterReceiver(controlReceiver) } catch (e: Exception) { }
        super.onDestroy()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Home ya doosri app par jate waqt: video chal rahi ho to
        // chhoti floating (Picture-in-Picture) window mein chali jaye.
        if (isPlaying && Build.VERSION.SDK_INT >= 26) {
            enterPictureInPictureMode()
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        // PiP window mein sirf video dikhao — header, buttons aur
        // playlist chhupa do; wapas aane par sab wapas dikhao.
        val js = if (isInPictureInPictureMode) {
            "document.body.classList.add('pip')"
        } else {
            "document.body.classList.remove('pip')"
        }
        if (::webView.isInitialized) webView.evaluateJavascript(js, null)
    }

    override fun onPause() {
        super.onPause()
        // WebView ko yahan pause NA karo — webView.onPause() bulane se
        // background playback ruk jata hai. PlaybackService app ko
        // foreground mein rakhta hai, isliye media chalta rehta hai.
    }

    override fun onResume() {
        super.onResume()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
