package com.love.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder

/**
 * Background playback + MP3 style media notification.
 *
 * Page har 2 second mein updatePosition() bulata hai (position, duration,
 * playing, title) — us se MediaSession ki state update hoti hai, aur
 * notification (upar wala media player) mein timeline / seek bar chalti
 * hai, Play/Pause/Next/Prev ke saath. Notification ya lock screen se
 * dabaye gaye buttons MainActivity ko broadcast se milte hain.
 *
 * Note: androidx.core ka NotificationCompat.MediaStyle ab nahi raha
 * (core 1.13 mein hata diya gaya), isliye framework ka
 * Notification.MediaStyle + Notification.Builder use ho raha hai.
 */
class PlaybackService : Service() {
    companion object {
        const val CHANNEL_ID = "love_player_playback"
        const val NOTIFICATION_ID = 1
        const val ACTION_STOP = "com.love.player.STOP"
        const val ACTION_TOGGLE = "com.love.player.TOGGLE"
        const val ACTION_NEXT = "com.love.player.NEXT"
        const val ACTION_PREV = "com.love.player.PREV"
        const val CONTROL_ACTION = "com.love.player.CONTROL"

        private var session: MediaSession? = null
        private var nowTitle = "Love Player"
        private var nowPlaying = false
        private var nowPos = 0L
        private var nowDur = 0L

        @Volatile
        private var runningService: PlaybackService? = null

        /**
         * Page se aata hai (chalte hue har 2 second): MediaSession ki
         * state + notification refresh karo taake timeline chalti rahe.
         */
        fun updatePlayback(
            context: Context,
            title: String,
            posMs: Long,
            durMs: Long,
            playing: Boolean
        ) {
            if (title.isNotEmpty()) nowTitle = title
            nowPos = posMs
            nowDur = durMs
            nowPlaying = playing
            val s = session ?: return
            s.setMetadata(
                MediaMetadata.Builder()
                    .putString(MediaMetadata.METADATA_KEY_TITLE, nowTitle)
                    .putString(MediaMetadata.METADATA_KEY_ARTIST, "Love Player")
                    .putLong(MediaMetadata.METADATA_KEY_DURATION, nowDur)
                    .build()
            )
            s.setPlaybackState(
                PlaybackState.Builder()
                    .setState(
                        if (playing) PlaybackState.STATE_PLAYING
                        else PlaybackState.STATE_PAUSED,
                        nowPos, 1.0f
                    )
                    .setActions(
                        PlaybackState.ACTION_PLAY_PAUSE or
                            PlaybackState.ACTION_PLAY or
                            PlaybackState.ACTION_PAUSE or
                            PlaybackState.ACTION_SKIP_TO_NEXT or
                            PlaybackState.ACTION_SKIP_TO_PREVIOUS or
                            PlaybackState.ACTION_SEEK_TO
                    )
                    .build()
            )
            s.isActive = true
            runningService?.startForeground(NOTIFICATION_ID, runningService!!.buildNotification())
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        runningService = this
        if (session == null) {
            session = MediaSession(this, "LovePlayer").apply {
                setCallback(object : MediaSession.Callback() {
                    override fun onPlay() = sendControl("play")
                    override fun onPause() = sendControl("pause")
                    override fun onSkipToNext() = sendControl("next")
                    override fun onSkipToPrevious() = sendControl("prev")
                    override fun onSeekTo(pos: Long) = sendControl("seek", pos)
                })
            }
        }
    }

    override fun onDestroy() {
        runningService = null
        super.onDestroy()
    }

    private fun sendControl(cmd: String, pos: Long = 0L) {
        sendBroadcast(Intent(CONTROL_ACTION).apply {
            putExtra("cmd", cmd)
            putExtra("pos", pos)
            setPackage(packageName)
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                session?.isActive = false
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE -> sendControl("toggle")
            ACTION_NEXT -> sendControl("next")
            ACTION_PREV -> sendControl("prev")
        }
        startForeground(NOTIFICATION_ID, buildNotification())
        return START_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Love Player playback",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Love Player background mein chal raha hai" }
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun actionIntent(action: String): PendingIntent {
        val intent = Intent(this, PlaybackService::class.java).apply {
            this.action = action
        }
        return PendingIntent.getService(
            this, action.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(nowTitle)
            .setContentText(
                if (nowPlaying) "Chal rahi hai — Love Player"
                else "Ruki hui hai — Love Player"
            )
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(openPending)
            .addAction(
                Notification.Action.Builder(
                    android.R.drawable.ic_media_previous, "Pehle",
                    actionIntent(ACTION_PREV)
                ).build()
            )
            .addAction(
                Notification.Action.Builder(
                    if (nowPlaying) android.R.drawable.ic_media_pause
                    else android.R.drawable.ic_media_play,
                    if (nowPlaying) "Ruko" else "Chalao",
                    actionIntent(ACTION_TOGGLE)
                ).build()
            )
            .addAction(
                Notification.Action.Builder(
                    android.R.drawable.ic_media_next, "Agli",
                    actionIntent(ACTION_NEXT)
                ).build()
            )
            .addAction(
                Notification.Action.Builder(
                    android.R.drawable.ic_media_pause, "Stop",
                    actionIntent(ACTION_STOP)
                ).build()
            )
            .setOngoing(true)
        session?.let {
            builder.setStyle(
                Notification.MediaStyle()
                    .setMediaSession(it.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2)
            )
        }
        return builder.build()
    }
}
