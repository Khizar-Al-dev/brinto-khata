package com.aistudio.offline.data

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL

/**
 * Downloads model files from Hugging Face (free, no key, no account)
 * with progress + pause/resume (HTTP Range). After the first download
 * the app never needs the network again.
 *
 * Each model lives in filesDir/models/<dirName>/ and each file is
 * downloaded to "<fileName>.part" first, then renamed on completion.
 */
class ModelDownloader(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.IO)
    private val jobs = mutableMapOf<String, Job>()

    private val _progress = mutableMapOf<String, MutableStateFlow<DownloadProgress>>()
    fun progressOf(modelId: String): StateFlow<DownloadProgress> =
        _progress.getOrPut(modelId) {
            MutableStateFlow(DownloadProgress(DownloadStatus.NOT_DOWNLOADED))
        }.asStateFlow()

    fun modelsDir(): File = File(context.filesDir, "models").apply { mkdirs() }
    fun modelDir(spec: ModelSpec): File = File(modelsDir(), spec.dirName).apply { mkdirs() }

    /** True when every file of the model exists at its final name. */
    fun isComplete(spec: ModelSpec): Boolean {
        val dir = modelDir(spec)
        return spec.files.all { File(dir, it.fileName).exists() }
    }

    /** Bytes already present (final files + .part files). */
    fun downloadedBytes(spec: ModelSpec): Long {
        val dir = modelDir(spec)
        var total = 0L
        for (f in spec.files) {
            val final = File(dir, f.fileName)
            val part = File(dir, f.fileName + ".part")
            total += if (final.exists()) final.length()
            else if (part.exists()) part.length() else 0L
        }
        return total
    }

    fun refreshStatus(spec: ModelSpec) {
        val flow = _progress.getOrPut(spec.id) {
            MutableStateFlow(DownloadProgress(DownloadStatus.NOT_DOWNLOADED))
        }
        val current = flow.value
        if (current.status == DownloadStatus.DOWNLOADING) return
        val complete = isComplete(spec)
        val downloaded = downloadedBytes(spec)
        flow.value = DownloadProgress(
            status = if (complete) DownloadStatus.COMPLETE else DownloadStatus.NOT_DOWNLOADED,
            downloadedBytes = downloaded,
            totalBytes = spec.totalBytes,
            fraction = if (spec.totalBytes > 0) downloaded.toFloat() / spec.totalBytes else 0f
        )
    }

    fun start(spec: ModelSpec) {
        if (jobs[spec.id]?.isActive == true) return
        val flow = _progress.getOrPut(spec.id) {
            MutableStateFlow(DownloadProgress(DownloadStatus.NOT_DOWNLOADED))
        }
        jobs[spec.id] = scope.launch {
            try {
                downloadAll(spec, flow)
            } catch (e: CancellationException) {
                flow.value = flow.value.copy(status = DownloadStatus.PAUSED)
                throw e
            } catch (e: Exception) {
                flow.value = flow.value.copy(
                    status = DownloadStatus.ERROR,
                    errorMessage = e.message ?: "Download fail ho gaya"
                )
            }
        }
    }

    fun pause(modelId: String) {
        jobs[modelId]?.cancel()
        jobs.remove(modelId)
    }

    private suspend fun downloadAll(spec: ModelSpec, flow: MutableStateFlow<DownloadProgress>) =
        withContext(Dispatchers.IO) {
            val dir = modelDir(spec)
            var downloadedSoFar = 0L
            // Bytes already present in COMPLETED files of this model.
            for (file in spec.files) {
                val finalFile = File(dir, file.fileName)
                // Nested file names (e.g. "unet/weights.pb") need their
                // parent directory: the UNet sidecar must sit next to
                // unet/model.onnx (ONNX external data).
                finalFile.parentFile?.mkdirs()
                if (finalFile.exists()) {
                    downloadedSoFar += finalFile.length()
                    continue
                }
                val partFile = File(dir, file.fileName + ".part")
                var downloaded = if (partFile.exists()) partFile.length() else 0L
                flow.value = DownloadProgress(
                    status = DownloadStatus.DOWNLOADING,
                    downloadedBytes = downloadedSoFar + downloaded,
                    totalBytes = spec.totalBytes,
                    fraction = progressFraction(spec, downloadedSoFar + downloaded),
                    currentFile = file.fileName
                )
                downloadOne(file, partFile, flow, spec, downloadedSoFar)
                downloadedSoFar += partFile.length()
                // Atomic-ish finish: rename .part -> final.
                if (!partFile.renameTo(finalFile)) {
                    throw IllegalStateException("File save nahi ho saka: ${file.fileName}")
                }
                flow.value = flow.value.copy(
                    downloadedBytes = downloadedSoFar,
                    fraction = progressFraction(spec, downloadedSoFar)
                )
            }
            flow.value = DownloadProgress(
                status = DownloadStatus.COMPLETE,
                downloadedBytes = spec.totalBytes,
                totalBytes = spec.totalBytes,
                fraction = 1f
            )
        }

    private fun progressFraction(spec: ModelSpec, downloaded: Long): Float =
        if (spec.totalBytes > 0) (downloaded.toFloat() / spec.totalBytes).coerceIn(0f, 1f)
        else -1f

    private fun downloadOne(
        file: ModelFile,
        partFile: File,
        flow: MutableStateFlow<DownloadProgress>,
        spec: ModelSpec,
        downloadedBeforeThisFile: Long
    ) {
        var downloaded = if (partFile.exists()) partFile.length() else 0L
        val connection = (URL(file.url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 30_000
            setRequestProperty("User-Agent", "AI-Studio-Offline/1.0")
            if (downloaded > 0) setRequestProperty("Range", "bytes=$downloaded-")
        }
        connection.connect()
        val responseCode = connection.responseCode
        val supportsResume = responseCode == HttpURLConnection.HTTP_PARTIAL
        if (responseCode != HttpURLConnection.HTTP_OK && !supportsResume) {
            connection.disconnect()
            throw IllegalStateException("Server error: HTTP $responseCode")
        }
        if (!supportsResume && downloaded > 0) {
            // Server ignored Range — restart this file from scratch.
            downloaded = 0L
            partFile.delete()
        }
        val totalForFile = if (file.sizeBytes > 0) file.sizeBytes
        else connection.contentLengthLong.let { if (it > 0) it + downloaded else 0L }

        RandomAccessFile(partFile, "rw").use { raf ->
            raf.seek(downloaded)
            connection.inputStream.use { input ->
                val buffer = ByteArray(256 * 1024)
                var read: Int
                var lastEmit = System.currentTimeMillis()
                while (input.read(buffer).also { read = it } != -1) {
                    raf.write(buffer, 0, read)
                    downloaded += read
                    val now = System.currentTimeMillis()
                    if (now - lastEmit > 250) {
                        lastEmit = now
                        flow.value = DownloadProgress(
                            status = DownloadStatus.DOWNLOADING,
                            downloadedBytes = downloadedBeforeThisFile + downloaded,
                            totalBytes = spec.totalBytes,
                            fraction = progressFraction(spec, downloadedBeforeThisFile + downloaded),
                            currentFile = file.fileName
                        )
                    }
                }
            }
        }
        connection.disconnect()
        // Sanity: if the server told us a size, the file must match it.
        if (totalForFile > 0 && partFile.length() < totalForFile) {
            throw IllegalStateException("Download adhoora reh gaya: ${file.fileName}")
        }
    }
}
