package com.aistudio.offline.ai

import org.json.JSONObject
import java.io.File
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * DDIM sampler (the scheduler from diffusers' DDIMScheduler), implemented
 * in Kotlin from `scheduler_config.json`.
 *
 * Config values read at load (SD 1.5 defaults shown):
 *  - beta_start 0.00085, beta_end 0.012, beta_schedule "scaled_linear"
 *  - num_train_timesteps 1000, prediction_type "epsilon"
 *  - set_alpha_to_one false
 *
 * Timesteps use "leading" spacing, exactly as diffusers does:
 *   step_ratio = num_train_timesteps / num_inference_steps
 *   timesteps = (arange(0, num_inference_steps) * step_ratio)[::-1]
 * The `steps_offset` config value is intentionally ignored — current
 * diffusers DDIM does not apply it in set_timesteps or step().
 *
 * The DDIM step below is the eta=0 (deterministic) update:
 *   pred_original = (sample - sqrt(1-a_t) * noise_pred) / sqrt(a_t)
 *   prev_sample   = sqrt(a_prev) * pred_original
 *                 + sqrt(1-a_prev) * noise_pred
 */
class DdimScheduler(
    betaStart: Double = 0.00085,
    betaEnd: Double = 0.012,
    private val numTrainTimesteps: Int = 1000,
    private val setAlphaToOne: Boolean = false
) {
    companion object {
        fun fromConfig(configFile: File): DdimScheduler {
            return try {
                val json = JSONObject(configFile.readText())
                DdimScheduler(
                    betaStart = json.optDouble("beta_start", 0.00085),
                    betaEnd = json.optDouble("beta_end", 0.012),
                    numTrainTimesteps = json.optInt("num_train_timesteps", 1000),
                    setAlphaToOne = json.optBoolean("set_alpha_to_one", false)
                )
            } catch (_: Exception) {
                // Config is tiny and standard; fall back to SD 1.5 defaults
                // rather than failing the whole generation.
                DdimScheduler()
            }
        }
    }

    private val alphasCumprod: DoubleArray

    init {
        // Scaled-linear betas: linspace(sqrt(start), sqrt(end), T)^2.
        val start = sqrt(betaStart)
        val end = sqrt(betaEnd)
        val betas = DoubleArray(numTrainTimesteps) { i ->
            val v = start + (end - start) * i / (numTrainTimesteps - 1.0)
            v * v
        }
        alphasCumprod = DoubleArray(numTrainTimesteps)
        var prod = 1.0
        for (i in betas.indices) {
            prod *= (1.0 - betas[i])
            alphasCumprod[i] = prod
        }
    }

    /** Inference timesteps for [numInferenceSteps], highest first. */
    fun setTimesteps(numInferenceSteps: Int): LongArray {
        val stepRatio = numTrainTimesteps / numInferenceSteps
        return LongArray(numInferenceSteps) { i ->
            (i * stepRatio).toLong()
        }.reversed().toLongArray()
    }

    /** How far back one DDIM step goes (diffusers: T / num_inference_steps). */
    fun stepRatio(numInferenceSteps: Int): Int =
        numTrainTimesteps / numInferenceSteps

    /**
     * One deterministic DDIM step. [sample] and [noisePred] are flat
     * float arrays of the same length (latent [1, 4, 64, 64] = 16384).
     */
    fun step(
        noisePred: FloatArray,
        timestep: Long,
        sample: FloatArray,
        numInferenceSteps: Int
    ): FloatArray {
        val t = timestep.toInt()
        val prevTimestep = t - stepRatio(numInferenceSteps)
        val alphaProdT = alphasCumprod[t]
        val alphaProdPrev = if (prevTimestep >= 0) {
            alphasCumprod[prevTimestep]
        } else if (setAlphaToOne) {
            1.0
        } else {
            alphasCumprod[0]
        }
        val sqrtAlphaProdT = sqrt(alphaProdT)
        val sqrtOneMinusAlphaProdT = sqrt(1.0 - alphaProdT)
        val sqrtAlphaProdPrev = sqrt(alphaProdPrev)
        val sqrtOneMinusAlphaProdPrev = sqrt(1.0 - alphaProdPrev)
        val out = FloatArray(sample.size)
        for (i in sample.indices) {
            val predOriginal =
                (sample[i] - sqrtOneMinusAlphaProdT * noisePred[i]) / sqrtAlphaProdT
            out[i] = (
                sqrtAlphaProdPrev * predOriginal +
                    sqrtOneMinusAlphaProdPrev * noisePred[i]
                ).toFloat()
        }
        return out
    }
}
