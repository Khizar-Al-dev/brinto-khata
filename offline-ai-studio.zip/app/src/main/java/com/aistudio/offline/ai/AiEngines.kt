package com.aistudio.offline.ai

/**
 * Factory for the on-device engines. Keeps StudioViewModel free of
 * concrete engine classes (and makes a future engine swap one line).
 */
object AiEngines {
    fun createLlmEngine(): LlmEngine = LlmEngineImpl()
    fun createImageEngine(): ImageEngine = ImageEngineImpl()
}
