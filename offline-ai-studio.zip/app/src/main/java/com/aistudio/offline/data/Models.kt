package com.aistudio.offline.data

/** One file that makes up a model (a model can be a single file,
 *  like a GGUF, or several files, like an ONNX Stable Diffusion). */
data class ModelFile(
    /** File name on disk, e.g. "qwen2.5-1.5b-instruct-q4_k_m.gguf" */
    val fileName: String,
    /** Full https URL to download from (Hugging Face resolve link). */
    val url: String,
    /** Expected size in bytes (0 = unknown; used for progress %). */
    val sizeBytes: Long = 0L
)

/** A downloadable model: the chat LLM or the image model. */
data class ModelSpec(
    val id: String, // "chat" | "image"
    val displayName: String,
    val description: String,
    /** Sub-folder under filesDir/models/ */
    val dirName: String,
    val files: List<ModelFile>
) {
    val totalBytes: Long get() = files.sumOf { it.sizeBytes }
}

enum class DownloadStatus {
    NOT_DOWNLOADED, DOWNLOADING, PAUSED, COMPLETE, ERROR
}

data class DownloadProgress(
    val status: DownloadStatus,
    /** Bytes downloaded across all files of this model. */
    val downloadedBytes: Long = 0L,
    val totalBytes: Long = 0L,
    /** 0..1, or -1 when the total size is unknown. */
    val fraction: Float = 0f,
    val errorMessage: String? = null,
    /** File currently being downloaded (for multi-file models). */
    val currentFile: String? = null
)

data class ChatMessage(
    val role: String, // "user" | "assistant"
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class ImageRecord(
    val fileName: String, // PNG file in filesDir/images/
    val prompt: String,
    val seed: Long,
    val steps: Int,
    val timestamp: Long = System.currentTimeMillis()
)
