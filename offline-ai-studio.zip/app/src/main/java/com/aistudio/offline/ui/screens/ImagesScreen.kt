package com.aistudio.offline.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import com.aistudio.offline.ui.StudioViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ImagesScreen(viewModel: StudioViewModel) {
    val generating = viewModel.imageGenerating
    val progress = viewModel.imageProgress
    val progressText = viewModel.imageProgressText
    val bitmap = viewModel.currentImage
    val record = viewModel.currentImageRecord
    val history = viewModel.imageHistory
    val error = viewModel.imageError
    var savedMessage by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = viewModel.imagePrompt,
                onValueChange = { viewModel.onPromptChange(it) },
                modifier = Modifier.fillMaxWidth(),
                placeholder = {
                    Text("Image ka prompt likhein… (jaise: aik safed sher, kaale chashme, suit mein)")
                },
                shape = RoundedCornerShape(16.dp),
                maxLines = 4
            )
        }

        item {
            // Steps slider: fewer steps = faster, more steps = better detail.
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Steps: ${viewModel.imageSteps}", style = MaterialTheme.typography.bodyMedium)
                Text(
                    text = "Kam steps = tez, zyada steps = behtar detail",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Slider(
                value = viewModel.imageSteps.toFloat(),
                onValueChange = { viewModel.onStepsChange(it.toInt()) },
                valueRange = 4f..50f,
                steps = 45,
                enabled = !generating
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Seed: ${viewModel.imageSeed?.toString() ?: "Random"}",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedButton(
                    onClick = { viewModel.onSeedChange(null) },
                    enabled = !generating
                ) {
                    Text("Random")
                }
            }
            Text(
                text = "Phone par image banne mein kuch minute lag sakte hain — ye normal hai.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            if (generating) {
                Button(
                    onClick = { viewModel.stopImageGeneration() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Rok dein")
                }
            } else {
                Button(
                    onClick = { viewModel.generateImage() },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = viewModel.imagePrompt.isNotBlank()
                ) {
                    Text("Generate")
                }
            }
        }

        if (generating) {
            item {
                Column {
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = progressText,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (error != null) {
            item {
                Text(
                    text = error,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        if (bitmap != null) {
            item {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = record?.prompt ?: "Generated image",
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                )
            }
            item {
                if (record != null) {
                    Text(
                        text = "“${record.prompt}” • seed ${record.seed} • ${record.steps} steps",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = {
                        viewModel.saveCurrentImageToGallery { ok ->
                            savedMessage = if (ok) "Gallery mein save ho gayi"
                            else "Save nahi ho saki"
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Gallery mein save karein")
                }
                if (savedMessage != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = savedMessage!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "History", style = MaterialTheme.typography.titleMedium)
            if (history.isEmpty()) {
                Text(
                    text = "Abhi koi image nahi banayi",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        items(history) { item ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { viewModel.selectHistoryImage(item) }
                    .padding(8.dp)
            ) {
                Text(
                    text = item.prompt,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 2
                )
                Text(
                    text = "seed ${item.seed} • ${item.steps} steps • " +
                        SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
                            .format(Date(item.timestamp)),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}
