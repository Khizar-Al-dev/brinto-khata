package com.aistudio.offline.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val BrandAccent = Color(0xFF8B7CFF)
private val BrandAccentDark = Color(0xFF6A5AE0)
private val AppBg = Color(0xFF0E0E14)
private val AppSurface = Color(0xFF17171F)
private val AppSurface2 = Color(0xFF1F1F2B)
private val AppText = Color(0xFFF2F2F7)
private val AppMuted = Color(0xFF9A9AAF)

private val DarkColors = darkColorScheme(
    primary = BrandAccent,
    onPrimary = AppText,
    primaryContainer = BrandAccentDark,
    onPrimaryContainer = AppText,
    background = AppBg,
    onBackground = AppText,
    surface = AppSurface,
    onSurface = AppText,
    surfaceVariant = AppSurface2,
    onSurfaceVariant = AppMuted,
    secondary = BrandAccent,
    onSecondary = AppText
)

private val LightColors = lightColorScheme(
    primary = BrandAccentDark,
    onPrimary = Color.White,
    primaryContainer = BrandAccent,
    onPrimaryContainer = Color.White,
    background = Color(0xFFF6F6FA),
    onBackground = Color(0xFF14141C),
    surface = Color.White,
    onSurface = Color(0xFF14141C),
    surfaceVariant = Color(0xFFEDEDF4),
    onSurfaceVariant = Color(0xFF5A5A6E)
)

@Composable
fun AIStudioTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
