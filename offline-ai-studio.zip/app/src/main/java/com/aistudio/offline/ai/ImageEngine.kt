package com.aistudio.offline.ai

import android.graphics.Bitmap

/**
 * On-device image model (Stable Diffusion via ONNX Runtime Mobile).
 * Implementations must run fully offline — no network calls.
 */
interface ImageEngine {
    val isLoaded: Boolean

    /** Loads the ONNX model files from [modelDir]. Must be called off the main thread. */
    suspend fun load(modelDir: String): Result<Unit>

    /**
     * Generates one image. [onProgress] reports (doneSteps, totalSteps)
     * from a background thread. Returns the bitmap on success.
     */
    suspend fun generate(
        prompt: String,
        steps: Int,
        seed: Long,
        onProgress: (done: Int, total: Int) -> Unit
    ): Result<Bitmap>

    fun unload()
}
