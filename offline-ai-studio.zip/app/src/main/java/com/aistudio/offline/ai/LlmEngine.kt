package com.aistudio.offline.ai

/**
 * On-device text model (GGUF via llama.cpp).
 * Implementations must run fully offline — no network calls.
 */
interface LlmEngine {
    val isLoaded: Boolean

    /** Loads the GGUF file at [modelPath]. Must be called off the main thread. */
    suspend fun load(modelPath: String): Result<Unit>

    /**
     * Streams a reply for [messages] (alternating user/assistant turns).
     * [onToken] is called for every generated piece of text (may be
     * called from a background thread — the caller posts to the UI).
     * Returns normally when generation finishes; throws on error.
     */
    suspend fun generate(
        messages: List<Pair<String, String>>,
        onToken: (String) -> Unit
    )

    /** Stops an in-flight generation as soon as possible. */
    fun stop()

    fun unload()
}
