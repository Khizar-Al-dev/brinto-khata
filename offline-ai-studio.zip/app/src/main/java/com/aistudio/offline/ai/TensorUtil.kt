package com.aistudio.offline.ai

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import java.nio.FloatBuffer
import java.nio.LongBuffer
import java.nio.ShortBuffer

/**
 * Small helpers for the ONNX Runtime Java API (ai.onnxruntime).
 *
 * The SD 1.5 ONNX models are FP16: ORT Java exposes FP16 tensor data as
 * raw half-precision bit patterns in `short` values (there is no Java
 * `half` type), so inputs must be converted float -> half bits and
 * outputs half bits -> float. The converters below are the standard
 * IEEE 754 half-precision bit math (no rounding on the float->half path;
 * the ~1e-3 relative error is far below diffusion noise).
 */

/** Raw half-precision bits -> Float. */
fun halfToFloat(h: Short): Float {
    val bits = h.toInt() and 0xFFFF
    val sign = (bits shr 15) and 1
    val exp = (bits shr 10) and 0x1F
    val mant = bits and 0x3FF
    val fbits = when {
        exp == 0 -> {
            if (mant == 0) {
                sign shl 31 // signed zero
            } else {
                // Subnormal half: normalize.
                var m = mant
                var e = -14
                while (m and 0x400 == 0) {
                    m = m shl 1
                    e--
                }
                m = m and 0x3FF
                (sign shl 31) or ((e + 127) shl 23) or (m shl 13)
            }
        }
        exp == 31 -> (sign shl 31) or (0xFF shl 23) or (mant shl 13) // inf / NaN
        else -> (sign shl 31) or ((exp - 15 + 127) shl 23) or (mant shl 13)
    }
    return Float.fromBits(fbits)
}

/** Float -> raw half-precision bits. */
fun floatToHalf(f: Float): Short {
    val bits = f.toBits()
    val sign = (bits shr 16) and 0x8000
    val exp = ((bits shr 23) and 0xFF) - 112
    val mant = bits and 0x7FFFFF
    val half = when {
        exp >= 31 -> sign or 0x7C00 // overflow -> inf
        exp <= 0 -> {
            if (exp < -10) {
                sign // underflow -> signed zero
            } else {
                // Subnormal half.
                val m = mant or 0x800000
                sign or (m shr (14 - exp))
            }
        }
        else -> sign or (exp shl 10) or (mant shr 13)
    }
    return half.toShort()
}

/**
 * Flattens any multi-dimensional primitive array returned by
 * `OnnxTensor.getValue()` into a FloatArray (row-major order).
 * When [fp16] is true, `short` values are treated as raw half bits.
 */
fun flattenToFloat(value: Any?, fp16: Boolean): FloatArray {
    val out = ArrayList<Float>()
    fun walk(v: Any?) {
        when (v) {
            null -> Unit
            is Number -> out.add(
                if (fp16 && v is Short) halfToFloat(v) else v.toFloat()
            )
            else -> {
                val cls = v.javaClass
                if (cls.isArray) {
                    val len = java.lang.reflect.Array.getLength(v)
                    for (i in 0 until len) {
                        walk(java.lang.reflect.Array.get(v, i))
                    }
                } else {
                    throw IllegalArgumentException(
                        "Unexpected tensor value type: ${cls.name}"
                    )
                }
            }
        }
    }
    walk(value)
    return out.toFloatArray()
}

/** FLOAT32 tensor from a FloatArray. */
fun createFloatTensor(
    env: OrtEnvironment,
    data: FloatArray,
    vararg shape: Long
): OnnxTensor = OnnxTensor.createTensor(env, FloatBuffer.wrap(data), shape)

/** FLOAT16 tensor from a FloatArray (converted to half bits). */
fun createHalfTensor(
    env: OrtEnvironment,
    data: FloatArray,
    vararg shape: Long
): OnnxTensor {
    val shorts = ShortArray(data.size) { floatToHalf(data[it]) }
    return OnnxTensor.createTensor(env, ShortBuffer.wrap(shorts), shape)
}

/** INT64 tensor from a LongArray. */
fun createLongTensor(
    env: OrtEnvironment,
    data: LongArray,
    vararg shape: Long
): OnnxTensor = OnnxTensor.createTensor(env, LongBuffer.wrap(data), shape)
