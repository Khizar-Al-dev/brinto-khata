package com.aistudio.offline.ai

import org.json.JSONObject
import java.io.File

/**
 * CLIP byte-level BPE tokenizer, implemented in Kotlin from
 * `vocab.json` + `merges.txt` (no ORT call — the tokenizer runs on CPU).
 *
 * This is the same algorithm as OpenAI CLIP / GPT-2 byte-level BPE:
 *  - Text is split with the CLIP regex (no lower-casing).
 *  - Each piece is byte-encoded through the GPT-2 byte->unicode table.
 *  - BPE merges are applied in rank order until no pair remains.
 *  - Output is a fixed 77-token sequence: BOS 49406, tokens, EOS 49407,
 *    padded with 0 — exactly what the SD 1.5 text encoder expects.
 *
 * Loaded once in [ImageEngineImpl.load]; the files are tiny (~1.5 MB).
 */
class ClipTokenizer private constructor(
    private val vocab: Map<String, Int>,
    private val merges: Map<String, Int>
) {

    companion object {
        const val CONTEXT_LENGTH = 77
        const val BOS_ID = 49406L
        const val EOS_ID = 49407L
        const val PAD_ID = 0L

        fun load(vocabFile: File, mergesFile: File): ClipTokenizer {
            val vocabJson = JSONObject(vocabFile.readText())
            val vocab = HashMap<String, Int>(vocabJson.length())
            val keys = vocabJson.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                vocab[key] = vocabJson.getInt(key)
            }
            val merges = HashMap<String, Int>()
            var rank = 0
            for (rawLine in mergesFile.readLines()) {
                val line = rawLine.trim()
                if (line.isEmpty() || line.startsWith("#")) continue
                // Each line is "tokenA tokenB" (tokens never contain a
                // literal space — spaces are the byte-level char U+0120).
                val parts = line.split(" ")
                if (parts.size == 2) {
                    merges["${parts[0]} ${parts[1]}"] = rank
                }
                rank++
            }
            return ClipTokenizer(vocab, merges)
        }

        /**
         * The GPT-2 byte->unicode table, built algorithmically:
         * printable bytes map to themselves; the rest map to code points
         * starting at U+0100. Byte value -> unicode char.
         */
        private fun byteEncoder(): Map<Int, Char> {
            val bs = ((33..126) + (161..172) + (174..255)).toMutableList()
            val cs = bs.map { it.toChar() }.toMutableList()
            var n = 0
            for (b in 0..255) {
                if (b !in bs) {
                    bs.add(b)
                    cs.add((256 + n).toChar())
                    n++
                }
            }
            return bs.zip(cs).toMap()
        }
    }

    private val byteEncoder = byteEncoder()
    private val bpeCache = HashMap<String, List<String>>()

    // CLIP's split pattern (same as GPT-2's).
    private val pattern = Regex(
        """'s|'t|'re|'ve|'m|'ll|'d| ?\p{L}+| ?\p{N}+| ?[^\s\p{L}\p{N}]+|\s+(?!\S)|\s+"""
    )

    private fun bpe(word: String): List<String> {
        bpeCache[word]?.let { return it }
        var parts = word.map { it.toString() }
        if (parts.size > 1) {
            while (true) {
                var bestRank = Int.MAX_VALUE
                var bestIdx = -1
                for (i in 0 until parts.size - 1) {
                    val rank = merges["${parts[i]} ${parts[i + 1]}"] ?: continue
                    if (rank < bestRank) {
                        bestRank = rank
                        bestIdx = i
                    }
                }
                if (bestIdx < 0) break
                val merged = parts[bestIdx] + parts[bestIdx + 1]
                parts = parts.subList(0, bestIdx) +
                    listOf(merged) +
                    parts.subList(bestIdx + 2, parts.size)
            }
        }
        bpeCache[word] = parts
        return parts
    }

    /** Encodes [text] to exactly [CONTEXT_LENGTH] token ids. */
    fun encode(text: String): LongArray {
        val ids = ArrayList<Long>(CONTEXT_LENGTH)
        ids.add(BOS_ID)
        for (match in pattern.findAll(text)) {
            // Byte-encode the piece, then BPE-merge it.
            val encoded = StringBuilder()
            for (byte in match.value.toByteArray(Charsets.UTF_8)) {
                encoded.append(byteEncoder[byte.toInt() and 0xFF] ?: '?')
            }
            for (piece in bpe(encoded.toString())) {
                // Every BPE piece is in the vocab by construction; 0 is
                // only a defensive fallback (CLIP has no UNK token).
                ids.add((vocab[piece] ?: 0).toLong())
                if (ids.size >= CONTEXT_LENGTH - 1) break
            }
            if (ids.size >= CONTEXT_LENGTH - 1) break
        }
        ids.add(EOS_ID)
        while (ids.size < CONTEXT_LENGTH) ids.add(PAD_ID)
        return ids.take(CONTEXT_LENGTH).toLongArray()
    }
}
