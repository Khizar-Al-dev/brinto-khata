package com.aistudio.offline.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aistudio.offline.data.DownloadStatus
import com.aistudio.offline.data.ModelSpec
import com.aistudio.offline.ui.StudioViewModel

@Composable
fun ModelsScreen(viewModel: StudioViewModel) {
    val models = listOf(viewModel.chatModel, viewModel.imageModel)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Pehli dafa models download karne honge (lagbhag 3 GB). " +
                    "WiFi use karein. Download ke baad sab kuch offline chalega.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        items(models) { spec ->
            ModelCard(viewModel = viewModel, spec = spec)
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}

@Composable
private fun ModelCard(viewModel: StudioViewModel, spec: ModelSpec) {
    val progress by viewModel.downloadProgress(spec).collectAsState()
    val complete = viewModel.isModelComplete(spec)
    // Safety guard: a spec with no real file URLs must not offer a
    // download that can only fail — show a plain note instead.
    // (All current specs have URLs; this guards future placeholders.)
    val downloadable = spec.files.any { it.url.isNotBlank() }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = spec.displayName, style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = spec.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Size: ${formatBytes(spec.totalBytes)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            val statusText = when {
                complete -> "Tayyar hai — offline"
                progress.status == DownloadStatus.DOWNLOADING ->
                    "Download ho raha hai… ${formatBytes(progress.downloadedBytes)} / ${formatBytes(progress.totalBytes)}"
                progress.status == DownloadStatus.PAUSED ->
                    "Ruka hua — ${formatBytes(progress.downloadedBytes)} / ${formatBytes(progress.totalBytes)}"
                progress.status == DownloadStatus.ERROR ->
                    "Download fail ho gaya — dobara try karein" +
                        (progress.errorMessage?.let { ": $it" } ?: "")
                else -> "Download nahi hua"
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (complete) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(start = if (complete) 6.dp else 0.dp)
                )
            }

            if (progress.status == DownloadStatus.DOWNLOADING ||
                progress.status == DownloadStatus.PAUSED
            ) {
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { progress.fraction.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth()
                )
                if (progress.currentFile != null) {
                    Text(
                        text = progress.currentFile!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            when {
                complete -> {
                    OutlinedButton(onClick = {}, enabled = false) {
                        Text("Tayyar hai — offline")
                    }
                }
                !downloadable -> {
                    Text(
                        text = "Is model ki files abhi tayyar ho rahi hain — jald aa rahi hain.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }                progress.status == DownloadStatus.DOWNLOADING -> {
                    Button(onClick = { viewModel.pauseDownload(spec) }) {
                        Text("Pause karein")
                    }
                }
                progress.status == DownloadStatus.PAUSED ||
                    progress.status == DownloadStatus.ERROR -> {
                    Button(onClick = { viewModel.startDownload(spec) }) {
                        Icon(
                            imageVector = Icons.Filled.Download,
                            contentDescription = null
                        )
                        Text("Resume karein")
                    }
                }
                else -> {
                    Button(onClick = { viewModel.startDownload(spec) }) {
                        Icon(
                            imageVector = Icons.Filled.Download,
                            contentDescription = null
                        )
                        Text("Download karein")
                    }
                }
            }
        }
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "—"
    val gb = bytes / 1_000_000_000.0
    return if (gb >= 1) "%.2f GB".format(gb)
    else "%.0f MB".format(bytes / 1_000_000.0)
}
