package com.aistudio.offline.data

/**
 * The two models the app downloads once (free, no key, no account)
 * and then runs fully offline.
 *
 * CHAT — verified 27 Nov 2026 against the Hugging Face repo page
 * bartowski/Qwen2.5-1.5B-Instruct-GGUF (0.99 GB for Q4_K_M;
 * exact byte size 986,048,768 confirmed via the repo file listing).
 * Download URL is the standard HF resolve link.
 *
 * IMAGE — verified 27 Nov 2026 via the Hugging Face API:
 * repo `nmkd/stable-diffusion-1.5-onnx-fp16` (FP16 ONNX export of
 * Runway SD 1.5, CreativeML OpenRAIL-M licence). Sizes below are the
 * exact repo sizes ROUNDED DOWN (235.1 MB -> 235,000,000 etc.) on
 * purpose: ModelDownloader treats sizeBytes as a minimum — a rounded-up
 * value would falsely report an incomplete download. The small files
 * (vocab/merges/scheduler config) use 0 = unknown, so the downloader
 * falls back to the server's Content-Length for them.
 * The `unet/weights.pb` sidecar MUST stay in the `unet/` sub-directory
 * next to `unet/model.onnx` (ONNX external data) — ModelDownloader
 * creates parent directories for nested file names.
 * Total txt2img download: ~1,971 MB (~1.93 GB).
 */
object ModelCatalog {

    val chatModel = ModelSpec(
        id = "chat",
        displayName = "Qwen2.5 1.5B Instruct — Chat",
        description = "Text chat model (1.5B parameters, Q4_K_M). " +
            "Phone par chalne ke liye chhota aur tez; " +
            "jawab aapke phone par bante hain, kahin nahi bheje jate.",
        dirName = "chat",
        files = listOf(
            ModelFile(
                fileName = "Qwen2.5-1.5B-Instruct-Q4_K_M.gguf",
                url = "https://huggingface.co/bartowski/Qwen2.5-1.5B-Instruct-GGUF/" +
                    "resolve/main/Qwen2.5-1.5B-Instruct-Q4_K_M.gguf",
                sizeBytes = 986_048_768L
            )
        )
    )

    val imageModel = ModelSpec(
        id = "image",
        displayName = "Stable Diffusion 1.5 — Images",
        description = "Image generation model (ONNX FP16). " +
            "Pehli dafa download ke baad images bhi poori tarah offline banti hain. " +
            "Phone par aik image banne mein 1-3 minute lag sakte hain.",
        dirName = "image",
        files = listOf(
            ModelFile(
                fileName = "text_encoder/model.onnx",
                url = "https://huggingface.co/nmkd/stable-diffusion-1.5-onnx-fp16/" +
                    "resolve/main/text_encoder/model.onnx",
                sizeBytes = 235_000_000L
            ),
            ModelFile(
                fileName = "unet/model.onnx",
                url = "https://huggingface.co/nmkd/stable-diffusion-1.5-onnx-fp16/" +
                    "resolve/main/unet/model.onnx",
                sizeBytes = 1_000_000L
            ),
            ModelFile(
                fileName = "unet/weights.pb",
                url = "https://huggingface.co/nmkd/stable-diffusion-1.5-onnx-fp16/" +
                    "resolve/main/unet/weights.pb",
                sizeBytes = 1_639_000_000L
            ),
            ModelFile(
                fileName = "vae_decoder/model.onnx",
                url = "https://huggingface.co/nmkd/stable-diffusion-1.5-onnx-fp16/" +
                    "resolve/main/vae_decoder/model.onnx",
                sizeBytes = 94_000_000L
            ),
            ModelFile(
                fileName = "tokenizer/vocab.json",
                url = "https://huggingface.co/nmkd/stable-diffusion-1.5-onnx-fp16/" +
                    "resolve/main/tokenizer/vocab.json",
                sizeBytes = 0L
            ),
            ModelFile(
                fileName = "tokenizer/merges.txt",
                url = "https://huggingface.co/nmkd/stable-diffusion-1.5-onnx-fp16/" +
                    "resolve/main/tokenizer/merges.txt",
                sizeBytes = 0L
            ),
            ModelFile(
                fileName = "scheduler/scheduler_config.json",
                url = "https://huggingface.co/nmkd/stable-diffusion-1.5-onnx-fp16/" +
                    "resolve/main/scheduler/scheduler_config.json",
                sizeBytes = 0L
            )
        )
    )

    val allModels: List<ModelSpec> = listOf(chatModel, imageModel)
}
