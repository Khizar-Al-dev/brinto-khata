package com.aistudio.offline.ai

import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.graphics.Bitmap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Random

/**
 * Stable Diffusion 1.5 image engine on ONNX Runtime Mobile.
 *
 * Stack (verified 27 Nov 2026):
 *  - `com.microsoft.onnxruntime:onnxruntime-android:1.32.0` (Maven Central,
 *    14 Nov 2026). API pattern from the official mobile tutorial:
 *    `OrtEnvironment.getEnvironment()` -> `SessionOptions` ->
 *    `env.createSession(path, options)` -> `session.run(mapOf(...))`.
 *  - Models: `nmkd/stable-diffusion-1.5-onnx-fp16` (FP16 export of
 *    Runway SD 1.5), ~1.97 GB for txt2img — see ModelCatalog.
 *    The UNet's `weights.pb` is an external-data sidecar and MUST sit in
 *    the same `unet/` directory as `unet/model.onnx` (ModelDownloader
 *    preserves the sub-directory layout).
 *
 * Pipeline (per the TensorChat reference implementation, which uses
 * these exact model files):
 *  1. CLIP BPE tokenizer in Kotlin (ClipTokenizer) -> token ids [1, 77].
 *  2. Text encoder (x2: prompt + empty negative prompt) -> embeddings
 *     [1, 77, 768] each.
 *  3. Latents [1, 4, 64, 64] from the seed (java.util.Random Gaussian).
 *  4. DDIM loop (DdimScheduler): UNet on the batched latents
 *     (uncond + cond, [2, 4, 64, 64]) with classifier-free guidance 7.5.
 *  5. VAE decoder: latents / 0.18215 -> image [1, 3, 512, 512] -> Bitmap.
 *
 * Execution providers: NNAPI first, then XNNPACK, then CPU — each
 * session creation is retried down the chain. NNAPI matters: on the
 * CPU provider ORT promotes the FP16 UNet to ~3.5 GB resident, which
 * will very likely OOM a 6 GB phone; NNAPI/XNNPACK execute FP16
 * natively. See README.md for the honest performance expectation
 * (roughly 1-3 minutes per image on a Redmi Note 13).
 *
 * Input names are resolved from each session's own `inputInfo` at load
 * (standard diffusers names first) — if an export ever renames a node,
 * the engine still finds it. Outputs are read by index (every session
 * here has exactly one output).
 */
class ImageEngineImpl : ImageEngine {

    private var env: OrtEnvironment? = null
    private var textEncoder: OrtSession? = null
    private var unet: OrtSession? = null
    private var vaeDecoder: OrtSession? = null
    private var tokenizer: ClipTokenizer? = null
    private var scheduler: DdimScheduler? = null

    private var textEncoderInput = "input_ids"
    private var unetSampleInput = "sample"
    private var unetTimestepInput = "timestep"
    private var unetEncoderInput = "encoder_hidden_states"
    private var vaeInput = "latent_sample"

    override val isLoaded: Boolean
        get() = textEncoder != null && unet != null && vaeDecoder != null

    override suspend fun load(modelDir: String): Result<Unit> {
        return try {
            withContext(Dispatchers.IO) { loadInternal(File(modelDir)) }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun loadInternal(dir: File) {
        try {
            val environment = OrtEnvironment.getEnvironment()
            env = environment
            tokenizer = ClipTokenizer.load(
                File(dir, "tokenizer/vocab.json"),
                File(dir, "tokenizer/merges.txt")
            )
            scheduler = DdimScheduler.fromConfig(
                File(dir, "scheduler/scheduler_config.json")
            )
            textEncoder = createSession(
                environment,
                File(dir, "text_encoder/model.onnx").absolutePath
            )
            unet = createSession(
                environment,
                File(dir, "unet/model.onnx").absolutePath
            )
            vaeDecoder = createSession(
                environment,
                File(dir, "vae_decoder/model.onnx").absolutePath
            )
            textEncoderInput = resolveInput(textEncoder!!, "input_ids")
            unetSampleInput = resolveInput(unet!!, "sample")
            unetTimestepInput = resolveInput(unet!!, "timestep")
            unetEncoderInput = resolveInput(unet!!, "encoder_hidden_states")
            vaeInput = resolveInput(vaeDecoder!!, "latent_sample")
        } catch (e: Exception) {
            // Don't leave half-loaded sessions behind.
            closeSessions()
            throw e
        }
    }

    override fun unload() {
        closeSessions()
        tokenizer = null
        scheduler = null
    }

    private fun closeSessions() {
        try {
            textEncoder?.close()
        } catch (_: Exception) {
        }
        try {
            unet?.close()
        } catch (_: Exception) {
        }
        try {
            vaeDecoder?.close()
        } catch (_: Exception) {
        }
        textEncoder = null
        unet = null
        vaeDecoder = null
        // OrtEnvironment is a process singleton — deliberately NOT closed
        // here, so a later reload reuses it (getEnvironment() returns the
        // same instance). The process owns it until the app exits.
    }

    /**
     * Creates one ORT session, trying NNAPI, then XNNPACK, then CPU.
     * Each attempt gets its own SessionOptions; the first provider that
     * loads the model wins.
     */
    private fun createSession(
        environment: OrtEnvironment,
        modelPath: String
    ): OrtSession {
        require(File(modelPath).exists()) { "Model file nahi mila: $modelPath" }
        var lastError: Exception? = null
        val attempts: List<Pair<String, (OrtSession.SessionOptions) -> Unit>> =
            listOf(
                "NNAPI" to { opts -> opts.addNnapi() },
                "XNNPACK" to { opts -> opts.addXnnpack(emptyMap()) },
                "CPU" to { opts -> opts.addCPU(true) }
            )
        for ((_, addEp) in attempts) {
            try {
                val options = OrtSession.SessionOptions()
                options.setIntraOpNumThreads(4)
                options.setOptimizationLevel(
                    // ORT 1.32.0 Java API: OptLevel values are NO_OPT /
                    // BASIC_OPT / EXTENDED_OPT / LAYOUT_OPT / ALL_OPT
                    // (verified from the 1.32.0 AAR's classes.jar).
                    OrtSession.SessionOptions.OptLevel.ALL_OPT
                )
                addEp(options)
                return environment.createSession(modelPath, options)
            } catch (e: Exception) {
                lastError = e
            }
        }
        throw lastError
            ?: IllegalStateException("Session nahi ban saka: $modelPath")
    }

    /** Finds an input by exact name, then by substring, then first input. */
    private fun resolveInput(session: OrtSession, vararg candidates: String): String {
        val names = session.inputInfo.keys.toList()
        for (candidate in candidates) {
            names.firstOrNull { it == candidate }?.let { return it }
        }
        for (candidate in candidates) {
            names.firstOrNull { it.contains(candidate, ignoreCase = true) }
                ?.let { return it }
        }
        return names.firstOrNull()
            ?: throw IllegalStateException("Session mein koi input nahi")
    }

    override suspend fun generate(
        prompt: String,
        steps: Int,
        seed: Long,
        onStep: (done: Int, total: Int) -> Unit
    ): Result<Bitmap> {
        return try {
            val bitmap = withContext(Dispatchers.Default) {
                generateInternal(prompt, steps, seed, onStep)
            }
            Result.success(bitmap)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun generateInternal(
        prompt: String,
        steps: Int,
        seed: Long,
        onStep: (done: Int, total: Int) -> Unit
    ): Bitmap {
        val encoder = textEncoder
            ?: throw IllegalStateException("Image model load nahi hua")
        val unetSession = unet
            ?: throw IllegalStateException("Image model load nahi hua")
        val vae = vaeDecoder
            ?: throw IllegalStateException("Image model load nahi hua")
        val tok = tokenizer
            ?: throw IllegalStateException("Tokenizer load nahi hua")
        val sched = scheduler
            ?: throw IllegalStateException("Scheduler load nahi hua")

        // 1. Text embeddings: prompt + empty negative prompt (CFG needs both).
        val condEmbedding = runTextEncoder(encoder, tok.encode(prompt))
        val uncondEmbedding = runTextEncoder(encoder, tok.encode(""))

        // 2. Initial latents from the seed.
        val random = Random(seed)
        var latents = FloatArray(LATENT_SIZE) { random.nextGaussian().toFloat() }

        // 3. Denoising loop.
        val timesteps = sched.setTimesteps(steps)
        for ((index, t) in timesteps.withIndex()) {
            // Batch of 2: [uncond, cond].
            val batchSample = FloatArray(LATENT_SIZE * 2)
            latents.copyInto(batchSample, 0)
            latents.copyInto(batchSample, LATENT_SIZE)
            val batchEmbedding = FloatArray(EMBEDDING_SIZE * 2)
            uncondEmbedding.copyInto(batchEmbedding, 0)
            condEmbedding.copyInto(batchEmbedding, EMBEDDING_SIZE)

            val noise = runUnet(unetSession, batchSample, t, batchEmbedding)
            // Classifier-free guidance: uncond + 7.5 * (cond - uncond).
            val noisePred = FloatArray(LATENT_SIZE) { i ->
                val uncond = noise[i]
                val cond = noise[LATENT_SIZE + i]
                uncond + GUIDANCE_SCALE * (cond - uncond)
            }
            latents = sched.step(noisePred, t, latents, steps)
            onStep(index + 1, steps)
        }

        // 4. VAE decode (latents are scaled by 0.18215 in SD 1.5).
        val scaled = FloatArray(LATENT_SIZE) { latents[it] / VAE_SCALE }
        val image = runVaeDecoder(vae, scaled)

        // 5. VAE output is ~[-1, 1] -> [0, 255] -> Bitmap.
        val pixels = IntArray(IMAGE_SIZE * IMAGE_SIZE)
        val plane = IMAGE_SIZE * IMAGE_SIZE
        for (p in pixels.indices) {
            val r = ((image[p] * 0.5f + 0.5f).coerceIn(0f, 1f) * 255).toInt()
            val g = ((image[plane + p] * 0.5f + 0.5f).coerceIn(0f, 1f) * 255).toInt()
            val b = ((image[2 * plane + p] * 0.5f + 0.5f).coerceIn(0f, 1f) * 255).toInt()
            pixels[p] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
        val bitmap = Bitmap.createBitmap(
            IMAGE_SIZE, IMAGE_SIZE, Bitmap.Config.ARGB_8888
        )
        bitmap.setPixels(pixels, 0, IMAGE_SIZE, 0, 0, IMAGE_SIZE, IMAGE_SIZE)
        return bitmap
    }

    /** Text encoder: token ids [1, 77] -> last_hidden_state [1, 77, 768]. */
    private fun runTextEncoder(session: OrtSession, tokenIds: LongArray): FloatArray {
        val environment = env
            ?: throw IllegalStateException("Image model load nahi hua")
        createLongTensor(environment, tokenIds, 1, 77).use { input ->
            session.run(mapOf(textEncoderInput to input)).use { result ->
                return flattenToFloat(result.get(0).value, fp16 = true)
            }
        }
    }

    /** UNet: batched sample [2, 4, 64, 64] -> noise [2, 4, 64, 64]. */
    private fun runUnet(
        session: OrtSession,
        sample: FloatArray,
        timestep: Long,
        encoderHiddenStates: FloatArray
    ): FloatArray {
        val environment = env
            ?: throw IllegalStateException("Image model load nahi hua")
        createHalfTensor(environment, sample, 2, 4, 64, 64).use { sampleTensor ->
            createLongTensor(environment, longArrayOf(timestep), 1)
                .use { timestepTensor ->
                    createHalfTensor(
                        environment, encoderHiddenStates, 2, 77, 768
                    ).use { encoderTensor ->
                        session.run(
                            mapOf(
                                unetSampleInput to sampleTensor,
                                unetTimestepInput to timestepTensor,
                                unetEncoderInput to encoderTensor
                            )
                        ).use { result ->
                            return flattenToFloat(result.get(0).value, fp16 = true)
                        }
                    }
                }
        }
    }

    /** VAE decoder: latents [1, 4, 64, 64] -> image [1, 3, 512, 512]. */
    private fun runVaeDecoder(session: OrtSession, latents: FloatArray): FloatArray {
        val environment = env
            ?: throw IllegalStateException("Image model load nahi hua")
        createHalfTensor(environment, latents, 1, 4, 64, 64).use { input ->
            session.run(mapOf(vaeInput to input)).use { result ->
                return flattenToFloat(result.get(0).value, fp16 = true)
            }
        }
    }

    companion object {
        private const val GUIDANCE_SCALE = 7.5f
        private const val VAE_SCALE = 0.18215f
        private const val IMAGE_SIZE = 512
        private const val LATENT_SIZE = 4 * 64 * 64 // 16384
        private const val EMBEDDING_SIZE = 77 * 768 // 59136
    }
}
