package com.aistudio.offline.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import net.ladenthin.llama.LlamaModel
import net.ladenthin.llama.LogFormat
import net.ladenthin.llama.parameters.InferenceParameters
import net.ladenthin.llama.parameters.ModelParameters

/**
 * Text engine backed by llama.cpp through the prebuilt AAR
 * `net.ladenthin:llama-android:6.0.0` (Maven Central).
 *
 * API shapes verified against the upstream README
 * (github.com/bernardladenthin/java-llama.cpp, "Chat Completion" and
 * "Kotlin Flow (Android / coroutines)" sections, read 27 Nov 2026):
 *   - `LlamaModel(ModelParameters().setModel(path))` — AutoCloseable.
 *   - `model.generateChat(InferenceParameters("").withMessages(system, msgs).withNPredict(n))`
 *     returns an Iterable<LlamaOutput>; printing an output yields its token text.
 *   - Hand-rolled streaming: `model.generate(params).use { for (output in it) emit(output) }`
 *     — wrapping the loop in `.use {}` makes coroutine cancellation close the
 *     iterator and stop generation mid-stream.
 *   - `LlamaModel.setLogger(LogFormat.TEXT, callback)` is static; a no-op
 *     callback silences llama.cpp's stderr chatter.
 *
 * Notes / fallbacks (see README.md in the project root):
 *   - If `generateChat`'s iterable ever stops supporting `.use {}`, switch to
 *     `model.generate(...)` with a manually built ChatML prompt
 *     (`<|im_start|>system ... <|im_end|> ...`) — the format is documented on
 *     the Qwen2.5 HF model card.
 *   - Context size is left at the llama.cpp default (not overridden — no
 *     verified setter name in the README). Sampling is left at the model
 *     defaults for the same reason; only max tokens are set.
 *   - stop() is a no-op by design: the ViewModel cancels the coroutine that
 *     is collecting generate(), and the flow's `.use {}` closes the iterator.
 */
class LlmEngineImpl : LlmEngine {

    private var model: LlamaModel? = null
    private var loadedPath: String? = null

    override val isLoaded: Boolean
        get() = model != null

    override suspend fun load(modelPath: String): Result<Unit> = runCatching {
        if (loadedPath == modelPath && model != null) return@runCatching
        unload()
        // Silence llama.cpp's per-request INFO lines (verified static API).
        LlamaModel.setLogger(LogFormat.TEXT) { _, _ -> }
        val params = ModelParameters().setModel(modelPath)
        model = LlamaModel(params)
        loadedPath = modelPath
    }

    override fun unload() {
        model?.close()
        model = null
        loadedPath = null
    }

    override fun stop() {
        // No-op by design — see the class doc. Generation stops when the
        // collecting coroutine is cancelled (StudioViewModel.stopChat
        // cancels chatJob first, then calls this).
    }

    override suspend fun generate(
        messages: List<Pair<String, String>>,
        onToken: (String) -> Unit
    ) {
        val current = model ?: throw IllegalStateException("LLM model is not loaded")
        val params = InferenceParameters("")
            .withMessages(SYSTEM_PROMPT, messages)
            .withNPredict(MAX_TOKENS)
        // Streaming exactly as the upstream README's hand-rolled Flow pattern.
        flow {
            current.generateChat(params).use { iterable ->
                for (output in iterable) {
                    emit(output.toString())
                }
            }
        }.flowOn(Dispatchers.IO).collect { token -> onToken(token) }
    }

    companion object {
        private const val SYSTEM_PROMPT =
            "You are a helpful assistant running fully offline on the user's phone. " +
                "Answer clearly and concisely."
        private const val MAX_TOKENS = 512
    }
}
