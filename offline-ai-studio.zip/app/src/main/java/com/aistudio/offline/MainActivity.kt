package com.aistudio.offline

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aistudio.offline.ui.StudioViewModel
import com.aistudio.offline.ui.screens.ChatScreen
import com.aistudio.offline.ui.screens.ImagesScreen
import com.aistudio.offline.ui.screens.ModelsScreen
import com.aistudio.offline.ui.theme.AIStudioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AIStudioTheme {
                AIStudioApp()
            }
        }
    }
}

private enum class Tab(val label: String) {
    CHAT("Chat"),
    IMAGES("Images"),
    MODELS("Models")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AIStudioApp() {
    val viewModel: StudioViewModel = viewModel()
    // Plain remember (not rememberSaveable): the enum tab has no saver,
    // and losing the tab across process death is trivial.
    var tab by remember { mutableStateOf(Tab.CHAT) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI Studio") },
                actions = {
                    Text(
                        text = "100% Offline • No API",
                        style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(end = 16.dp)
                    )
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == Tab.CHAT,
                    onClick = { tab = Tab.CHAT },
                    icon = {
                        Icon(
                            imageVector = Icons.Filled.ChatBubbleOutline,
                            contentDescription = null
                        )
                    },
                    label = { Text("Chat") }
                )
                NavigationBarItem(
                    selected = tab == Tab.IMAGES,
                    onClick = { tab = Tab.IMAGES },
                    icon = {
                        Icon(
                            imageVector = Icons.Filled.Image,
                            contentDescription = null
                        )
                    },
                    label = { Text("Images") }
                )
                NavigationBarItem(
                    selected = tab == Tab.MODELS,
                    onClick = { tab = Tab.MODELS },
                    icon = {
                        Icon(
                            imageVector = Icons.Filled.Download,
                            contentDescription = null
                        )
                    },
                    label = { Text("Models") }
                )
            }
        }
    ) { padding ->
        androidx.compose.foundation.layout.Box(
            modifier = Modifier.padding(padding)
        ) {
            when (tab) {
                Tab.CHAT -> ChatScreen(viewModel)
                Tab.IMAGES -> ImagesScreen(viewModel)
                Tab.MODELS -> ModelsScreen(viewModel)
            }
        }
    }
}
