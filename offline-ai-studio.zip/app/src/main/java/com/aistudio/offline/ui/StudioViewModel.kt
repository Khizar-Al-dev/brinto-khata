package com.aistudio.offline.ui

import android.app.Application
import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aistudio.offline.ai.AiEngines
import com.aistudio.offline.ai.ImageEngine
import com.aistudio.offline.ai.LlmEngine
import com.aistudio.offline.data.ChatMessage
import com.aistudio.offline.data.DownloadProgress
import com.aistudio.offline.data.DownloadStatus
import com.aistudio.offline.data.HistoryStore
import com.aistudio.offline.data.ImageRecord
import com.aistudio.offline.data.ModelCatalog
import com.aistudio.offline.data.ModelDownloader
import com.aistudio.offline.data.ModelSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class EngineState { NOT_LOADED, LOADING, READY, ERROR }

class StudioViewModel(app: Application) : AndroidViewModel(app) {

    private val historyStore = HistoryStore(app)
    private val downloader = ModelDownloader(app)

    val chatModel: ModelSpec = ModelCatalog.chatModel
    val imageModel: ModelSpec = ModelCatalog.imageModel

    private val llm: LlmEngine = AiEngines.createLlmEngine()
    private val imageEngine: ImageEngine = AiEngines.createImageEngine()

    // ---- Chat ----
    var chatMessages by mutableStateOf(historyStore.loadChat())
        private set
    var chatGenerating by mutableStateOf(false)
        private set
    var chatError by mutableStateOf<String?>(null)
        private set
    var chatEngineState by mutableStateOf(EngineState.NOT_LOADED)
        private set
    private var chatJob: Job? = null

    // ---- Images ----
    var imagePrompt by mutableStateOf("")
        private set
    var imageSteps by mutableStateOf(20)
        private set
    var imageSeed by mutableStateOf<Long?>(null)
        private set
    var imageGenerating by mutableStateOf(false)
        private set
    var imageProgress by mutableStateOf(0f)
        private set
    var imageProgressText by mutableStateOf("")
        private set
    var currentImage by mutableStateOf<Bitmap?>(null)
        private set
    var currentImageRecord by mutableStateOf<ImageRecord?>(null)
        private set
    var imageHistory by mutableStateOf(historyStore.loadImageIndex())
        private set
    var imageError by mutableStateOf<String?>(null)
        private set
    var imageEngineState by mutableStateOf(EngineState.NOT_LOADED)
        private set
    private var imageJob: Job? = null

    init {
        downloader.refreshStatus(chatModel)
        downloader.refreshStatus(imageModel)
    }

    // ---- Downloads ----

    fun downloadProgress(spec: ModelSpec): StateFlow<DownloadProgress> =
        downloader.progressOf(spec.id)

    fun isModelComplete(spec: ModelSpec): Boolean = downloader.isComplete(spec)

    fun startDownload(spec: ModelSpec) {
        downloader.refreshStatus(spec)
        downloader.start(spec)
    }

    fun pauseDownload(spec: ModelSpec) = downloader.pause(spec.id)

    fun onPromptChange(value: String) {
        imagePrompt = value
    }

    fun onStepsChange(value: Int) {
        imageSteps = value.coerceIn(4, 50)
    }

    fun onSeedChange(value: Long?) {
        imageSeed = value
    }

    // ---- Chat ----

    fun sendChat(userText: String) {
        val text = userText.trim()
        if (text.isEmpty() || chatGenerating) return
        if (!downloader.isComplete(chatModel)) {
            chatError = "Pehle chat model download karein (Models tab)."
            return
        }
        chatError = null
        val updated = chatMessages + ChatMessage("user", text) +
            ChatMessage("assistant", "")
        chatMessages = updated
        chatGenerating = true
        chatJob = viewModelScope.launch(Dispatchers.Default) {
            try {
                if (!llm.isLoaded) {
                    withContext(Dispatchers.Main) { chatEngineState = EngineState.LOADING }
                    val modelFile = downloader.modelDir(chatModel)
                        .resolve(chatModel.files.first().fileName)
                    val loaded = llm.load(modelFile.absolutePath)
                    if (loaded.isFailure) {
                        throw loaded.exceptionOrNull()
                            ?: IllegalStateException("Model load nahi ho saka")
                    }
                    withContext(Dispatchers.Main) { chatEngineState = EngineState.READY }
                }
                val history = chatMessages
                    .filter { it.content.isNotEmpty() }
                    .map { it.role to it.content }
                val reply = StringBuilder()
                llm.generate(history) { token ->
                    reply.append(token)
                    val snapshot = reply.toString()
                    chatMessages = chatMessages.dropLast(1) +
                        ChatMessage("assistant", snapshot)
                }
                val finalMessages = chatMessages
                withContext(Dispatchers.IO) { historyStore.saveChat(finalMessages) }
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                withContext(Dispatchers.Main) {
                    chatEngineState = EngineState.ERROR
                    chatError = "Jawab nahi ban saka: ${e.message ?: "unknown error"}"
                    // Drop the empty assistant bubble on failure.
                    chatMessages = chatMessages.filter { it.content.isNotEmpty() }
                }
            } finally {
                withContext(Dispatchers.Main) { chatGenerating = false }
            }
        }
    }

    fun stopChat() {
        chatJob?.cancel()
        llm.stop()
        chatGenerating = false
    }

    fun newChat() {
        stopChat()
        chatMessages = emptyList()
        viewModelScope.launch(Dispatchers.IO) { historyStore.clearChat() }
    }

    // ---- Images ----

    fun generateImage() {
        val prompt = imagePrompt.trim()
        if (prompt.isEmpty() || imageGenerating) return
        if (!downloader.isComplete(imageModel)) {
            imageError = "Pehle image model download karein (Models tab)."
            return
        }
        imageError = null
        val steps = imageSteps
        val seed = imageSeed ?: (System.currentTimeMillis() % 1_000_000L)
        imageGenerating = true
        imageProgress = 0f
        imageProgressText = "Model load ho raha hai…"
        imageJob = viewModelScope.launch(Dispatchers.Default) {
            try {
                if (!imageEngine.isLoaded) {
                    withContext(Dispatchers.Main) {
                        imageEngineState = EngineState.LOADING
                    }
                    val loaded = imageEngine.load(
                        downloader.modelDir(imageModel).absolutePath
                    )
                    if (loaded.isFailure) {
                        throw loaded.exceptionOrNull()
                            ?: IllegalStateException("Image model load nahi ho saka")
                    }
                    withContext(Dispatchers.Main) {
                        imageEngineState = EngineState.READY
                    }
                }
                withContext(Dispatchers.Main) {
                    imageProgressText = "Image ban rahi hai… (0/$steps steps)"
                }
                val result = imageEngine.generate(prompt, steps, seed) { done, total ->
                    imageProgress = if (total > 0) done.toFloat() / total else 0f
                    imageProgressText = "Image ban rahi hai… ($done/$total steps)"
                }
                val bitmap = result.getOrThrow()
                currentImage = bitmap
                val record = withContext(Dispatchers.IO) {
                    historyStore.saveGeneratedImage(bitmap, prompt, seed, steps)
                }
                currentImageRecord = record
                imageHistory = historyStore.loadImageIndex()
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                withContext(Dispatchers.Main) {
                    imageEngineState = EngineState.ERROR
                    imageError = "Image nahi ban saki: ${e.message ?: "unknown error"}"
                }
            } finally {
                withContext(Dispatchers.Main) {
                    imageGenerating = false
                    imageProgressText = ""
                }
            }
        }
    }

    fun stopImageGeneration() {
        imageJob?.cancel()
        imageGenerating = false
        imageProgressText = ""
    }

    fun selectHistoryImage(record: ImageRecord) {
        viewModelScope.launch(Dispatchers.IO) {
            val file = historyStore.imageFile(record)
            if (!file.exists()) return@launch
            val bitmap = android.graphics.BitmapFactory.decodeFile(file.absolutePath)
            withContext(Dispatchers.Main) {
                currentImage = bitmap
                currentImageRecord = record
                imagePrompt = record.prompt
            }
        }
    }

    fun saveCurrentImageToGallery(onDone: (Boolean) -> Unit) {
        val bitmap = currentImage ?: run { onDone(false); return }
        val record = currentImageRecord
        viewModelScope.launch(Dispatchers.IO) {
            val name = "AI-Studio-${record?.timestamp ?: System.currentTimeMillis()}.png"
            val ok = historyStore.saveToGallery(bitmap, name)
            withContext(Dispatchers.Main) { onDone(ok) }
        }
    }

    override fun onCleared() {
        super.onCleared()
        try { llm.unload() } catch (_: Exception) { }
        try { imageEngine.unload() } catch (_: Exception) { }
    }
}
