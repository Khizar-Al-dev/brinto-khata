package com.aistudio.offline.data

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/**
 * On-device-only storage: chat history + generated-image history.
 * Nothing leaves the phone. Uses org.json (built into Android) —
 * no extra dependency.
 */
class HistoryStore(private val context: Context) {

    private val chatFile get() = File(context.filesDir, "chat_history.json")
    private val imageIndexFile get() = File(context.filesDir, "images_index.json")
    private val imagesDir get() = File(context.filesDir, "images").apply { mkdirs() }

    // ---- Chat history (single current conversation) ----

    fun loadChat(): List<ChatMessage> {
        return try {
            if (!chatFile.exists()) return emptyList()
            val arr = JSONArray(chatFile.readText())
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                ChatMessage(
                    role = o.optString("role", "user"),
                    content = o.optString("content", ""),
                    timestamp = o.optLong("timestamp", 0L)
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveChat(messages: List<ChatMessage>) = try {
        val arr = JSONArray()
        for (m in messages) {
            arr.put(JSONObject().apply {
                put("role", m.role)
                put("content", m.content)
                put("timestamp", m.timestamp)
            })
        }
        chatFile.writeText(arr.toString())
    } catch (_: Exception) {
        // History is a nice-to-have; a failed write must not break chat.
    }

    fun clearChat() {
        try { chatFile.delete() } catch (_: Exception) { }
    }

    // ---- Generated images ----

    /** Saves a generated bitmap as PNG in app-private storage + index. */
    fun saveGeneratedImage(bitmap: Bitmap, prompt: String, seed: Long, steps: Int): ImageRecord? {
        return try {
            val fileName = "img_${System.currentTimeMillis()}.png"
            FileOutputStream(File(imagesDir, fileName)).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            val record = ImageRecord(fileName, prompt, seed, steps)
            val records = loadImageIndex().toMutableList().apply { add(0, record) }
            saveImageIndex(records)
            record
        } catch (_: Exception) {
            null
        }
    }

    fun loadImageIndex(): List<ImageRecord> {
        return try {
            if (!imageIndexFile.exists()) return emptyList()
            val arr = JSONArray(imageIndexFile.readText())
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                ImageRecord(
                    fileName = o.optString("fileName", ""),
                    prompt = o.optString("prompt", ""),
                    seed = o.optLong("seed", 0L),
                    steps = o.optInt("steps", 0),
                    timestamp = o.optLong("timestamp", 0L)
                )
            }.filter { it.fileName.isNotEmpty() && File(imagesDir, it.fileName).exists() }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun saveImageIndex(records: List<ImageRecord>) = try {
        val arr = JSONArray()
        for (r in records) {
            arr.put(JSONObject().apply {
                put("fileName", r.fileName)
                put("prompt", r.prompt)
                put("seed", r.seed)
                put("steps", r.steps)
                put("timestamp", r.timestamp)
            })
        }
        imageIndexFile.writeText(arr.toString())
    } catch (_: Exception) { }

    fun imageFile(record: ImageRecord): File = File(imagesDir, record.fileName)

    /** Copies an image into the public gallery (Pictures/AI Studio). */
    suspend fun saveToGallery(bitmap: Bitmap, displayName: String): Boolean =
        withContext(Dispatchers.IO) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
                        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                        put(
                            MediaStore.Images.Media.RELATIVE_PATH,
                            Environment.DIRECTORY_PICTURES + "/AI Studio"
                        )
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                    val resolver = context.contentResolver
                    val uri = resolver.insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
                    ) ?: return@withContext false
                    resolver.openOutputStream(uri)?.use { out ->
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    }
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    true
                } else {
                    @Suppress("DEPRECATION")
                    val pictures = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_PICTURES
                    )
                    val dir = File(pictures, "AI Studio").apply { mkdirs() }
                    val file = File(dir, displayName)
                    FileOutputStream(file).use { out ->
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    }
                    true
                }
            } catch (_: Exception) {
                false
            }
        }
}
