# Keep JNI entry points (llama.cpp / ONNX Runtime) from being stripped.
-keep class com.aistudio.offline.ai.** { *; }
