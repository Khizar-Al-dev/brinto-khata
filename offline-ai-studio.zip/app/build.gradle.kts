plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.aistudio.offline"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.aistudio.offline"
        // llama-android AAR (net.ladenthin:llama-android) enforces minSdk 28
        // in its manifest — Android 9+ only. Raised from 26 for that reason.
        minSdk = 28
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // llama.cpp / ONNX Runtime ship ARM64 native libs.
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
        // Native .so files from llama.cpp / ONNX Runtime: keep them
        // uncompressed so they load directly from the APK.
        jniLibs {
            useLegacyPackaging = false
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.5")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.5")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3:1.3.0")
    implementation("androidx.compose.material:material-icons-extended")

    // ---- On-device AI (verified 27 Nov 2026) ----
    // llama.cpp via the prebuilt AAR — no NDK/CMake build needed.
    // https://github.com/bernardladenthin/java-llama.cpp — README "Importing in Android",
    // Option 1 (recommended). 6.0.0 released 26 Oct 2026, Maven Central.
    implementation("net.ladenthin:llama-android:6.0.0")
    // (The companion `net.ladenthin:llama-kotlin` Flow facade is NOT
    // depended on: the engine uses the README's hand-rolled Flow pattern
    // instead, so the extra artifact would only add size.)

    // ONNX Runtime Mobile — Stable Diffusion image model.
    // Verified 27 Nov 2026: com.microsoft.onnxruntime:onnxruntime-android
    // 1.32.0 (Maven Central, released 14 Nov 2026). AAR inspected:
    // arm64-v8a + armeabi-v7a + x86 + x86_64, minSdk 24, 16 KB page-size
    // aligned. API: OrtEnvironment / OrtSession / OnnxTensor.
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.32.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
