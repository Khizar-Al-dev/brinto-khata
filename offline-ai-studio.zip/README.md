# AI Studio — on-device AI, fully offline

Native Kotlin / Jetpack Compose Android app (package `com.aistudio.offline`,
label "AI Studio"). Two tabs: **Chat** (text) and **Images**. No Firebase,
no login, no analytics, no API keys anywhere. `INTERNET` permission is used
**only** for the one-time model download from Hugging Face (free, no key,
no account). After that, everything runs on the phone with no network calls.

## What it does

- **Chat tab** — chat-style UI, streaming replies from a local GGUF LLM
  (llama.cpp). Conversation history stays on-device (`chat_history.json`).
- **Images tab** — prompt + Generate + step progress, 512×512 image from a
  local Stable Diffusion 1.5 model. Save to gallery (MediaStore,
  Pictures/AI Studio) + small on-device history.
- **Models tab** — downloads both models once (~3 GB total, WiFi
  recommended) with progress bar + pause/resume (HTTP Range).

## Stack (all verified 27 Nov 2026)

| Piece | Choice |
|---|---|
| Text LLM | llama.cpp via prebuilt AAR `net.ladenthin:llama-android:6.0.0` (+ `net.ladenthin:llama-kotlin:6.0.0` facade). Maven Central, released 26 Oct 2026. No NDK/CMake build. **minSdk 28** (enforced by the AAR). |
| Chat model | `bartowski/Qwen2.5-1.5B-Instruct-GGUF`, file `Qwen2.5-1.5B-Instruct-Q4_K_M.gguf`, **986,048,768 bytes** (~0.99 GB). |
| Image model | ONNX Runtime Mobile `com.microsoft.onnxruntime:onnxruntime-android:1.32.0` (Maven Central, 14 Nov 2026; AAR minSdk 24, 16 KB page aligned). |
| SD model | `nmkd/stable-diffusion-1.5-onnx-fp16` (FP16 export of Runway SD 1.5), txt2img total ~1,971 MB: `text_encoder/model.onnx` (~235 MB), `unet/model.onnx` (~1.2 MB) + `unet/weights.pb` (~1,639 MB, external-data sidecar — must sit next to `model.onnx`), `vae_decoder/model.onnx` (~94.5 MB), `tokenizer/vocab.json` + `merges.txt`, `scheduler/scheduler_config.json`. |
| Image pipeline | 3 ORT sessions (text encoder, UNet, VAE decoder); CLIP BPE tokenizer implemented in Kotlin (`ClipTokenizer.kt`); DDIM sampler in Kotlin (`DdimScheduler.kt`, scaled-linear betas, eta=0); classifier-free guidance 7.5; VAE scale 0.18215. Execution providers tried in order: NNAPI → XNNPACK → CPU. |
| Build | AGP 8.5.2, Kotlin 2.0.20, Gradle 8.7, JDK 17, targetSdk 34, minSdk 28, `arm64-v8a` only. |

## Project layout

```
app/src/main/java/com/aistudio/offline/
  MainActivity.kt            Bottom-nav scaffold (Chat / Images / Models)
  ai/
    LlmEngine.kt / LlmEngineImpl.kt       llama.cpp chat (streaming)
    ImageEngine.kt / ImageEngineImpl.kt   ONNX SD 1.5 pipeline
    ClipTokenizer.kt                      CLIP byte-level BPE (Kotlin)
    DdimScheduler.kt                      DDIM sampler (Kotlin)
    TensorUtil.kt                         FP16 <-> float, ORT tensor helpers
    AiEngines.kt                          factory
  data/
    Models.kt / ModelCatalog.kt           model specs + verified URLs/sizes
    ModelDownloader.kt                    resumable HF downloads (Range + .part)
    HistoryStore.kt                       on-device chat + image history
  ui/
    StudioViewModel.kt                    chat/image/download state
    screens/ChatScreen.kt, ImagesScreen.kt, ModelsScreen.kt
    theme/Theme.kt                        dark Material 3 (violet accent)
```

## Build (parent / GitHub Actions)

Local Gradle is blocked on this VM (direct TCP Deny), so the build runs
through GitHub Actions like the other apps (reuse the `brinto-khata` repo
pattern: zip this project, upload, workflow unzips + `:app:assembleDebug`).
Do **not** bundle the ~3 GB of models in the APK — they download at first
run into `filesDir/models/`.

## Honest limits / open risks

1. **Image speed on Redmi Note 13 (Snapdragon 685): ~1–3 min per image**
   at 20 steps (NNAPI-mixed; CPU-only likely 2–4 min). No published
   benchmark exists for the 685 specifically — this is scaled from
   stronger-chip anchors. The phone will get warm on repeated generations.
   A 4-step LCM setup would be ~5× faster but needs a desktop Python
   re-export to ONNX FP16 first (v2, unverified end-to-end).
2. **RAM is the biggest risk.** On the CPU provider ORT promotes the FP16
   UNet to ~3.5 GB resident — on a 6 GB Redmi Note 13 that will very
   likely OOM/get killed. NNAPI-first is the realistic path; the 8 GB
   phone variant is the safer minimum. Test on the real device.
3. **Chat speed:** ~5–15 tokens/sec CPU for the 1.5B Q4 model (guide-level
   estimate, not measured). Context size is left at the llama.cpp default
   (no verified setter name in the upstream README); max reply 512 tokens.
4. **No official Microsoft SD Android sample exists** — the pipeline was
   written from the generic ORT Android pattern + the TensorChat reference
   (same model files). Input/output node names are resolved from each
   session's own metadata at load, with the standard diffusers names as
   first choice; if an export renames a node, generation throws a clear
   error naming the session.
5. **Model file sizes in ModelCatalog are rounded DOWN** on purpose (see
   the comment there) so the downloader's completeness check can never
   falsely fail; small files use size 0 (Content-Length fallback).
6. **No safety checker** is bundled (`safety_checker/model.onnx` is
   skipped); the SD 1.5 model is under the CreativeML OpenRAIL-M licence.
7. **First-run UX:** ~3 GB download needs WiFi + patience; session load
   takes seconds and gigabytes of RAM — the UI shows loading states.
8. **Not compile-verified on this VM** (local Gradle blocked). Verified by
   careful reading: balanced braces/imports, every referenced symbol
   exists, library coordinates + model URLs checked against their sources.
   The first real compile happens in GitHub Actions — expect at most
   small API-shape fixes there (most likely candidates: ORT
   `SessionOptions`/`OnnxTensor` overloads and the `generateChat`
   iterable's `.use {}` support, both with fallbacks noted in code).
