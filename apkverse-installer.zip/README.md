# APK Verse — personal APK installer

Chrome se download ki hui APKs ko aik jagah dikhata hai aur aik tap par
install karta hai (Android ke PackageInstaller session API se — aakhri
"Install" confirmation Android ki apni hoti hai, ye security rule hai).

## Features (v1)
- Downloads folder ki saari .apk files ki list — naam, icon, version, size, date
- Har APK par: pehle se installed hai ya nahi, update available hai ya nahi
- INSTALL / UPDATE button — PackageInstaller session se install
- Kisi bhi jagah ki APK file chuno (file picker) aur install karo
- APK delete karo

## Permissions (pehli dafa)
1. **All Files Access** — Downloads folder dekhne ke liye (app khud guide karegi)
2. **Install unknown apps** — Install dabate hi system khud poochhega

## Build
GitHub Actions workflow `build-apkverse-apk.yml` — zip push par auto-build.
Package: `com.apkverse.installer`, minSdk 26, targetSdk 34.
