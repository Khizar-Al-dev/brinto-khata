package com.apkverse.installer

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Environment
import java.io.File

data class ApkItem(
    val file: File,
    val label: String,
    val packageName: String?,
    val versionName: String?,
    val versionCode: Long,
    val sizeBytes: Long,
    val lastModified: Long,
    val icon: Drawable?,
    val installedVersionName: String?,
    val installedVersionCode: Long,
) {
    val isInstalled: Boolean get() = installedVersionCode >= 0
    val isUpdate: Boolean get() = isInstalled && versionCode > installedVersionCode
}

object ApkScanner {
    fun downloadsDir(): File =
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)

    fun scan(context: Context): List<ApkItem> {
        val dir = downloadsDir()
        val files = dir.listFiles()
            ?.filter { it.isFile && it.name.endsWith(".apk", ignoreCase = true) }
            ?: emptyList()
        val pm = context.packageManager
        return files.sortedByDescending { it.lastModified() }
            .mapNotNull { parseApk(pm, it) }
    }

    fun parseApk(pm: PackageManager, file: File): ApkItem? {
        val info: PackageInfo = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageArchiveInfo(file.absolutePath, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageArchiveInfo(file.absolutePath, 0)
            } ?: return null
        } catch (e: Exception) {
            return null
        }
        val appInfo = info.applicationInfo ?: return null
        appInfo.sourceDir = file.absolutePath
        appInfo.publicSourceDir = file.absolutePath
        val label = try {
            pm.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
            file.nameWithoutExtension
        }
        val icon = try {
            pm.getApplicationIcon(appInfo)
        } catch (e: Exception) {
            null
        }
        val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            info.versionCode.toLong()
        }
        var installedName: String? = null
        var installedCode: Long = -1
        val pkg = info.packageName
        if (pkg != null) {
            try {
                val installed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
                } else {
                    @Suppress("DEPRECATION")
                    pm.getPackageInfo(pkg, 0)
                }
                installedName = installed.versionName
                installedCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    installed.longVersionCode
                } else {
                    @Suppress("DEPRECATION")
                    installed.versionCode.toLong()
                }
            } catch (e: Exception) {
                // Not installed — leave defaults.
            }
        }
        return ApkItem(
            file = file,
            label = label,
            packageName = pkg,
            versionName = info.versionName,
            versionCode = versionCode,
            sizeBytes = file.length(),
            lastModified = file.lastModified(),
            icon = icon,
            installedVersionName = installedName,
            installedVersionCode = installedCode,
        )
    }
}
