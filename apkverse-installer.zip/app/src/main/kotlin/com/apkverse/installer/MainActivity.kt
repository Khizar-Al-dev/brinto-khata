package com.apkverse.installer

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ApkVerseApp() }
    }
}

private val Midnight = Color(0xFF0B0D0F)
private val Charcoal = Color(0xFF15191D)
private val CardBg = Color(0xFF1B2025)
private val NeonLime = Color(0xFFB8F34A)
private val White = Color(0xFFFFFFFF)
private val SteelGrey = Color(0xFF9299A1)
private val SoftRed = Color(0xFFFF6B6B)

fun hasAllFilesAccess(): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        true
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApkVerseApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<ApkItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var query by remember { mutableStateOf("") }
    var hasAllFiles by remember { mutableStateOf(hasAllFilesAccess()) }
    val installStates by InstallStatus.states.collectAsState()
    val installMessages by InstallStatus.messages.collectAsState()

    fun refresh() {
        loading = true
        hasAllFiles = hasAllFilesAccess()
        scope.launch {
            val list = withContext(Dispatchers.IO) { ApkScanner.scan(context) }
            items = list
            loading = false
        }
    }

    val pickApk = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            ApkInstaller.installUri(context, uri)
        }
    }

    LaunchedEffect(Unit) { refresh() }

    val filtered = remember(items, query) {
        if (query.isBlank()) {
            items
        } else {
            items.filter {
                it.label.contains(query, ignoreCase = true) ||
                    (it.packageName ?: "").contains(query, ignoreCase = true)
            }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = NeonLime,
            background = Midnight,
            surface = CardBg,
            onBackground = White,
            onSurface = White,
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("APK Verse", fontWeight = FontWeight.Black, fontSize = 20.sp)
                            Text(
                                "Chrome APKs — aik tap par install",
                                color = SteelGrey,
                                fontSize = 12.sp,
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Midnight),
                )
            },
            containerColor = Midnight,
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp),
            ) {
                if (!hasAllFiles) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CardBg),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text("Files ki permission chahiye", fontWeight = FontWeight.Bold)
                            Text(
                                "Downloads folder ki APKs dekhne ke liye All Files Access dein.",
                                color = SteelGrey,
                                fontSize = 13.sp,
                            )
                            Spacer(Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    val intent = Intent(
                                        Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                        Uri.parse("package:" + context.packageName),
                                    )
                                    context.startActivity(intent)
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NeonLime,
                                    contentColor = Midnight,
                                ),
                            ) {
                                Text("Permission dein")
                            }
                        }
                    }
                }
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search APK...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            pickApk.launch(arrayOf("application/vnd.android.package-archive"))
                        },
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.Filled.FolderOpen, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("APK file chuno")
                    }
                    OutlinedButton(
                        onClick = { refresh() },
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Refresh")
                    }
                }
                Spacer(Modifier.height(12.dp))
                if (loading) {
                    Box(
                        Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center,
                    ) {
                        CircularProgressIndicator(color = NeonLime)
                    }
                } else if (filtered.isEmpty()) {
                    Box(
                        Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Filled.Download,
                                contentDescription = null,
                                tint = SteelGrey,
                                modifier = Modifier.size(48.dp),
                            )
                            Spacer(Modifier.height(12.dp))
                            Text(
                                if (items.isEmpty()) "Downloads mein koi APK nahi mili"
                                else "Kuch nahi mila",
                                color = SteelGrey,
                            )
                            Text(
                                "Chrome se APK download karein, phir yahan aayegi.",
                                color = SteelGrey,
                                fontSize = 13.sp,
                            )
                        }
                    }
                } else {
                    Text("${filtered.size} APKs", color = SteelGrey, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(filtered, key = { it.file.absolutePath }) { item ->
                            ApkCard(
                                item = item,
                                state = installStates[item.file.absolutePath]
                                    ?: InstallState.IDLE,
                                message = installMessages[item.file.absolutePath] ?: "",
                                onInstall = {
                                    val pm = context.packageManager
                                    if (!pm.canRequestPackageInstalls()) {
                                        val intent = Intent(
                                            Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                            Uri.parse("package:" + context.packageName),
                                        )
                                        context.startActivity(intent)
                                    } else {
                                        ApkInstaller.installFile(context, item.file)
                                    }
                                },
                                onDelete = {
                                    scope.launch {
                                        withContext(Dispatchers.IO) { item.file.delete() }
                                        refresh()
                                    }
                                },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ApkCard(
    item: ApkItem,
    state: InstallState,
    message: String,
    onInstall: () -> Unit,
    onDelete: () -> Unit,
) {
    var iconBitmap by remember(item.file.absolutePath) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(item.file.absolutePath) {
        withContext(Dispatchers.IO) {
            iconBitmap = try {
                item.icon?.toBitmap(96, 96)
            } catch (e: Exception) {
                null
            }
        }
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(16.dp),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (iconBitmap != null) {
                Image(
                    bitmap = iconBitmap!!.asImageBitmap(),
                    contentDescription = null,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp)),
                )
            } else {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Charcoal),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.Download, contentDescription = null, tint = NeonLime)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.label, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
                Text(item.packageName ?: "", color = SteelGrey, fontSize = 12.sp, maxLines = 1)
                Text(
                    "v${item.versionName ?: "?"} • ${formatSize(item.sizeBytes)} • ${formatDate(item.lastModified)}",
                    color = SteelGrey,
                    fontSize = 12.sp,
                )
                if (item.isInstalled) {
                    Text(
                        if (item.isUpdate) "Update available (installed v${item.installedVersionName})"
                        else "Installed v${item.installedVersionName}",
                        color = if (item.isUpdate) NeonLime else SteelGrey,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
                if (state == InstallState.FAILED && message.isNotEmpty()) {
                    Text(message, color = SoftRed, fontSize = 12.sp)
                }
                if (state == InstallState.SUCCESS) {
                    Text("Install ho gaya", color = NeonLime, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Button(
                    onClick = onInstall,
                    enabled = state != InstallState.INSTALLING &&
                        state != InstallState.WAITING_CONFIRM,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonLime,
                        contentColor = Midnight,
                    ),
                ) {
                    Text(
                        if (state == InstallState.INSTALLING || state == InstallState.WAITING_CONFIRM) "..."
                        else if (item.isUpdate) "UPDATE"
                        else "INSTALL",
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = SteelGrey)
                }
            }
        }
    }
}

fun formatSize(bytes: Long): String {
    val mb = bytes / 1_000_000.0
    return if (mb >= 1) {
        String.format(Locale.US, "%.1f MB", mb)
    } else {
        String.format(Locale.US, "%d KB", bytes / 1000)
    }
}

fun formatDate(ts: Long): String =
    SimpleDateFormat("d MMM yyyy", Locale.US).format(Date(ts))
