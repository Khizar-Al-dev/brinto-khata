package com.apkverse.installer

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

enum class InstallState { IDLE, INSTALLING, WAITING_CONFIRM, SUCCESS, FAILED }

object InstallStatus {
    private val _states = MutableStateFlow<Map<String, InstallState>>(emptyMap())
    val states: StateFlow<Map<String, InstallState>> = _states.asStateFlow()

    private val _messages = MutableStateFlow<Map<String, String>>(emptyMap())
    val messages: StateFlow<Map<String, String>> = _messages.asStateFlow()

    fun set(key: String, state: InstallState, message: String = "") {
        _states.value = _states.value + (key to state)
        if (message.isNotEmpty()) {
            _messages.value = _messages.value + (key to message)
        }
    }
}

object ApkInstaller {
    const val ACTION_STATUS = "com.apkverse.installer.INSTALL_STATUS"

    fun installFile(context: Context, file: File) {
        val key = file.absolutePath
        InstallStatus.set(key, InstallState.INSTALLING)
        try {
            val installer = context.packageManager.packageInstaller
            val params = PackageInstaller.SessionParams(
                PackageInstaller.SessionParams.MODE_FULL_INSTALL
            )
            val sessionId = installer.createSession(params)
            val session = installer.openSession(sessionId)
            session.openWrite("apk", 0, file.length()).use { out ->
                file.inputStream().use { input -> input.copyTo(out) }
                session.fsync(out)
            }
            session.commit(statusPendingIntent(context, sessionId, key).intentSender)
            session.close()
        } catch (e: Exception) {
            InstallStatus.set(key, InstallState.FAILED, e.message ?: "Install shuru nahi ho saka")
        }
    }

    fun installUri(context: Context, uri: Uri) {
        val key = uri.toString()
        InstallStatus.set(key, InstallState.INSTALLING)
        try {
            val installer = context.packageManager.packageInstaller
            val params = PackageInstaller.SessionParams(
                PackageInstaller.SessionParams.MODE_FULL_INSTALL
            )
            val sessionId = installer.createSession(params)
            val session = installer.openSession(sessionId)
            val input = context.contentResolver.openInputStream(uri)
                ?: throw IllegalStateException("File khul nahi saki")
            session.openWrite("apk", 0, -1).use { out ->
                input.use { it.copyTo(out) }
                session.fsync(out)
            }
            session.commit(statusPendingIntent(context, sessionId, key).intentSender)
            session.close()
        } catch (e: Exception) {
            InstallStatus.set(key, InstallState.FAILED, e.message ?: "Install shuru nahi ho saka")
        }
    }

    private fun statusPendingIntent(context: Context, sessionId: Int, key: String): PendingIntent {
        val statusIntent = Intent(context, InstallStatusReceiver::class.java).apply {
            action = ACTION_STATUS
            putExtra("apk_path", key)
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
        return PendingIntent.getBroadcast(context, sessionId, statusIntent, flags)
    }
}

class InstallStatusReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val key = intent.getStringExtra("apk_path") ?: return
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)
        when (status) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                InstallStatus.set(key, InstallState.WAITING_CONFIRM)
                val confirm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(Intent.EXTRA_INTENT)
                }
                confirm?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    context.startActivity(confirm)
                } catch (e: Exception) {
                    // The system confirmation could not be shown.
                }
            }
            PackageInstaller.STATUS_SUCCESS -> {
                InstallStatus.set(key, InstallState.SUCCESS, "Install ho gaya")
            }
            else -> {
                val msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)
                    ?: "Install nahi ho saka"
                InstallStatus.set(key, InstallState.FAILED, msg)
            }
        }
    }
}
