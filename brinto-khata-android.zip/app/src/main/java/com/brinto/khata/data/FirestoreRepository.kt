package com.brinto.khata.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

/**
 * Cloud layer: Firebase Auth (email/password) + Cloud Firestore.
 *
 * Collections:
 *   users/{uid}                 -> UserProfile (email, role). First user = admin.
 *   users/{uid}/customers/{id}  -> Customer (one document per khata entry)
 *   users/{uid}/history/{id}    -> HistoryEvent (SAVED / UPDATED / DELETED)
 *   users/{uid}/settings/stock  -> StockSettings
 *   users/{uid}/meta/migration  -> legacy-migration marker
 *
 * Cloud data lives in the SIGNED-IN Gmail's own space
 * (users/{uid}/...), so whichever Gmail signs in gets exactly
 * that Gmail's data back — nothing leaks between accounts.
 * Older builds wrote to the GLOBAL collections (customers /,
 * history /, settings/stock); the loadLegacy* methods read
 * those once per Gmail so old data is copied into the Gmail's
 * own space on first sync (see KhataRepository).
 *
 * Loads (loadCustomers / loadHistory / loadStock) let failures
 * propagate as exceptions, so a sync can tell "cloud is empty"
 * apart from "cloud could not be reached" — the caller reports
 * the failure instead of silently showing an empty khata.
 * Saves stay fire-and-forget: a failed save must never crash the
 * UI, and the next sync uploads the phone's copy again.
 *
 * If google-services.json is missing, Firebase will throw at runtime.
 * In that case the app still works locally with Room only — see
 * KhataRepository: every Firestore call is wrapped in try/catch.
 */
class FirestoreRepository {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()

    val currentUser: FirebaseUser? get() = auth.currentUser

    suspend fun signUp(email: String, password: String): Result<FirebaseUser> = runCatching {
        val result = auth.createUserWithEmailAndPassword(email, password).await()
        val user = result.user ?: throw IllegalStateException("Sign up failed")
        // First registered user becomes Admin, everyone after is a normal user.
        val usersSnapshot = db.collection("users").get().await()
        val role = if (usersSnapshot.isEmpty) "admin" else "user"
        val profile = UserProfile(uid = user.uid, email = email, role = role)
        db.collection("users").document(user.uid).set(profile.toMap()).await()
        user
    }

    suspend fun signIn(email: String, password: String): Result<FirebaseUser> = runCatching {
        val result = auth.signInWithEmailAndPassword(email, password).await()
        result.user ?: throw IllegalStateException("Login failed")
    }

    fun signOut() = auth.signOut()

    suspend fun getProfile(uid: String): UserProfile? = runCatching {
        val snap = db.collection("users").document(uid).get().await()
        snap.data?.let { UserProfile.fromMap(it) }
    }.getOrNull()

    suspend fun getAllUsers(): List<UserProfile> = runCatching {
        db.collection("users").get().await()
            .documents.mapNotNull { it.data?.let { data -> UserProfile.fromMap(data) } }
    }.getOrDefault(emptyList())

    suspend fun setUserRole(uid: String, role: String) {
        runCatching {
            db.collection("users").document(uid).update("role", role).await()
        }
    }

    /** Admin creates / issues another user account. */
    suspend fun createUserByAdmin(email: String, password: String): Result<Unit> = runCatching {
        // Firebase Auth only lets the currently signed-in user create an
        // account, so the admin's session is briefly replaced. To keep it
        // simple and safe, this helper creates the account and then signs
        // the admin back out — the admin signs in again with their own
        // email/password. In a production app, use a Cloud Function /
        // Admin SDK for this instead.
        auth.createUserWithEmailAndPassword(email, password).await()
        val newUser = auth.currentUser
        if (newUser != null) {
            db.collection("users").document(newUser.uid)
                .set(UserProfile(newUser.uid, email, "user").toMap()).await()
        }
        auth.signOut()
    }

    /** UID of the signed-in Gmail, or null when signed out. */
    val currentUid: String? get() = auth.currentUser?.uid

    /** True: this variant has a real cloud backend. */
    val cloudAvailable: Boolean = true

    private fun requireUid(): String =
        auth.currentUser?.uid ?: throw IllegalStateException("Not signed in")

    private fun userCollection(name: String) =
        db.collection("users").document(requireUid()).collection(name)

    suspend fun saveCustomer(customer: Customer) {
        runCatching {
            userCollection("customers").document(customer.id).set(customer.toMap()).await()
        }
    }

    /** Same write, but failures propagate — used by the sync push phase. */
    suspend fun saveCustomerStrict(customer: Customer) {
        userCollection("customers").document(customer.id).set(customer.toMap()).await()
    }

    suspend fun loadCustomers(): List<Customer> {
        return userCollection("customers").get().await()
            .documents.mapNotNull { it.data?.let { data -> Customer.fromMap(data) } }
    }

    suspend fun loadLegacyCustomers(): List<Customer> {
        return db.collection("customers").get().await()
            .documents.mapNotNull { it.data?.let { data -> Customer.fromMap(data) } }
    }

    suspend fun deleteCustomer(customerId: String) {
        runCatching {
            userCollection("customers").document(customerId).delete().await()
        }
        // Also remove the pre-scoping global copy, if one exists.
        runCatching {
            db.collection("customers").document(customerId).delete().await()
        }
    }

    suspend fun saveHistoryEvent(event: HistoryEvent) {
        runCatching {
            userCollection("history").document(event.id).set(event.toMap()).await()
        }
    }

    /** Same write, but failures propagate — used by the sync push phase. */
    suspend fun saveHistoryEventStrict(event: HistoryEvent) {
        userCollection("history").document(event.id).set(event.toMap()).await()
    }

    suspend fun loadHistory(): List<HistoryEvent> {
        return userCollection("history").get().await()
            .documents.mapNotNull { it.data?.let { data -> HistoryEvent.fromMap(data) } }
    }

    suspend fun loadLegacyHistory(): List<HistoryEvent> {
        return db.collection("history").get().await()
            .documents.mapNotNull { it.data?.let { data -> HistoryEvent.fromMap(data) } }
    }

    suspend fun saveStock(stock: StockSettings) {
        runCatching {
            userCollection("settings").document("stock").set(stock.toMap()).await()
        }
    }

    /** Same write, but failures propagate — used by the sync push phase. */
    suspend fun saveStockStrict(stock: StockSettings) {
        userCollection("settings").document("stock").set(stock.toMap()).await()
    }

    suspend fun loadStock(): StockSettings? {
        val snap = userCollection("settings").document("stock").get().await()
        return snap.data?.let { StockSettings.fromMap(it) }
    }

    suspend fun loadLegacyStock(): StockSettings? {
        val snap = db.collection("settings").document("stock").get().await()
        return snap.data?.let { StockSettings.fromMap(it) }
    }

    /** True once the old global collections were copied into this Gmail's space. */
    suspend fun isLegacyMigrated(): Boolean = runCatching {
        val snap = userCollection("meta").document("migration").get().await()
        snap.getBoolean("legacyMigrated") == true
    }.getOrDefault(false)

    suspend fun markLegacyMigrated() {
        runCatching {
            userCollection("meta").document("migration")
                .set(mapOf("legacyMigrated" to true)).await()
        }
    }
}
