package com.brinto.khata.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

/**
 * Cloud layer: Firebase Auth (email/password) + Cloud Firestore.
 *
 * Collections:
 *   users/{uid}        -> UserProfile (email, role). First user = admin.
 *   customers/{id}     -> Customer (one document per khata entry)
 *   settings/stock     -> StockSettings
 *
 * If google-services.json is missing, Firebase will throw at runtime.
 * In that case the app still works locally with Room only — see
 * KhataRepository: every Firestore call is wrapped in try/catch.
 */
class FirestoreRepository {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()

    val currentUser: FirebaseUser? get() = auth.currentUser

    suspend fun signUp(email: String, password: String): Result<FirebaseUser> = runCatching {
        val result = auth.createUserWithEmailAndPassword(email, password).await()
        val user = result.user ?: throw IllegalStateException("Sign up failed")
        // First registered user becomes Admin, everyone after is a normal user.
        val usersSnapshot = db.collection("users").get().await()
        val role = if (usersSnapshot.isEmpty) "admin" else "user"
        val profile = UserProfile(uid = user.uid, email = email, role = role)
        db.collection("users").document(user.uid).set(profile.toMap()).await()
        user
    }

    suspend fun signIn(email: String, password: String): Result<FirebaseUser> = runCatching {
        val result = auth.signInWithEmailAndPassword(email, password).await()
        result.user ?: throw IllegalStateException("Login failed")
    }

    fun signOut() = auth.signOut()

    suspend fun getProfile(uid: String): UserProfile? = runCatching {
        val snap = db.collection("users").document(uid).get().await()
        snap.data?.let { UserProfile.fromMap(it) }
    }.getOrNull()

    suspend fun getAllUsers(): List<UserProfile> = runCatching {
        db.collection("users").get().await()
            .documents.mapNotNull { it.data?.let { data -> UserProfile.fromMap(data) } }
    }.getOrDefault(emptyList())

    suspend fun setUserRole(uid: String, role: String) {
        runCatching {
            db.collection("users").document(uid).update("role", role).await()
        }
    }

    /** Admin creates / issues another user account. */
    suspend fun createUserByAdmin(email: String, password: String): Result<Unit> = runCatching {
        // Firebase Auth only lets the currently signed-in user create an
        // account, so the admin's session is briefly replaced. To keep it
        // simple and safe, this helper creates the account and then signs
        // the admin back out — the admin signs in again with their own
        // email/password. In a production app, use a Cloud Function /
        // Admin SDK for this instead.
        auth.createUserWithEmailAndPassword(email, password).await()
        val newUser = auth.currentUser
        if (newUser != null) {
            db.collection("users").document(newUser.uid)
                .set(UserProfile(newUser.uid, email, "user").toMap()).await()
        }
        auth.signOut()
    }

    suspend fun saveCustomer(customer: Customer) {
        runCatching {
            db.collection("customers").document(customer.id).set(customer.toMap()).await()
        }
    }

    suspend fun loadCustomers(): List<Customer> = runCatching {
        db.collection("customers").get().await()
            .documents.mapNotNull { it.data?.let { data -> Customer.fromMap(data) } }
    }.getOrDefault(emptyList())

    suspend fun deleteCustomer(customerId: String) {
        runCatching {
            db.collection("customers").document(customerId).delete().await()
        }
    }

    suspend fun saveStock(stock: StockSettings) {
        runCatching {
            db.collection("settings").document("stock").set(stock.toMap()).await()
        }
    }

    suspend fun loadStock(): StockSettings? = runCatching {
        val snap = db.collection("settings").document("stock").get().await()
        snap.data?.let { StockSettings.fromMap(it) }
    }.getOrNull()
}
