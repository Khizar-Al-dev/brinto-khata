package com.brinto.khata.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Order unit values for [Customer.unit] and [HistoryEvent.unit]: dozen (default), KG, or both (dozen + KG in one order). */
const val UNIT_DOZEN: String = "dozen"
const val UNIT_KG: String = "kg"
const val UNIT_BOTH: String = "both"

/**
 * One khata entry = one wholesaler customer + one order.
 *
 * Quantities are entered and shown in DOZENS (1 dozen = 12 packets).
 * [packets] still stores the packets count (dozens x 12), so old orders
 * keep working and totals stay exact.
 *
 * total    = packets * unitPrice   (unitPrice = price-per-dozen / 12, unless
 *                                   the price was overridden for this order)
 *          = dozens * price-per-dozen
 * remaining = total - paid
 *
 * KG orders ([unit] = "kg") store the quantity in [kgQuantity] and the
 * price in [pricePerKg]; total = kgQuantity * pricePerKg. They keep
 * packets = 0 and unitPrice = 0, never touch the dozen stock, and
 * earn no per-dozen profit. Combined orders ([unit] = "both") carry
 * both a dozen part (packets + unitPrice) and a KG part (kgQuantity +
 * pricePerKg); total is the sum of both, profit comes only from the
 * dozen part, and stock deducts only the dozen packets.
 */
@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val name: String = "",
    val location: String = "",
    val phone: String = "",
    /** Packets in this order (dozen part). The UI enters/shows dozens; packets = dozens x 12. Pure-KG orders store 0 here. */
    val packets: Int = 0,
    /** Price charged for ONE packet on this order (Rs). Dozen part only; 0 when no dozens given. */
    val unitPrice: Double = 0.0,
    /** Order unit: "dozen" (default), "kg", or "both". See [UNIT_DOZEN] / [UNIT_KG] / [UNIT_BOTH]. */
    val unit: String = UNIT_DOZEN,
    /** KG quantity (e.g. 2.5). 0 when no KG given. */
    val kgQuantity: Double = 0.0,
    /** Price per KG (Rs). 0 when no KG given. */
    val pricePerKg: Double = 0.0,
    val total: Double = 0.0,
    val paid: Double = 0.0,
    val remaining: Double = 0.0,
    /** Date the order was paid / the customer was saved (millis). */
    val paidDate: Long = System.currentTimeMillis(),
    /** Profit earned on this order (Rs) = dozens * profitPerDozen = (packets / 12) * profitPerDozen. */
    val orderProfit: Double = 0.0,
    val ownerUid: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any> = mapOf(
        "id" to id,
        "name" to name,
        "location" to location,
        "phone" to phone,
        "packets" to packets,
        "unitPrice" to unitPrice,
        "unit" to unit,
        "kgQuantity" to kgQuantity,
        "pricePerKg" to pricePerKg,
        "total" to total,
        "paid" to paid,
        "remaining" to remaining,
        "paidDate" to paidDate,
        "orderProfit" to orderProfit,
        "ownerUid" to ownerUid,
        "createdAt" to createdAt
    )

    companion object {
        fun fromMap(map: Map<String, Any>): Customer = Customer(
            id = map["id"] as? String ?: java.util.UUID.randomUUID().toString(),
            name = map["name"] as? String ?: "",
            location = map["location"] as? String ?: "",
            phone = map["phone"] as? String ?: "",
            packets = (map["packets"] as? Number)?.toInt() ?: 0,
            unitPrice = (map["unitPrice"] as? Number)?.toDouble() ?: 0.0,
            unit = map["unit"] as? String ?: UNIT_DOZEN,
            kgQuantity = (map["kgQuantity"] as? Number)?.toDouble() ?: 0.0,
            pricePerKg = (map["pricePerKg"] as? Number)?.toDouble() ?: 0.0,
            total = (map["total"] as? Number)?.toDouble() ?: 0.0,
            paid = (map["paid"] as? Number)?.toDouble() ?: 0.0,
            remaining = (map["remaining"] as? Number)?.toDouble() ?: 0.0,
            paidDate = (map["paidDate"] as? Number)?.toLong()
                ?: (map["createdAt"] as? Number)?.toLong() ?: 0L,
            orderProfit = (map["orderProfit"] as? Number)?.toDouble() ?: 0.0,
            ownerUid = map["ownerUid"] as? String ?: "",
            createdAt = (map["createdAt"] as? Number)?.toLong() ?: 0L
        )
    }
}

/**
 * One order in the separate Orders book (drawer "Orders").
 *
 * Orders are SEPARATE from Home customers: people added on Home are
 * never counted here, and people added here never appear on Home.
 * Each order has the same sale shape as a customer order — dozens
 * and/or KG with their own prices — but no location: Name, optional
 * Phone, Dozens, KG, Price per KG, Price per dozen.
 *
 * total    = packets * unitPrice + kgQuantity * pricePerKg
 * remaining = total - paid (paid starts 0: a new order shows as
 * Remaining in Udhaar until a payment is added in Edit)
 * Profit comes only from the dozen part, and stock deducts only
 * the dozen packets — exactly like a customer order.
 */
@Entity(tableName = "orders")
data class ShopOrder(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val name: String = "",
    val phone: String = "",
    /** Packets in this order (dozen part). The UI enters/shows dozens; packets = dozens x 12. Pure-KG orders store 0 here. */
    val packets: Int = 0,
    /** Price charged for ONE packet on this order (Rs). Dozen part only; 0 when no dozens given. */
    val unitPrice: Double = 0.0,
    /** Order unit: "dozen" (default), "kg", or "both". See [UNIT_DOZEN] / [UNIT_KG] / [UNIT_BOTH]. */
    val unit: String = UNIT_DOZEN,
    /** KG quantity (e.g. 2.5). 0 when no KG given. */
    val kgQuantity: Double = 0.0,
    /** Price per KG (Rs). 0 when no KG given. */
    val pricePerKg: Double = 0.0,
    val total: Double = 0.0,
    val paid: Double = 0.0,
    val remaining: Double = 0.0,
    /** Profit earned on this order (Rs) = dozens * profitPerDozen = (packets / 12) * profitPerDozen. */
    val orderProfit: Double = 0.0,
    val ownerUid: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any> = mapOf(
        "id" to id,
        "name" to name,
        "phone" to phone,
        "packets" to packets,
        "unitPrice" to unitPrice,
        "unit" to unit,
        "kgQuantity" to kgQuantity,
        "pricePerKg" to pricePerKg,
        "total" to total,
        "paid" to paid,
        "remaining" to remaining,
        "orderProfit" to orderProfit,
        "ownerUid" to ownerUid,
        "createdAt" to createdAt
    )

    companion object {
        fun fromMap(map: Map<String, Any>): ShopOrder = ShopOrder(
            id = map["id"] as? String ?: java.util.UUID.randomUUID().toString(),
            name = map["name"] as? String ?: "",
            phone = map["phone"] as? String ?: "",
            packets = (map["packets"] as? Number)?.toInt() ?: 0,
            unitPrice = (map["unitPrice"] as? Number)?.toDouble() ?: 0.0,
            unit = map["unit"] as? String ?: UNIT_DOZEN,
            kgQuantity = (map["kgQuantity"] as? Number)?.toDouble() ?: 0.0,
            pricePerKg = (map["pricePerKg"] as? Number)?.toDouble() ?: 0.0,
            total = (map["total"] as? Number)?.toDouble() ?: 0.0,
            paid = (map["paid"] as? Number)?.toDouble() ?: 0.0,
            remaining = (map["remaining"] as? Number)?.toDouble() ?: 0.0,
            orderProfit = (map["orderProfit"] as? Number)?.toDouble() ?: 0.0,
            ownerUid = map["ownerUid"] as? String ?: "",
            createdAt = (map["createdAt"] as? Number)?.toLong() ?: 0L
        )
    }
}

/**
 * One history entry — a SAVED or DELETED customer order.
 * Deleted customers stay visible here even after they are gone
 * from the Home list, so the old order can still be opened.
 */
@Entity(tableName = "history")
data class HistoryEvent(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val customerId: String = "",
    val customerName: String = "",
    val location: String = "",
    /** "SAVED" or "DELETED" */
    val action: String = "SAVED",
    val eventDate: Long = System.currentTimeMillis(),
    val packets: Int = 0,
    /** Order unit at the time of the event ("dozen" or "kg"). */
    val unit: String = UNIT_DOZEN,
    /** KG quantity for KG orders. 0 for dozen orders. */
    val kgQuantity: Double = 0.0,
    val total: Double = 0.0,
    val paid: Double = 0.0,
    val remaining: Double = 0.0,
    val details: String = ""
) {
    fun toMap(): Map<String, Any> = mapOf(
        "id" to id,
        "customerId" to customerId,
        "customerName" to customerName,
        "location" to location,
        "action" to action,
        "eventDate" to eventDate,
        "packets" to packets,
        "unit" to unit,
        "kgQuantity" to kgQuantity,
        "total" to total,
        "paid" to paid,
        "remaining" to remaining,
        "details" to details
    )

    companion object {
        fun fromMap(map: Map<String, Any>): HistoryEvent = HistoryEvent(
            id = map["id"] as? String ?: java.util.UUID.randomUUID().toString(),
            customerId = map["customerId"] as? String ?: "",
            customerName = map["customerName"] as? String ?: "",
            location = map["location"] as? String ?: "",
            action = map["action"] as? String ?: "SAVED",
            eventDate = (map["eventDate"] as? Number)?.toLong() ?: 0L,
            packets = (map["packets"] as? Number)?.toInt() ?: 0,
            unit = map["unit"] as? String ?: UNIT_DOZEN,
            kgQuantity = (map["kgQuantity"] as? Number)?.toDouble() ?: 0.0,
            total = (map["total"] as? Number)?.toDouble() ?: 0.0,
            paid = (map["paid"] as? Number)?.toDouble() ?: 0.0,
            remaining = (map["remaining"] as? Number)?.toDouble() ?: 0.0,
            details = map["details"] as? String ?: ""
        )
    }
}

/** Single-row stock settings. Kept in Room (id = 0) and in Firestore.
 * Stock is entered and shown in dozens; packets counts are stored (dozens x 12). */
@Entity(tableName = "stock")
data class StockSettings(
    @PrimaryKey val id: Int = 0,
    /** Packets in stock. The UI enters/shows dozens; packets = dozens x 12. */
    val packetsInStock: Int = 0,
    /** Master price for one dozen (12 packets) (Rs). Per-packet price = this / 12. */
    val pricePerDozen: Double = 0.0,
    /** Profit earned per dozen sold (Rs) — set in Stock, pencil edit. */
    val profitPerDozen: Double = 0.0,
    val totalPacketsSold: Int = 0,
    val totalSalesAmount: Double = 0.0
) {
    val pricePerPacket: Double get() = if (pricePerDozen > 0) pricePerDozen / 12.0 else 0.0

    fun toMap(): Map<String, Any> = mapOf(
        "packetsInStock" to packetsInStock,
        "pricePerDozen" to pricePerDozen,
        "profitPerDozen" to profitPerDozen,
        "totalPacketsSold" to totalPacketsSold,
        "totalSalesAmount" to totalSalesAmount
    )

    companion object {
        fun fromMap(map: Map<String, Any>): StockSettings = StockSettings(
            packetsInStock = (map["packetsInStock"] as? Number)?.toInt() ?: 0,
            pricePerDozen = (map["pricePerDozen"] as? Number)?.toDouble() ?: 0.0,
            profitPerDozen = (map["profitPerDozen"] as? Number)?.toDouble() ?: 0.0,
            totalPacketsSold = (map["totalPacketsSold"] as? Number)?.toInt() ?: 0,
            totalSalesAmount = (map["totalSalesAmount"] as? Number)?.toDouble() ?: 0.0
        )
    }
}

/**
 * The one and only admin account. Admin sirf ye email hai — baqi
 * har email user hota hai, chahe wo pehle register hua ho ya baad mein.
 */
const val ADMIN_EMAIL = "khizaralam243@gmail.com"

/** True only for the admin's email (case-insensitive, trimmed). */
fun isAdminEmail(email: String): Boolean =
    email.trim().equals(ADMIN_EMAIL, ignoreCase = true)

/** The role an email always gets: "admin" only for the admin email, "user" for everyone else. */
fun roleForEmail(email: String): String = if (isAdminEmail(email)) "admin" else "user"

/** A user account. Only the admin email is Admin; every other account is a user. */
data class UserProfile(
    val uid: String = "",
    val email: String = "",
    val role: String = "user" // "admin" or "user"
) {
    fun toMap(): Map<String, Any> = mapOf(
        "uid" to uid, "email" to email, "role" to role
    )

    companion object {
        fun fromMap(map: Map<String, Any>): UserProfile {
            val email = map["email"] as? String ?: ""
            return UserProfile(
                uid = map["uid"] as? String ?: "",
                email = email,
                // Role is fixed by email: a stored "admin" for any other
                // email is ignored, so nobody else can ever be admin.
                role = roleForEmail(email)
            )
        }
    }
}
