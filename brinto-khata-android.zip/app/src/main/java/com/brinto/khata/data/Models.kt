package com.brinto.khata.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One khata entry = one wholesaler customer + one order.
 *
 * Quantities are entered and shown in DOZENS (1 dozen = 12 packets).
 * [packets] still stores the packets count (dozens x 12), so old orders
 * keep working and totals stay exact.
 *
 * total    = packets * unitPrice   (unitPrice = price-per-dozen / 12, unless
 *                                   the price was overridden for this order)
 *          = dozens * price-per-dozen
 * remaining = total - paid
 */
@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val name: String = "",
    val location: String = "",
    val phone: String = "",
    /** Packets in this order. The UI enters/shows dozens; packets = dozens x 12. */
    val packets: Int = 0,
    /** Price charged for ONE packet on this order (Rs). */
    val unitPrice: Double = 0.0,
    val total: Double = 0.0,
    val paid: Double = 0.0,
    val remaining: Double = 0.0,
    /** Customer photo: a Cloudinary https URL once backed up, else a local file path (empty = no photo). */
    val photoPath: String = "",
    /** Extra photos (shop / location) — Cloudinary URLs or local file paths joined by "|". */
    val extraPhotoPaths: String = "",
    /** Date the order was paid / the customer was saved (millis). */
    val paidDate: Long = System.currentTimeMillis(),
    /** Profit earned on this order (Rs) = dozens * profitPerDozen = (packets / 12) * profitPerDozen. */
    val orderProfit: Double = 0.0,
    val ownerUid: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    /** Extra photo paths as a list (empty = none). */
    val extraPhotos: List<String> get() =
        extraPhotoPaths.split("|").map { it.trim() }.filter { it.isNotEmpty() }

    fun toMap(): Map<String, Any> = mapOf(
        "id" to id,
        "name" to name,
        "location" to location,
        "phone" to phone,
        "packets" to packets,
        "unitPrice" to unitPrice,
        "total" to total,
        "paid" to paid,
        "remaining" to remaining,
        "photoPath" to photoPath,
        "extraPhotoPaths" to extraPhotoPaths,
        "paidDate" to paidDate,
        "orderProfit" to orderProfit,
        "ownerUid" to ownerUid,
        "createdAt" to createdAt
    )

    companion object {
        fun fromMap(map: Map<String, Any>): Customer = Customer(
            id = map["id"] as? String ?: java.util.UUID.randomUUID().toString(),
            name = map["name"] as? String ?: "",
            location = map["location"] as? String ?: "",
            phone = map["phone"] as? String ?: "",
            packets = (map["packets"] as? Number)?.toInt() ?: 0,
            unitPrice = (map["unitPrice"] as? Number)?.toDouble() ?: 0.0,
            total = (map["total"] as? Number)?.toDouble() ?: 0.0,
            paid = (map["paid"] as? Number)?.toDouble() ?: 0.0,
            remaining = (map["remaining"] as? Number)?.toDouble() ?: 0.0,
            photoPath = map["photoPath"] as? String ?: "",
            extraPhotoPaths = map["extraPhotoPaths"] as? String ?: "",
            paidDate = (map["paidDate"] as? Number)?.toLong()
                ?: (map["createdAt"] as? Number)?.toLong() ?: 0L,
            orderProfit = (map["orderProfit"] as? Number)?.toDouble() ?: 0.0,
            ownerUid = map["ownerUid"] as? String ?: "",
            createdAt = (map["createdAt"] as? Number)?.toLong() ?: 0L
        )
    }
}

/**
 * One history entry — a SAVED or DELETED customer order.
 * Deleted customers stay visible here even after they are gone
 * from the Home list, so the old order can still be opened.
 */
@Entity(tableName = "history")
data class HistoryEvent(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val customerId: String = "",
    val customerName: String = "",
    val location: String = "",
    /** "SAVED" or "DELETED" */
    val action: String = "SAVED",
    val eventDate: Long = System.currentTimeMillis(),
    val packets: Int = 0,
    val total: Double = 0.0,
    val paid: Double = 0.0,
    val remaining: Double = 0.0,
    val details: String = ""
) {
    fun toMap(): Map<String, Any> = mapOf(
        "id" to id,
        "customerId" to customerId,
        "customerName" to customerName,
        "location" to location,
        "action" to action,
        "eventDate" to eventDate,
        "packets" to packets,
        "total" to total,
        "paid" to paid,
        "remaining" to remaining,
        "details" to details
    )

    companion object {
        fun fromMap(map: Map<String, Any>): HistoryEvent = HistoryEvent(
            id = map["id"] as? String ?: java.util.UUID.randomUUID().toString(),
            customerId = map["customerId"] as? String ?: "",
            customerName = map["customerName"] as? String ?: "",
            location = map["location"] as? String ?: "",
            action = map["action"] as? String ?: "SAVED",
            eventDate = (map["eventDate"] as? Number)?.toLong() ?: 0L,
            packets = (map["packets"] as? Number)?.toInt() ?: 0,
            total = (map["total"] as? Number)?.toDouble() ?: 0.0,
            paid = (map["paid"] as? Number)?.toDouble() ?: 0.0,
            remaining = (map["remaining"] as? Number)?.toDouble() ?: 0.0,
            details = map["details"] as? String ?: ""
        )
    }
}

/** Single-row stock settings. Kept in Room (id = 0) and in Firestore.
 * Stock is entered and shown in dozens; packets counts are stored (dozens x 12). */
@Entity(tableName = "stock")
data class StockSettings(
    @PrimaryKey val id: Int = 0,
    /** Packets in stock. The UI enters/shows dozens; packets = dozens x 12. */
    val packetsInStock: Int = 0,
    /** Master price for one dozen (12 packets) (Rs). Per-packet price = this / 12. */
    val pricePerDozen: Double = 0.0,
    /** Profit earned per dozen sold (Rs) — set in Stock, pencil edit. */
    val profitPerDozen: Double = 0.0,
    val totalPacketsSold: Int = 0,
    val totalSalesAmount: Double = 0.0
) {
    val pricePerPacket: Double get() = if (pricePerDozen > 0) pricePerDozen / 12.0 else 0.0

    fun toMap(): Map<String, Any> = mapOf(
        "packetsInStock" to packetsInStock,
        "pricePerDozen" to pricePerDozen,
        "profitPerDozen" to profitPerDozen,
        "totalPacketsSold" to totalPacketsSold,
        "totalSalesAmount" to totalSalesAmount
    )

    companion object {
        fun fromMap(map: Map<String, Any>): StockSettings = StockSettings(
            packetsInStock = (map["packetsInStock"] as? Number)?.toInt() ?: 0,
            pricePerDozen = (map["pricePerDozen"] as? Number)?.toDouble() ?: 0.0,
            profitPerDozen = (map["profitPerDozen"] as? Number)?.toDouble() ?: 0.0,
            totalPacketsSold = (map["totalPacketsSold"] as? Number)?.toInt() ?: 0,
            totalSalesAmount = (map["totalSalesAmount"] as? Number)?.toDouble() ?: 0.0
        )
    }
}

/**
 * The one and only admin account. Admin sirf ye email hai — baqi
 * har email user hota hai, chahe wo pehle register hua ho ya baad mein.
 */
const val ADMIN_EMAIL = "khizaralam243@gmail.com"

/** True only for the admin's email (case-insensitive, trimmed). */
fun isAdminEmail(email: String): Boolean =
    email.trim().equals(ADMIN_EMAIL, ignoreCase = true)

/** The role an email always gets: "admin" only for the admin email, "user" for everyone else. */
fun roleForEmail(email: String): String = if (isAdminEmail(email)) "admin" else "user"

/** A user account. Only the admin email is Admin; every other account is a user. */
data class UserProfile(
    val uid: String = "",
    val email: String = "",
    val role: String = "user" // "admin" or "user"
) {
    fun toMap(): Map<String, Any> = mapOf(
        "uid" to uid, "email" to email, "role" to role
    )

    companion object {
        fun fromMap(map: Map<String, Any>): UserProfile {
            val email = map["email"] as? String ?: ""
            return UserProfile(
                uid = map["uid"] as? String ?: "",
                email = email,
                // Role is fixed by email: a stored "admin" for any other
                // email is ignored, so nobody else can ever be admin.
                role = roleForEmail(email)
            )
        }
    }
}
