package com.brinto.khata.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.brinto.khata.data.Customer
import com.brinto.khata.data.UNIT_DOZEN
import com.brinto.khata.data.UNIT_KG
import com.brinto.khata.ui.KhataViewModel
import com.brinto.khata.util.ImageUtils
import com.brinto.khata.util.dozensToPackets
import com.brinto.khata.util.formatDozensValue
import com.brinto.khata.util.formatKgValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Add Customer (Khata entry) form.
 * Required: Name, Location, Quantity, Amount Paid.
 * Optional: Phone, Photo.
 * Quantity is Dozen or KG (toggle above the quantity field). Dozen:
 * entered in DOZENS (1 dozen = 12 packets) and stored as packets
 * (dozens x 12); total = dozens * price-per-dozen. KG: entered in KG
 * with its own price per KG below it; total = KG * price-per-KG.
 * KG orders never touch the dozen stock and earn no profit.
 * Remaining = total - paid (auto).
 * Price per dozen defaults to the stock price, but can be overridden
 * for this order (discount / lower price) — the order keeps its own price.
 * Photo: camera icon = take photo, + icon = gallery, images only.
 * Save runs only once: the button is disabled while saving, and on
 * success the screen closes automatically (no duplicate saves).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddCustomerScreen(viewModel: KhataViewModel, onBack: () -> Unit, onSaved: () -> Unit) {
    val context = LocalContext.current
    val stock by viewModel.stock.collectAsState()

    var name by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var dozensText by remember { mutableStateOf("") }
    var kgText by remember { mutableStateOf("") }
    var kgPriceText by remember { mutableStateOf("") }
    var isKg by remember { mutableStateOf(false) }
    var paidText by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("") }
    var priceEdited by remember { mutableStateOf(false) }
    var photoPath by remember { mutableStateOf("") }
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    var error by remember { mutableStateOf("") }
    var permissionNote by remember { mutableStateOf("") }
    // True from the first Save tap until the save finishes. Blocks
    // repeated taps from creating duplicate orders.
    var isSaving by remember { mutableStateOf(false) }

    val defaultPricePerDozen = stock?.pricePerDozen ?: 0.0
    val dozens = dozensText.toDoubleOrNull() ?: 0.0
    val kg = kgText.toDoubleOrNull() ?: 0.0
    // Stored quantity: dozen orders store dozens x 12 packets; KG orders store 0 packets.
    val packets = if (isKg) 0 else dozensToPackets(dozens)
    val paid = paidText.toDoubleOrNull() ?: 0.0
    // If the user has not typed a price, use the stock price; otherwise use theirs.
    val pricePerDozen = if (priceEdited) (priceText.toDoubleOrNull() ?: defaultPricePerDozen) else defaultPricePerDozen
    // KG orders have their own price per KG (no stock default).
    val pricePerKg = kgPriceText.toDoubleOrNull() ?: 0.0
    // Per-packet price is kept for storage; totals match the repository (packets x unitPrice).
    // KG orders keep unitPrice 0 — the repository totals them as KG x price-per-KG.
    val unitPrice = if (isKg) 0.0 else pricePerDozen / 12.0
    val total = if (isKg) kg * pricePerKg else packets * unitPrice
    val remaining = total - paid
    // Profit in this order, matching the repository: (packets / 12) * profit per dozen.
    // KG orders earn no profit (no profit-per-KG setting exists).
    val orderProfit = if (isKg) 0.0 else (packets / 12.0) * (stock?.profitPerDozen ?: 0.0)

    var cameraFile by remember { mutableStateOf<File?>(null) }
    // Photo copy / square-crop runs in the background (a big gallery
    // photo copied on the main thread froze the screen). While it
    // runs, a small note is shown under the photo buttons.
    val photoScope = rememberCoroutineScope()
    var isCopyingPhoto by remember { mutableStateOf(false) }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            // "image/*" only — see the launcher call below.
            // Profile photo: square-cropped so it fills the round circle.
            isCopyingPhoto = true
            photoScope.launch {
                val path = withContext(Dispatchers.IO) {
                    ImageUtils.copyProfilePhotoFromGallery(context, uri)
                }
                isCopyingPhoto = false
                if (path != null) photoPath = path
            }
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success: Boolean ->
        if (success) {
            cameraFile?.let { file ->
                isCopyingPhoto = true
                photoScope.launch {
                    photoPath = withContext(Dispatchers.IO) {
                        ImageUtils.squareCropCameraPhoto(context, file)
                    }
                    isCopyingPhoto = false
                }
            }
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted: Boolean ->
        if (granted) {
            val file = ImageUtils.createCameraImageFile(context)
            cameraFile = file
            val uri = FileProvider.getUriForFile(
                context, "com.brinto.khata.fileprovider", file
            )
            photoUri = uri
            cameraLauncher.launch(uri)
        } else {
            permissionNote = "Camera permission ke baghair photo nahi le sakte. Settings se Camera allow karein."
        }
    }

    val galleryPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted: Boolean ->
        if (granted) {
            galleryLauncher.launch("image/*")
        } else {
            // Android 13+ (API 33+) does not need READ_MEDIA_IMAGES for the
            // system photo picker, but on older phones this permission is needed.
            galleryLauncher.launch("image/*")
        }
    }

    fun requestCamera() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            val file = ImageUtils.createCameraImageFile(context)
            cameraFile = file
            val uri = FileProvider.getUriForFile(
                context, "com.brinto.khata.fileprovider", file
            )
            photoUri = uri
            cameraLauncher.launch(uri)
        } else {
            permissionNote = "Camera se photo lene ke liye Camera permission chahiye."
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    fun requestGallery() {
        val permission = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (ContextCompat.checkSelfPermission(context, permission) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            galleryLauncher.launch("image/*")
        } else {
            permissionNote = "Gallery se photo chunne ke liye gallery / photos permission chahiye. Sirf images allowed hain."
            galleryPermissionLauncher.launch(permission)
        }
    }

    if (permissionNote.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { permissionNote = "" },
            title = { Text("Permission") },
            text = { Text(permissionNote) },
            confirmButton = {
                TextButton(onClick = { permissionNote = "" }) { Text("OK") }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Add Customer") },
                navigationIcon = {
                    IconButton(onClick = onBack, enabled = !isSaving) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("Name *") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = location, onValueChange = { location = it },
                label = { Text("Location *") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = phone, onValueChange = { phone = it },
                label = { Text("Phone (optional)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text("Quantity kis hisaab se deni hai?", style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { isKg = false },
                    modifier = Modifier.weight(1f),
                    enabled = !isSaving
                ) { Text(if (isKg) "Dozen" else "Dozen ✓") }
                OutlinedButton(
                    onClick = { isKg = true },
                    modifier = Modifier.weight(1f),
                    enabled = !isSaving
                ) { Text(if (isKg) "KG ✓" else "KG") }
            }
            if (isKg) {
                OutlinedTextField(
                    value = kgText, onValueChange = { kgText = it },
                    label = { Text("KG purchased *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (kg > 0) {
                    Text(
                        "${formatKgValue(kg)} KG.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                OutlinedTextField(
                    value = kgPriceText, onValueChange = { kgPriceText = it },
                    label = { Text("Price per KG (Rs) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "KG ki price yahan likhein — ye stock price se nahi aati, har KG order ki apni price hoti hai.",
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                OutlinedTextField(
                    value = dozensText, onValueChange = { dozensText = it },
                    label = { Text("Dozens purchased *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (dozens > 0) {
                    Text(
                        "${formatDozensValue(dozens)} dozen = $packets packets (1 dozen = 12 packets).",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                OutlinedTextField(
                    value = if (priceEdited) priceText else if (defaultPricePerDozen > 0) defaultPricePerDozen.toString() else "",
                    onValueChange = { priceText = it; priceEdited = true },
                    label = { Text("Price per dozen (Rs) — stock se auto, yahan change kar sakte hain") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "Stock price: Rs ${stock?.pricePerDozen?.toInt() ?: 0} per dozen " +
                        "(Rs ${String.format("%.2f", stock?.pricePerPacket ?: 0.0)} per packet). " +
                        "Upar wali price change kar dein to is order par wahi price lagegi.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            OutlinedTextField(
                value = paidText, onValueChange = { paidText = it },
                label = { Text("Amount Paid (Rs) *") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Photo: right after the information fields — camera icon + gallery (+) icon, images only.
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (photoPath.isNotBlank()) {
                    AsyncImage(
                        model = ImageUtils.photoModel(photoPath),
                        contentDescription = "Customer photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(72.dp).clip(CircleShape)
                    )
                }
                Spacer(Modifier.size(12.dp))
                OutlinedButton(onClick = { requestCamera() }) {
                    Icon(Icons.Default.CameraAlt, contentDescription = "Camera")
                    Text(" Camera")
                }
                Spacer(Modifier.size(8.dp))
                OutlinedButton(onClick = { requestGallery() }) {
                    Icon(Icons.Default.Add, contentDescription = "Gallery")
                    Text(" + Gallery")
                }
            }
            Text(
                "Photo optional hai — location / dukaan yaad rakhne ke liye. Sirf images allowed hain.",
                style = MaterialTheme.typography.bodySmall
            )
            if (isCopyingPhoto) {
                Text(
                    "Photo tayyar ho rahi hai...",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            // Live totals — shown AFTER the photo options, auto calculated as the user types.
            Text("Total Bill: Rs ${String.format("%.2f", total)}", style = MaterialTheme.typography.titleMedium)
            Text("Remaining: Rs ${String.format("%.2f", remaining)}", style = MaterialTheme.typography.titleMedium)
            if (isKg) {
                Text(
                    "KG wali sale ka profit nahi gina jata aur stock se kuch deduct nahi hota.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            } else {
                Text(
                    "Profit in this order: Rs ${String.format("%.2f", orderProfit)}",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (error.isNotEmpty()) {
                Text(error, color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(4.dp))
            Button(
                onClick = {
                    if (isSaving) return@Button
                    if (name.isBlank() || location.isBlank()) {
                        error = "Name aur Location zaroori hain."
                        return@Button
                    }
                    if (isKg && (kg <= 0 || pricePerKg <= 0)) {
                        error = "KG aur Price per KG (0 se zyada) zaroori hain."
                        return@Button
                    }
                    if (!isKg && dozens <= 0) {
                        error = "Name, Location aur Dozens (0 se zyada) zaroori hain."
                        return@Button
                    }
                    isSaving = true
                    error = ""
                    val ownerUid = viewModel.profile.value?.uid ?: ""
                    viewModel.addCustomer(
                        Customer(
                            name = name.trim(),
                            location = location.trim(),
                            phone = phone.trim(),
                            packets = packets,
                            unitPrice = unitPrice,
                            unit = if (isKg) UNIT_KG else UNIT_DOZEN,
                            kgQuantity = if (isKg) kg else 0.0,
                            pricePerKg = if (isKg) pricePerKg else 0.0,
                            total = total,
                            paid = paid,
                            remaining = remaining,
                            photoPath = photoPath,
                            paidDate = System.currentTimeMillis(),
                            orderProfit = orderProfit,
                            ownerUid = ownerUid
                        ),
                        onDone = { onSaved() },
                        onError = {
                            isSaving = false
                            error = "Save nahi ho saka. Dobara try karein."
                        }
                    )
                },
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (isSaving) "Saving..." else "Save")
            }
            Text(
                if (isKg) "Save karte hi KG wali sale ka total sale amount mein add ho jayega — stock se kuch deduct nahi hoga. Save ke baad screen khud band ho jayegi."
                else "Save karte hi stock se ${formatDozensValue(dozens)} dozen ($packets packets) deduct ho jayenge aur sale total mein add ho jayega. Save ke baad screen khud band ho jayegi.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
