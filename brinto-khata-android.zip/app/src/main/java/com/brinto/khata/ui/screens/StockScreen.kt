package com.brinto.khata.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.brinto.khata.ui.KhataViewModel
import com.brinto.khata.util.dozensToPackets
import com.brinto.khata.util.formatDozens
import com.brinto.khata.util.formatDozensValue

/**
 * Stock screen (hamburger menu > Stock).
 * - Dozens in stock (editable number, 1 dozen = 12 packets)
 * - Price per dozen (12 packets) (editable via the pencil / edit icon)
 * - Profit per dozen (editable via the pencil / edit icon)
 * - Current stock, dozens sold and total sale amount are shown.
 * When an order is added, stock deducts automatically — see
 * KhataRepository.addCustomer().
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StockScreen(viewModel: KhataViewModel, onBack: () -> Unit) {
    val stock by viewModel.stock.collectAsState()
    var editing by remember { mutableStateOf(false) }
    var dozensText by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("") }
    var profitText by remember { mutableStateOf("") }
    val editingDozens = dozensText.toDoubleOrNull() ?: 0.0
    val editingPackets = dozensToPackets(editingDozens)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Stock") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        if (!editing) {
                            dozensText = formatDozens(stock?.packetsInStock ?: 0)
                            priceText = (stock?.pricePerDozen ?: 0.0).toString()
                            profitText = (stock?.profitPerDozen ?: 0.0).toString()
                        }
                        editing = !editing
                    }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit stock — pencil icon")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Dozens in Stock: ${formatDozens(stock?.packetsInStock ?: 0)} (${stock?.packetsInStock ?: 0} packets)", style = MaterialTheme.typography.titleLarge)
                    Text("Price per dozen (12 packets): Rs ${stock?.pricePerDozen?.toInt() ?: 0}", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Price per packet: Rs ${String.format("%.2f", stock?.pricePerPacket ?: 0.0)}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        "Profit per dozen: Rs ${stock?.profitPerDozen?.toInt() ?: 0}",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("Dozens sold: ${formatDozens(stock?.totalPacketsSold ?: 0)} (${stock?.totalPacketsSold ?: 0} packets)", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "Total sale amount: Rs ${String.format("%.2f", stock?.totalSalesAmount ?: 0.0)}",
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }

            if (editing) {
                Text("Edit Stock — pencil icon se khula hai. Teeno values change kar sakte hain. Dozens likhein, packets khud hisaab ho jayenge (1 dozen = 12 packets).", style = MaterialTheme.typography.bodyMedium)
                OutlinedTextField(
                    value = dozensText, onValueChange = { dozensText = it },
                    label = { Text("Dozens in Stock") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (editingDozens > 0) {
                    Text(
                        "${formatDozensValue(editingDozens)} dozen = $editingPackets packets save honge.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                OutlinedTextField(
                    value = priceText, onValueChange = { priceText = it },
                    label = { Text("Price per dozen (12 packets) (Rs)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = profitText, onValueChange = { profitText = it },
                    label = { Text("Profit per dozen (Rs)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val dozens = dozensText.toDoubleOrNull()
                            val packets = if (dozens != null) dozensToPackets(dozens) else (stock?.packetsInStock ?: 0)
                            val price = priceText.toDoubleOrNull() ?: (stock?.pricePerDozen ?: 0.0)
                            val profit = profitText.toDoubleOrNull() ?: (stock?.profitPerDozen ?: 0.0)
                            viewModel.saveStock(packets, price, profit)
                            editing = false
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Save Stock") }
                }
            } else {
                Text(
                    "Stock change karne ke liye upar pencil (edit) icon par tap karein.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Jab bhi kisi customer ka order add hoga, stock se dozens (x 12 packets) khud deduct ho jayenge aur sale total mein add ho jayega.",
                style = MaterialTheme.typography.bodySmall
            )
            // Keep the layout stable when not editing.
            Row(verticalAlignment = Alignment.CenterVertically) { }
        }
    }
}
