package com.brinto.khata.data

import com.brinto.khata.util.formatDozens
import kotlinx.coroutines.flow.Flow

/**
 * Single place the UI talks to for data.
 *
 * Rule: Room is the source of truth on the phone (works offline).
 * Firestore is the cloud copy: every save also goes to Firestore
 * (customers, history and stock), and [refreshFromCloud] runs a
 * two-way sync after login, on app start, and from the Cloud Sync
 * menu — so data survives app deletion: sign in again with the
 * same Gmail and the khata comes back.
 *
 * Photos are NOT backed up: photoPath points at files in the app's
 * private storage, which Android deletes with the app. Names,
 * orders, amounts, stock and history come back; photos do not.
 */
class KhataRepository(
    private val db: AppDatabase,
    private val cloud: FirestoreRepository
) {
    val customers: Flow<List<Customer>> = db.customerDao().getAll()
    val udhaar: Flow<List<Customer>> = db.customerDao().getUdhaar()
    val stock: Flow<StockSettings?> = db.stockDao().getStock()
    val history: Flow<List<HistoryEvent>> = db.historyDao().getAll()

    /**
     * Two-way cloud sync.
     *
     * PUSH first, then PULL: everything saved on this phone —
     * including saves made while offline — is uploaded before the
     * cloud copy is merged down, so a sync can never erase phone
     * data. On a conflict the phone's copy wins. On a fresh
     * install the phone is empty, so the pull restores the whole
     * khata from the cloud.
     *
     * Failures are returned (never swallowed): the caller shows
     * "sync failed — check internet" instead of an empty list
     * that looks like lost data.
     */
    suspend fun refreshFromCloud(): Result<SyncResult> = runCatching {
        // PUSH: upload the phone's copy first.
        val localCustomers = db.customerDao().getAllOnce()
        for (customer in localCustomers) cloud.saveCustomer(customer)
        val localHistory = db.historyDao().getAllOnce()
        for (event in localHistory) cloud.saveHistoryEvent(event)
        db.stockDao().getStockOnce()?.let { cloud.saveStock(it) }

        // PULL: merge the cloud copy down into Room.
        val cloudCustomers = cloud.loadCustomers()
        var restoredCustomers = 0
        if (cloudCustomers.isNotEmpty()) {
            db.customerDao().insertAll(cloudCustomers)
            restoredCustomers = cloudCustomers.size
        }
        val cloudHistory = cloud.loadHistory()
        var restoredHistory = 0
        if (cloudHistory.isNotEmpty()) {
            db.historyDao().insertAll(cloudHistory)
            restoredHistory = cloudHistory.size
        }
        val cloudStock = cloud.loadStock()
        val stockRestored = cloudStock != null
        if (cloudStock != null) db.stockDao().save(cloudStock)

        SyncResult(
            customersRestored = restoredCustomers,
            historyRestored = restoredHistory,
            stockRestored = stockRestored,
            customersBackedUp = localCustomers.size
        )
    }

    suspend fun getStockOnce(): StockSettings =
        db.stockDao().getStockOnce() ?: StockSettings()

    suspend fun saveStock(stock: StockSettings) {
        db.stockDao().save(stock)
        cloud.saveStock(stock)
    }

    suspend fun getCustomerById(id: String): Customer? =
        db.customerDao().getById(id)

    /** Change a customer's profile photo (pencil on the detail screen). */
    suspend fun updateCustomerPhoto(customerId: String, photoPath: String): Result<Unit> =
        runCatching {
            val current = db.customerDao().getById(customerId) ?: return@runCatching
            val updated = current.copy(photoPath = photoPath)
            db.customerDao().update(updated)
            cloud.saveCustomer(updated)
        }

    /** Add one more photo (shop / location) to a customer. */
    suspend fun addExtraPhoto(customerId: String, photoPath: String): Result<Unit> =
        runCatching {
            val current = db.customerDao().getById(customerId) ?: return@runCatching
            val paths = current.extraPhotos.toMutableList().apply { add(photoPath) }
            val updated = current.copy(extraPhotoPaths = paths.joinToString("|"))
            db.customerDao().update(updated)
            cloud.saveCustomer(updated)
        }

    private fun orderDetails(customer: Customer): String =
        "Order: ${formatDozens(customer.packets)} dozen (${customer.packets} packets), " +
            "Total Rs ${customer.total.toInt()}, " +
            "Paid Rs ${customer.paid.toInt()}, " +
            "Remaining Rs ${customer.remaining.toInt()}"

    private suspend fun logHistory(customer: Customer, action: String) {
        val event = HistoryEvent(
            customerId = customer.id,
            customerName = customer.name,
            location = customer.location,
            action = action,
            eventDate = System.currentTimeMillis(),
            packets = customer.packets,
            total = customer.total,
            paid = customer.paid,
            remaining = customer.remaining,
            details = orderDetails(customer)
        )
        db.historyDao().insert(event)
        cloud.saveHistoryEvent(event)
    }

    /**
     * Add a customer order (quantity entered in dozens, stored as packets):
     *  - total = packets * unitPrice = dozens * price-per-dozen, remaining = total - paid
     *  - profit = dozens * profitPerDozen = (packets / 12) * profitPerDozen
     *  - stock packets are deducted automatically (dozens x 12)
     *  - sale totals are updated (packets sold + sale amount)
     *  - a SAVED event is written to History
     */
    suspend fun addCustomer(customer: Customer): Result<Unit> = runCatching {
        val stock = getStockOnce()
        val total = customer.packets * customer.unitPrice
        val profit = (customer.packets / 12.0) * stock.profitPerDozen
        val now = System.currentTimeMillis()
        val finalCustomer = customer.copy(
            total = total,
            remaining = total - customer.paid,
            orderProfit = profit,
            paidDate = if (customer.paidDate == 0L) now else customer.paidDate,
            createdAt = if (customer.createdAt == 0L) now else customer.createdAt
        )
        db.customerDao().insert(finalCustomer)
        cloud.saveCustomer(finalCustomer)
        logHistory(finalCustomer, "SAVED")

        val newStock = stock.copy(
            packetsInStock = (stock.packetsInStock - customer.packets).coerceAtLeast(0),
            totalPacketsSold = stock.totalPacketsSold + customer.packets,
            totalSalesAmount = stock.totalSalesAmount + total
        )
        db.stockDao().save(newStock)
        cloud.saveStock(newStock)
    }

    /** Delete a customer (long-press on their card, then confirm). */
    suspend fun deleteCustomer(customer: Customer): Result<Unit> = runCatching {
        // Log the DELETED event FIRST, so the old order stays in History
        // even after the customer row is gone from Home.
        logHistory(customer, "DELETED")
        db.customerDao().deleteById(customer.id)
        cloud.deleteCustomer(customer.id)
    }

    /**
     * Update an existing customer order (Edit order from the detail
     * screen's three-dots menu, or from the Home long-press menu):
     *  - total / remaining / orderProfit are recomputed from the edited
     *    dozens (stored as packets), unit price and paid amount
     *  - stock is adjusted for the DIFFERENCE only: packets in stock,
     *    packets sold and sale total move by (new - old)
     *  - paidDate is set to now only when the paid amount changed,
     *    otherwise the old paid date is kept; createdAt never changes
     *  - an UPDATED event is written to History
     */
    suspend fun updateCustomer(edited: Customer): Result<Unit> = runCatching {
        val old = db.customerDao().getById(edited.id) ?: return@runCatching
        val stock = getStockOnce()
        val total = edited.packets * edited.unitPrice
        val profit = (edited.packets / 12.0) * stock.profitPerDozen
        val now = System.currentTimeMillis()
        val finalCustomer = edited.copy(
            total = total,
            remaining = total - edited.paid,
            orderProfit = profit,
            paidDate = if (edited.paid != old.paid) now else old.paidDate,
            createdAt = old.createdAt
        )
        db.customerDao().update(finalCustomer)
        cloud.saveCustomer(finalCustomer)
        logHistory(finalCustomer, "UPDATED")

        val newStock = stock.copy(
            packetsInStock = (stock.packetsInStock + (old.packets - edited.packets)).coerceAtLeast(0),
            totalPacketsSold = (stock.totalPacketsSold + (edited.packets - old.packets)).coerceAtLeast(0),
            totalSalesAmount = (stock.totalSalesAmount + (total - old.total)).coerceAtLeast(0.0)
        )
        db.stockDao().save(newStock)
        cloud.saveStock(newStock)
    }
}

/** Result of a cloud sync: what was pulled down and pushed up. */
data class SyncResult(
    val customersRestored: Int = 0,
    val historyRestored: Int = 0,
    val stockRestored: Boolean = false,
    val customersBackedUp: Int = 0
)
