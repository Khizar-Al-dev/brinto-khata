package com.brinto.khata.data

import com.brinto.khata.util.quantityLine
import kotlinx.coroutines.flow.Flow

/**
 * Single place the UI talks to for data.
 *
 * Rule: Room is the source of truth on the phone (works offline).
 * Firestore is the cloud copy: every save also goes to Firestore
 * (customers, history and stock), and [refreshFromCloud] runs a
 * two-way sync after login, on app start, and automatically the
 * moment internet returns — so data survives app deletion: sign
 * in again with the same Gmail and the khata comes back.
 *
 */
class KhataRepository(
    private val db: AppDatabase,
    private val cloud: FirestoreRepository
) {
    val customers: Flow<List<Customer>> = db.customerDao().getAll()
    val udhaar: Flow<List<Customer>> = db.customerDao().getUdhaar()
    val stock: Flow<StockSettings?> = db.stockDao().getStock()
    val history: Flow<List<HistoryEvent>> = db.historyDao().getAll()
    /** Separate Orders book (drawer "Orders") — never mixed with Home customers. */
    val orders: Flow<List<ShopOrder>> = db.shopOrderDao().getAll()

    /**
     * Two-way sync between this phone's Room database and the
     * signed-in Gmail's own Firestore space (users/{uid}/...).
     *
     * Order matters, and every step before the local replace must
     * succeed, so a failed sync never wipes local data:
     *  1. STRICT PUSH: this phone's copy is uploaded into this
     *     Gmail's cloud space — including saves made while
     *     offline. Only this Gmail's rows (ownerUid matches,
     *     or unclaimed legacy rows) go up, so another Gmail's
     *     rows never leak across accounts.
     *  2. LEGACY MIGRATION (once per Gmail): this Gmail's own
     *     data written by older builds to the global
     *     collections is copied into this Gmail's space, so old
     *     data is not left behind. Another Gmail's docs are
     *     never claimed, so sharing the APK cannot leak data
     *     between accounts.
     *  3. PULL: this Gmail's cloud copy is read.
     *  4. REPLACE: local Room data is replaced with the cloud
     *     copy, so a previous Gmail's rows never stay on the
     *     phone after a new login. On a fresh install the phone
     *     is empty, so the pull restores the whole khata.
     *
     * Failures are returned (never swallowed): the caller shows
     * "sync failed — check internet" instead of an empty list
     * that looks like lost data.
     */
    suspend fun refreshFromCloud(): Result<SyncResult> = runCatching {
        // Local-only variant: no cloud, Room is everything.
        if (!cloud.cloudAvailable) return@runCatching SyncResult()
        val uid = cloud.currentUid ?: throw IllegalStateException("Not signed in")

        // 1. STRICT PUSH: a failure aborts before local data is touched.
        val localCustomers = db.customerDao().getAllOnce()
        var backedUp = 0
        for (customer in localCustomers) {
            if (customer.ownerUid.isNotEmpty() && customer.ownerUid != uid) continue
            val owned = if (customer.ownerUid.isEmpty()) {
                val claimed = customer.copy(ownerUid = uid)
                db.customerDao().update(claimed)
                claimed
            } else customer
            cloud.saveCustomerStrict(owned)
            backedUp++
        }
        val localHistory = db.historyDao().getAllOnce()
        for (event in localHistory) cloud.saveHistoryEventStrict(event)
        // Orders push: same owner rule as customers — only this Gmail's
        // rows (or unclaimed legacy rows) go up.
        val localOrders = db.shopOrderDao().getAllOnce()
        var ordersBackedUp = 0
        for (order in localOrders) {
            if (order.ownerUid.isNotEmpty() && order.ownerUid != uid) continue
            val owned = if (order.ownerUid.isEmpty()) {
                val claimed = order.copy(ownerUid = uid)
                db.shopOrderDao().update(claimed)
                claimed
            } else order
            cloud.saveOrderStrict(owned)
            ordersBackedUp++
        }
        db.stockDao().getStockOnce()?.let { cloud.saveStockStrict(it) }

        // 2. LEGACY MIGRATION (once per Gmail). Only this Gmail's own
        // old data is copied: docs stamped with another Gmail's UID
        // are never claimed, so sharing the APK with a friend can
        // never leak the old cloud copy into their account.
        // Unstamped ("") docs are claimed only when no other Gmail's
        // docs are present. History and stock migrate only when this
        // Gmail owned at least one legacy customer.
        if (!cloud.isLegacyMigrated()) {
            val legacyCustomers = cloud.loadLegacyCustomers()
            val othersExist = legacyCustomers.any { it.ownerUid.isNotEmpty() && it.ownerUid != uid }
            val owned = legacyCustomers.filter {
                it.ownerUid == uid || (it.ownerUid.isEmpty() && !othersExist)
            }
            for (customer in owned) {
                cloud.saveCustomerStrict(customer.copy(ownerUid = uid))
            }
            if (owned.isNotEmpty()) {
                for (event in cloud.loadLegacyHistory()) {
                    cloud.saveHistoryEventStrict(event)
                }
                cloud.loadLegacyStock()?.let { cloud.saveStockStrict(it) }
            }
            cloud.markLegacyMigrated()
        }

        // 3. PULL: a failure aborts before local data is touched.
        val cloudCustomers = cloud.loadCustomers()
        val cloudHistory = cloud.loadHistory()
        val cloudOrders = cloud.loadOrders()
        val cloudStock = cloud.loadStock()

        // 4. REPLACE local data with this Gmail's cloud copy.
        db.customerDao().deleteAll()
        db.historyDao().deleteAll()
        db.shopOrderDao().deleteAll()
        db.stockDao().clear()
        var restoredCustomers = 0
        if (cloudCustomers.isNotEmpty()) {
            db.customerDao().insertAll(cloudCustomers)
            restoredCustomers = cloudCustomers.size
        }
        var restoredHistory = 0
        if (cloudHistory.isNotEmpty()) {
            db.historyDao().insertAll(cloudHistory)
            restoredHistory = cloudHistory.size
        }
        var restoredOrders = 0
        if (cloudOrders.isNotEmpty()) {
            db.shopOrderDao().insertAll(cloudOrders)
            restoredOrders = cloudOrders.size
        }
        val stockRestored = cloudStock != null
        if (cloudStock != null) db.stockDao().save(cloudStock)

        SyncResult(
            customersRestored = restoredCustomers,
            historyRestored = restoredHistory,
            ordersRestored = restoredOrders,
            stockRestored = stockRestored,
            customersBackedUp = backedUp,
            ordersBackedUp = ordersBackedUp
        )
    }

    suspend fun getStockOnce(): StockSettings =
        db.stockDao().getStockOnce() ?: StockSettings()

    suspend fun saveStock(stock: StockSettings) {
        db.stockDao().save(stock)
        cloud.saveStock(stock)
    }

    suspend fun getCustomerById(id: String): Customer? =
        db.customerDao().getById(id)

    private fun orderDetails(customer: Customer): String =
        "Order: " + quantityLine(customer.unit, customer.packets, customer.kgQuantity) + ", " +
            "Total Rs ${customer.total.toInt()}, " +
            "Paid Rs ${customer.paid.toInt()}, " +
            "Remaining Rs ${customer.remaining.toInt()}"

    private suspend fun logHistory(customer: Customer, action: String) {
        val event = HistoryEvent(
            customerId = customer.id,
            customerName = customer.name,
            location = customer.location,
            action = action,
            eventDate = System.currentTimeMillis(),
            packets = customer.packets,
            unit = customer.unit,
            kgQuantity = customer.kgQuantity,
            total = customer.total,
            paid = customer.paid,
            remaining = customer.remaining,
            details = orderDetails(customer)
        )
        db.historyDao().insert(event)
        cloud.saveHistoryEvent(event)
    }

    /**
     * Add a customer order:
     *  - total = packets * unitPrice + kgQuantity * pricePerKg: the dozen
     *    part (dozens x price-per-dozen) plus the KG part (KG x price-per-KG).
     *    One order can carry both at once (unit "both").
     *  - profit comes only from the dozen part:
     *    profit = dozens * profitPerDozen = (packets / 12) * profitPerDozen
     *  - stock: only the dozen packets are deducted (dozens x 12); the KG
     *    part never touches the dozen stock (no packets deducted/sold)
     *  - sale amount is updated for every order (totalSalesAmount += total)
     *  - a SAVED event is written to History
     */
    suspend fun addCustomer(customer: Customer): Result<Unit> = runCatching {
        val stock = getStockOnce()
        val total = customer.packets * customer.unitPrice +
            customer.kgQuantity * customer.pricePerKg
        val profit = (customer.packets / 12.0) * stock.profitPerDozen
        val now = System.currentTimeMillis()
        val finalCustomer = customer.copy(
            total = total,
            remaining = total - customer.paid,
            orderProfit = profit,
            paidDate = if (customer.paidDate == 0L) now else customer.paidDate,
            createdAt = if (customer.createdAt == 0L) now else customer.createdAt,
            // Owner defaults to the signed-in Gmail (AddCustomerScreen
            // already sets it; this covers any other call path).
            ownerUid = customer.ownerUid.ifEmpty { cloud.currentUid ?: "" }
        )
        db.customerDao().insert(finalCustomer)
        cloud.saveCustomer(finalCustomer)
        logHistory(finalCustomer, "SAVED")

        // Only the dozen packets leave the stock (KG-only orders keep
        // packets = 0, so nothing is deducted for their KG part).
        val newStock = stock.copy(
            packetsInStock = (stock.packetsInStock - customer.packets).coerceAtLeast(0),
            totalPacketsSold = stock.totalPacketsSold + customer.packets,
            totalSalesAmount = stock.totalSalesAmount + total
        )
        db.stockDao().save(newStock)
        cloud.saveStock(newStock)
    }

    /** Delete a customer (long-press on their card, then confirm). */
    suspend fun deleteCustomer(customer: Customer): Result<Unit> = runCatching {
        // Log the DELETED event FIRST, so the old order stays in History
        // even after the customer row is gone from Home.
        logHistory(customer, "DELETED")
        db.customerDao().deleteById(customer.id)
        cloud.deleteCustomer(customer.id)
    }

    /**
     * Update an existing customer order (Edit order from the detail
     * screen's three-dots menu, or from the Home long-press menu):
     *  - total / remaining / orderProfit are recomputed from the edited
     *    quantity: dozens (stored as packets) + unit price, plus KG
     *    quantity + price per KG when given. Profit comes only from
     *    the dozen part; the KG part never touches the dozen stock.
     *  - stock is adjusted for the DIFFERENCE only: packets in stock,
     *    packets sold and sale total move by (new - old). KG orders store
     *    packets = 0, so switching dozen <-> KG moves the packets back
     *    into / out of stock automatically.
     *  - paidDate is set to now only when the paid amount changed,
     *    otherwise the old paid date is kept; createdAt never changes
     *  - an UPDATED event is written to History
     */
    suspend fun updateCustomer(edited: Customer): Result<Unit> = runCatching {
        val old = db.customerDao().getById(edited.id) ?: return@runCatching
        val stock = getStockOnce()
        val total = edited.packets * edited.unitPrice +
            edited.kgQuantity * edited.pricePerKg
        val profit = (edited.packets / 12.0) * stock.profitPerDozen
        val now = System.currentTimeMillis()
        val finalCustomer = edited.copy(
            total = total,
            remaining = total - edited.paid,
            orderProfit = profit,
            paidDate = if (edited.paid != old.paid) now else old.paidDate,
            createdAt = old.createdAt,
            ownerUid = edited.ownerUid.ifEmpty { cloud.currentUid ?: "" }
        )
        db.customerDao().update(finalCustomer)
        cloud.saveCustomer(finalCustomer)
        logHistory(finalCustomer, "UPDATED")

        val newStock = stock.copy(
            packetsInStock = (stock.packetsInStock + (old.packets - edited.packets)).coerceAtLeast(0),
            totalPacketsSold = (stock.totalPacketsSold + (edited.packets - old.packets)).coerceAtLeast(0),
            totalSalesAmount = (stock.totalSalesAmount + (total - old.total)).coerceAtLeast(0.0)
        )
        db.stockDao().save(newStock)
        cloud.saveStock(newStock)
    }

    // ---- Separate Orders book (drawer "Orders") ----
    // Same sale rules as a customer order, but stored in its own
    // table (orders) and its own cloud collection (users/{uid}/orders):
    // Home customers are never counted here, and orders never appear
    // on Home. Only the dozen packets leave the stock; the KG part
    // never touches it and earns no profit.

    suspend fun getOrderById(id: String): ShopOrder? =
        db.shopOrderDao().getById(id)

    private fun orderDetails(order: ShopOrder): String =
        "Order: " + quantityLine(order.unit, order.packets, order.kgQuantity) + ", " +
            "Total Rs ${order.total.toInt()}, " +
            "Paid Rs ${order.paid.toInt()}, " +
            "Remaining Rs ${order.remaining.toInt()}"

    private suspend fun logOrderHistory(order: ShopOrder, action: String) {
        val event = HistoryEvent(
            customerId = order.id,
            customerName = order.name,
            location = "",
            action = action,
            eventDate = System.currentTimeMillis(),
            packets = order.packets,
            unit = order.unit,
            kgQuantity = order.kgQuantity,
            total = order.total,
            paid = order.paid,
            remaining = order.remaining,
            details = orderDetails(order)
        )
        db.historyDao().insert(event)
        cloud.saveHistoryEvent(event)
    }

    /**
     * Add an order to the separate Orders book:
     *  - total = packets * unitPrice + kgQuantity * pricePerKg
     *  - profit comes only from the dozen part
     *  - stock: only the dozen packets are deducted; KG never touches it
     *  - sale amount is updated (totalSalesAmount += total)
     *  - a SAVED event is written to History
     */
    suspend fun addOrder(order: ShopOrder): Result<Unit> = runCatching {
        val stock = getStockOnce()
        val total = order.packets * order.unitPrice +
            order.kgQuantity * order.pricePerKg
        val profit = (order.packets / 12.0) * stock.profitPerDozen
        val now = System.currentTimeMillis()
        val finalOrder = order.copy(
            total = total,
            remaining = total - order.paid,
            orderProfit = profit,
            createdAt = if (order.createdAt == 0L) now else order.createdAt,
            ownerUid = order.ownerUid.ifEmpty { cloud.currentUid ?: "" }
        )
        db.shopOrderDao().insert(finalOrder)
        cloud.saveOrder(finalOrder)
        logOrderHistory(finalOrder, "SAVED")

        val newStock = stock.copy(
            packetsInStock = (stock.packetsInStock - order.packets).coerceAtLeast(0),
            totalPacketsSold = stock.totalPacketsSold + order.packets,
            totalSalesAmount = stock.totalSalesAmount + total
        )
        db.stockDao().save(newStock)
        cloud.saveStock(newStock)
    }

    /** Delete an order (long-press on its card, then confirm). */
    suspend fun deleteOrder(order: ShopOrder): Result<Unit> = runCatching {
        // Log the DELETED event FIRST, so the old order stays in History
        // even after the order row is gone from the Orders list.
        logOrderHistory(order, "DELETED")
        db.shopOrderDao().deleteById(order.id)
        cloud.deleteOrder(order.id)
    }

    /**
     * Update an existing order (Edit order from the Orders long-press
     * menu, or by tapping its card): total / remaining / orderProfit
     * are recomputed, stock is adjusted for the DIFFERENCE only, and
     * an UPDATED event is written to History. createdAt never changes.
     */
    suspend fun updateOrder(edited: ShopOrder): Result<Unit> = runCatching {
        val old = db.shopOrderDao().getById(edited.id) ?: return@runCatching
        val stock = getStockOnce()
        val total = edited.packets * edited.unitPrice +
            edited.kgQuantity * edited.pricePerKg
        val profit = (edited.packets / 12.0) * stock.profitPerDozen
        val now = System.currentTimeMillis()
        val finalOrder = edited.copy(
            total = total,
            remaining = total - edited.paid,
            orderProfit = profit,
            createdAt = old.createdAt,
            ownerUid = edited.ownerUid.ifEmpty { cloud.currentUid ?: "" }
        )
        db.shopOrderDao().update(finalOrder)
        cloud.saveOrder(finalOrder)
        logOrderHistory(finalOrder, "UPDATED")

        val newStock = stock.copy(
            packetsInStock = (stock.packetsInStock + (old.packets - edited.packets)).coerceAtLeast(0),
            totalPacketsSold = (stock.totalPacketsSold + (edited.packets - old.packets)).coerceAtLeast(0),
            totalSalesAmount = (stock.totalSalesAmount + (total - old.total)).coerceAtLeast(0.0)
        )
        db.stockDao().save(newStock)
        cloud.saveStock(newStock)
    }
}

/** Result of a cloud sync: what was pulled down and pushed up. */
data class SyncResult(
    val customersRestored: Int = 0,
    val historyRestored: Int = 0,
    val ordersRestored: Int = 0,
    val stockRestored: Boolean = false,
    val customersBackedUp: Int = 0,
    val ordersBackedUp: Int = 0
)
