package com.brinto.khata.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

/**
 * Photos: only images are accepted (the pickers below use "image/*").
 * A picked / taken photo is copied into the app's private folder, so
 * the thumbnail still shows after the gallery app is closed.
 * Profile photos are square-cropped (centre square, max 1024px) so
 * the whole photo fills the round profile circle.
 */
object ImageUtils {
    fun copyImageToInternalStorage(context: Context, uri: Uri): String? {
        return try {
            val dir = File(context.filesDir, "customer_photos").apply { mkdirs() }
            val file = File(dir, "photo_${System.currentTimeMillis()}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            }
            file.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    fun createCameraImageFile(context: Context): File {
        val dir = File(context.getExternalFilesDir("Pictures"), "BrintoKhata").apply { mkdirs() }
        return File(dir, "photo_${System.currentTimeMillis()}.jpg")
    }

    /**
     * Square-crops a photo file for the profile circle: the centre
     * square is saved (max 1024px side, JPEG 85) into the app's
     * private folder. Returns the new path, or null when the crop
     * fails (caller then keeps the original file).
     * Runs on a background thread — never call from the main thread.
     */
    fun saveSquaredProfilePhoto(context: Context, source: File): String? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(source.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            val maxDim = maxOf(bounds.outWidth, bounds.outHeight)
            while (maxDim / sample > 1024) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bitmap = BitmapFactory.decodeFile(source.absolutePath, opts) ?: return null
            val size = minOf(bitmap.width, bitmap.height)
            val squared = Bitmap.createBitmap(
                bitmap,
                (bitmap.width - size) / 2,
                (bitmap.height - size) / 2,
                size,
                size
            )
            val dir = File(context.filesDir, "customer_photos").apply { mkdirs() }
            val out = File(dir, "photo_${System.currentTimeMillis()}.jpg")
            FileOutputStream(out).use { squared.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            if (squared != bitmap) bitmap.recycle()
            squared.recycle()
            out.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Gallery pick -> square-cropped profile photo path. Falls back
     * to the plain copy when the crop fails.
     * Runs on a background thread — never call from the main thread.
     */
    fun copyProfilePhotoFromGallery(context: Context, uri: Uri): String? {
        val tempPath = copyImageToInternalStorage(context, uri) ?: return null
        val tempFile = File(tempPath)
        val squared = saveSquaredProfilePhoto(context, tempFile)
        return if (squared != null) {
            tempFile.delete()
            squared
        } else {
            tempPath
        }
    }

    /**
     * Camera file -> square-cropped profile photo path. The original
     * camera file is deleted after a successful crop; when the crop
     * fails the original path is returned.
     * Runs on a background thread — never call from the main thread.
     */
    fun squareCropCameraPhoto(context: Context, file: File): String {
        val squared = saveSquaredProfilePhoto(context, file)
        if (squared != null) {
            file.delete()
            return squared
        }
        return file.absolutePath
    }

    /**
     * Coil model for a stored photo: Cloudinary https URLs load
     * directly, local file paths load as files.
     */
    fun photoModel(path: String): Any =
        if (path.startsWith("http://") || path.startsWith("https://")) path else File(path)
}
