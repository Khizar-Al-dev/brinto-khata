package com.brinto.khata.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.brinto.khata.data.ShopOrder
import com.brinto.khata.ui.KhataViewModel
import com.brinto.khata.util.formatDate
import com.brinto.khata.util.quantityLine

/**
 * Orders — the SEPARATE order book, opened from the drawer ("Orders").
 * This list holds ONLY orders added here. People added on Home /
 * Customers are never shown or counted here, and orders added here
 * never appear on Home. Tap a card to edit the order; long-press
 * for Edit / Delete. The "+" button opens the short Add Order form
 * (name, optional phone, dozens, KG, price per KG, price per dozen).
 * Saving an order here does everything the customer flow does: dozen
 * packets leave the stock, a SAVED event is written to History, and
 * the order is synced to the cloud, so it comes back after a reinstall.
 * The red badge on the drawer "Orders" item and on the hamburger
 * menu shows how many orders are saved HERE — nothing else.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrdersScreen(
    viewModel: KhataViewModel,
    onBack: () -> Unit,
    onAddOrder: () -> Unit,
    onOrderClick: (String) -> Unit = {},
    onEditOrder: (String) -> Unit = {}
) {
    val orders by viewModel.orders.collectAsState()
    var query by remember { mutableStateOf("") }
    // Long-press an order card to choose Edit or Delete.
    var orderForOptions by remember { mutableStateOf<ShopOrder?>(null) }
    var orderToDelete by remember { mutableStateOf<ShopOrder?>(null) }

    val filtered = orders.filter { order ->
        if (query.isBlank()) true
        else order.name.contains(query, ignoreCase = true)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Orders (${orders.size})") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddOrder) {
                Icon(Icons.Default.Add, contentDescription = "Add order")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search by Name") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${filtered.size} orders", style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filtered, key = { it.id }) { order ->
                    OrderCard(
                        order,
                        onClick = { onOrderClick(order.id) },
                        onLongClick = { orderForOptions = order }
                    )
                }
            }
            // Long-press options — Edit or Delete.
            orderForOptions?.let { selected ->
                AlertDialog(
                    onDismissRequest = { orderForOptions = null },
                    title = { Text(selected.name) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(quantityLine(selected.unit, selected.packets, selected.kgQuantity))
                            Button(
                                onClick = {
                                    orderForOptions = null
                                    onEditOrder(selected.id)
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Edit order") }
                            OutlinedButton(
                                onClick = {
                                    orderForOptions = null
                                    orderToDelete = selected
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Delete order") }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { orderForOptions = null }) { Text("Cancel") }
                    }
                )
            }
            // Delete confirmation — delete only after Yes.
            orderToDelete?.let { toDelete ->
                AlertDialog(
                    onDismissRequest = { orderToDelete = null },
                    title = { Text("Delete order?") },
                    text = { Text("Delete ${toDelete.name}'s order? This cannot be undone.") },
                    confirmButton = {
                        TextButton(onClick = {
                            viewModel.deleteOrder(toDelete)
                            orderToDelete = null
                        }) { Text("Yes, delete") }
                    },
                    dismissButton = {
                        TextButton(onClick = { orderToDelete = null }) { Text("Cancel") }
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OrderCard(
    order: ShopOrder,
    onClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null
) {
    Card(
        modifier = Modifier.fillMaxWidth().combinedClickable(
            onClick = { onClick?.invoke() },
            onLongClick = onLongClick
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Default.ShoppingCart,
                contentDescription = "Order",
                modifier = Modifier.size(56.dp).clip(CircleShape)
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(order.name, style = MaterialTheme.typography.titleMedium)
                if (order.phone.isNotBlank()) {
                    Text("Phone: ${order.phone}", style = MaterialTheme.typography.bodySmall)
                }
                Text(
                    "${quantityLine(order.unit, order.packets, order.kgQuantity)}  |  Total: Rs ${order.total.toInt()}",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    "Paid: Rs ${order.paid.toInt()}  |  Remaining: Rs ${order.remaining.toInt()}",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (order.remaining > 0) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary
                )
                // Saved date — small text at the bottom of the card.
                Text(
                    "Saved: ${formatDate(order.createdAt)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
