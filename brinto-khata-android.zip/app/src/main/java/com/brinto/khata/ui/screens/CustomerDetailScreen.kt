package com.brinto.khata.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.brinto.khata.ui.KhataViewModel
import com.brinto.khata.util.ImageUtils
import com.brinto.khata.util.formatDate
import java.io.File

/**
 * Customer Detail — opened by tapping a saved customer card on Home.
 * Shows the same details as the card, plus:
 *  - large profile photo with a PENCIL icon to change it
 *    (Camera or Gallery, images only)
 *  - "Saved on" and "Paid on" dates
 *  - a Photos section below the details: + / Camera buttons add
 *    more photos (shop / location), shown as a grid of thumbnails.
 *  - three-dots menu (top-right): "Edit order" opens the edit form,
 *    "Delete customer" asks for confirmation and deletes (same as
 *    the long-press delete on Home).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerDetailScreen(
    viewModel: KhataViewModel,
    customerId: String,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onDeleted: () -> Unit
) {
    val context = LocalContext.current
    val customers by viewModel.customers.collectAsState()
    val customer = customers.firstOrNull { it.id == customerId }

    // Which photo is being picked: "profile" or "extra".
    var photoTarget by remember { mutableStateOf("profile") }
    var permissionNote by remember { mutableStateOf("") }
    var cameraFile by remember { mutableStateOf<File?>(null) }
    // Three-dots menu and delete confirmation.
    var menuExpanded by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    fun onPhotoPicked(path: String) {
        if (customer == null) return
        if (photoTarget == "profile") {
            viewModel.updateCustomerPhoto(customer.id, path)
        } else {
            viewModel.addExtraPhoto(customer.id, path)
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            ImageUtils.copyImageToInternalStorage(context, uri)?.let { onPhotoPicked(it) }
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success: Boolean ->
        if (success) {
            cameraFile?.let { onPhotoPicked(it.absolutePath) }
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted: Boolean ->
        if (granted) {
            val file = ImageUtils.createCameraImageFile(context)
            cameraFile = file
            val uri = FileProvider.getUriForFile(
                context, "com.brinto.khata.fileprovider", file
            )
            cameraLauncher.launch(uri)
        } else {
            permissionNote = "Camera permission ke baghair photo nahi le sakte. Settings se Camera allow karein."
        }
    }

    val galleryPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted: Boolean ->
        // On Android 13+ the system picker needs no permission; on older
        // phones it does. Either way, open the picker (images only).
        galleryLauncher.launch("image/*")
    }

    fun requestCamera(target: String) {
        photoTarget = target
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            val file = ImageUtils.createCameraImageFile(context)
            cameraFile = file
            val uri = FileProvider.getUriForFile(
                context, "com.brinto.khata.fileprovider", file
            )
            cameraLauncher.launch(uri)
        } else {
            permissionNote = "Camera se photo lene ke liye Camera permission chahiye."
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    fun requestGallery(target: String) {
        photoTarget = target
        val permission = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (ContextCompat.checkSelfPermission(context, permission) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            galleryLauncher.launch("image/*")
        } else {
            permissionNote = "Gallery se photo chunne ke liye gallery / photos permission chahiye. Sirf images allowed hain."
            galleryPermissionLauncher.launch(permission)
        }
    }

    if (permissionNote.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { permissionNote = "" },
            title = { Text("Permission") },
            text = { Text(permissionNote) },
            confirmButton = {
                TextButton(onClick = { permissionNote = "" }) { Text("OK") }
            }
        )
    }

    // Delete confirmation — same as the long-press delete on Home.
    if (showDeleteConfirm && customer != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete customer?") },
            text = { Text("Delete ${customer.name} (${customer.location})? This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirm = false
                    viewModel.deleteCustomer(customer)
                    onDeleted()
                }) { Text("Yes, delete") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(customer?.name ?: "Customer") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Three-dots menu: Edit order / Delete customer.
                    IconButton(onClick = { menuExpanded = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More options")
                    }
                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Edit order") },
                            onClick = {
                                menuExpanded = false
                                onEdit()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Delete customer") },
                            onClick = {
                                menuExpanded = false
                                showDeleteConfirm = true
                            }
                        )
                    }
                }
            )
        }
    ) { padding ->
        if (customer == null) {
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Customer not found — ye customer delete ho chuka ho sakta hai.")
            }
        } else {
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Large profile photo with pencil edit icon.
            Box(contentAlignment = Alignment.BottomEnd) {
                if (customer.photoPath.isNotBlank()) {
                    AsyncImage(
                        model = File(customer.photoPath),
                        contentDescription = "Profile photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(140.dp).clip(CircleShape)
                    )
                } else {
                    Icon(
                        Icons.Default.Person,
                        contentDescription = "No photo",
                        modifier = Modifier.size(140.dp).clip(CircleShape)
                    )
                }
                IconButton(
                    onClick = { requestGallery("profile") },
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit profile photo — pencil")
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { requestCamera("profile") }) {
                    Icon(Icons.Default.CameraAlt, contentDescription = "Camera")
                    Text(" Camera")
                }
                OutlinedButton(onClick = { requestGallery("profile") }) {
                    Icon(Icons.Default.Add, contentDescription = "Gallery")
                    Text(" + Gallery")
                }
            }
            Text(
                "Profile photo badalne ke liye pencil, Camera ya + Gallery par tap karein.",
                style = MaterialTheme.typography.bodySmall
            )

            // Same details as the Home card.
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(customer.name, style = MaterialTheme.typography.titleLarge)
                Text("Location: ${customer.location}", style = MaterialTheme.typography.bodyLarge)
                if (customer.phone.isNotBlank()) {
                    Text("Phone: ${customer.phone}", style = MaterialTheme.typography.bodyMedium)
                }
                Text("Packets: ${customer.packets}", style = MaterialTheme.typography.bodyMedium)
                Text(
                    "Total: Rs ${customer.total.toInt()}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    "Paid: Rs ${customer.paid.toInt()}  |  Remaining: Rs ${customer.remaining.toInt()}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (customer.remaining > 0) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary
                )
                if (customer.orderProfit > 0) {
                    Text(
                        "Profit in this order: Rs ${String.format("%.2f", customer.orderProfit)}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                Text(
                    "Saved on: ${formatDate(customer.createdAt)}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    "Paid on: ${formatDate(customer.paidDate)}",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Spacer(Modifier.height(4.dp))
            Text(
                "Photos",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { requestCamera("extra") }) {
                    Icon(Icons.Default.CameraAlt, contentDescription = "Camera")
                    Text(" Camera")
                }
                OutlinedButton(onClick = { requestGallery("extra") }) {
                    Icon(Icons.Default.Add, contentDescription = "Gallery")
                    Text(" + Add photo")
                }
            }
            Text(
                "Dukaan / location ki aur photos yahan add karein — sirf images allowed hain.",
                style = MaterialTheme.typography.bodySmall
            )
            if (customer.extraPhotos.isEmpty()) {
                Text(
                    "Abhi koi extra photo nahi hai.",
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.fillMaxWidth().height(240.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(customer.extraPhotos) { path ->
                        AsyncImage(
                            model = File(path),
                            contentDescription = "Customer photo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(110.dp)
                        )
                    }
                }
            }
        }
        }
    }
}
