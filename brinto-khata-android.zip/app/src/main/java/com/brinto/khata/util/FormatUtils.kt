package com.brinto.khata.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Formats a millis timestamp as dd/MM/yyyy, e.g. 02/02/2026. */
fun formatDate(millis: Long): String {
    if (millis == 0L) return "-"
    return SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(millis))
}
