package com.brinto.khata.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.brinto.khata.data.Customer
import com.brinto.khata.data.FirestoreRepository
import com.brinto.khata.data.HistoryEvent
import com.brinto.khata.data.KhataRepository
import com.brinto.khata.data.StockSettings
import com.brinto.khata.data.UserProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class KhataViewModel(
    private val repo: KhataRepository,
    private val cloud: FirestoreRepository
) : ViewModel() {

    val customers: StateFlow<List<Customer>> = repo.customers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val udhaar: StateFlow<List<Customer>> = repo.udhaar
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val stock: StateFlow<StockSettings?> = repo.stock
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val history: StateFlow<List<HistoryEvent>> = repo.history
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isLoggedIn = MutableStateFlow(cloud.currentUser != null)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _profile = MutableStateFlow<UserProfile?>(null)
    val profile: StateFlow<UserProfile?> = _profile.asStateFlow()

    private val _message = MutableStateFlow("")
    val message: StateFlow<String> = _message.asStateFlow()

    private val _users = MutableStateFlow<List<UserProfile>>(emptyList())
    val users: StateFlow<List<UserProfile>> = _users.asStateFlow()

    val isAdmin: Boolean get() = _profile.value?.role == "admin"

    init {
        viewModelScope.launch { loadProfile() }
    }

    fun setMessage(text: String) { _message.value = text }

    suspend fun loadProfile() {
        val uid = cloud.currentUser?.uid ?: return
        _profile.value = cloud.getProfile(uid)
        if (isAdmin) loadUsers()
    }

    fun signUp(email: String, password: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val result = cloud.signUp(email, password)
            if (result.isSuccess) {
                _isLoggedIn.value = true
                loadProfile()
                repo.refreshFromCloud()
                onDone(true)
            } else {
                _message.value = result.exceptionOrNull()?.message ?: "Sign up failed"
                onDone(false)
            }
        }
    }

    fun signIn(email: String, password: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val result = cloud.signIn(email, password)
            if (result.isSuccess) {
                _isLoggedIn.value = true
                loadProfile()
                repo.refreshFromCloud()
                onDone(true)
            } else {
                _message.value = result.exceptionOrNull()?.message ?: "Login failed"
                onDone(false)
            }
        }
    }

    fun signOut() {
        cloud.signOut()
        _isLoggedIn.value = false
        _profile.value = null
    }

    fun loadUsers() {
        viewModelScope.launch { _users.value = cloud.getAllUsers() }
    }

    fun createUserByAdmin(email: String, password: String) {
        viewModelScope.launch {
            val result = cloud.createUserByAdmin(email, password)
            if (result.isSuccess) {
                // Firebase Auth replaces the admin's session when creating
                // a user, so the admin signs in again afterwards.
                _message.value = "User created. Please sign in again as admin."
                _isLoggedIn.value = false
            } else {
                _message.value = result.exceptionOrNull()?.message ?: "Could not create user"
            }
            loadUsers()
        }
    }

    fun changeRole(uid: String, role: String) {
        viewModelScope.launch {
            cloud.setUserRole(uid, role)
            loadUsers()
        }
    }

    fun saveStock(packetsInStock: Int, pricePerDozen: Double, profitPerDozen: Double = 0.0) {
        viewModelScope.launch {
            val current = repo.getStockOnce()
            repo.saveStock(
                current.copy(
                    packetsInStock = packetsInStock,
                    pricePerDozen = pricePerDozen,
                    profitPerDozen = profitPerDozen
                )
            )
            _message.value = "Stock saved"
        }
    }

    fun updateCustomerPhoto(customerId: String, photoPath: String) {
        viewModelScope.launch {
            val result = repo.updateCustomerPhoto(customerId, photoPath)
            _message.value = if (result.isSuccess) "Profile photo updated"
            else result.exceptionOrNull()?.message ?: "Could not update photo"
        }
    }

    fun addExtraPhoto(customerId: String, photoPath: String) {
        viewModelScope.launch {
            val result = repo.addExtraPhoto(customerId, photoPath)
            _message.value = if (result.isSuccess) "Photo added"
            else result.exceptionOrNull()?.message ?: "Could not add photo"
        }
    }

    fun deleteCustomer(customer: Customer) {
        viewModelScope.launch {
            val result = repo.deleteCustomer(customer)
            _message.value = if (result.isSuccess) "Customer deleted: ${customer.name}"
            else result.exceptionOrNull()?.message ?: "Could not delete"
        }
    }

    fun addCustomer(customer: Customer, onDone: () -> Unit) {
        viewModelScope.launch {
            val result = repo.addCustomer(customer)
            if (result.isSuccess) {
                _message.value = "Saved. Stock deducted, sale added."
                onDone()
            } else {
                _message.value = result.exceptionOrNull()?.message ?: "Could not save"
            }
        }
    }

    fun updateCustomer(customer: Customer, onDone: () -> Unit) {
        viewModelScope.launch {
            val result = repo.updateCustomer(customer)
            if (result.isSuccess) {
                _message.value = "Order updated."
                onDone()
            } else {
                _message.value = result.exceptionOrNull()?.message ?: "Could not update"
            }
        }
    }
}
