package com.brinto.khata.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.brinto.khata.data.Customer
import com.brinto.khata.data.FirestoreRepository
import com.brinto.khata.data.HistoryEvent
import com.brinto.khata.data.isAdminEmail
import com.brinto.khata.data.KhataRepository
import com.brinto.khata.data.StockSettings
import com.brinto.khata.data.SyncResult
import com.brinto.khata.data.UserProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class KhataViewModel(
    private val repo: KhataRepository,
    private val cloud: FirestoreRepository
) : ViewModel() {

    val customers: StateFlow<List<Customer>> = repo.customers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val udhaar: StateFlow<List<Customer>> = repo.udhaar
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val stock: StateFlow<StockSettings?> = repo.stock
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val history: StateFlow<List<HistoryEvent>> = repo.history
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isLoggedIn = MutableStateFlow(cloud.currentUser != null)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _profile = MutableStateFlow<UserProfile?>(null)
    val profile: StateFlow<UserProfile?> = _profile.asStateFlow()

    private val _message = MutableStateFlow("")
    val message: StateFlow<String> = _message.asStateFlow()

    private val _users = MutableStateFlow<List<UserProfile>>(emptyList())
    val users: StateFlow<List<UserProfile>> = _users.asStateFlow()

    val isAdmin: Boolean get() = _profile.value?.email?.let { isAdminEmail(it) } == true

    init {
        viewModelScope.launch { loadProfile() }
        // Already signed in (the session survived app restarts): sync
        // on start too, so a wiped local database comes back from the
        // cloud without needing to log in again.
        if (cloud.currentUser != null) {
            viewModelScope.launch { runSync(report = false) }
        }
    }

    fun setMessage(text: String) { _message.value = text }

    suspend fun loadProfile() {
        val uid = cloud.currentUser?.uid ?: return
        _profile.value = cloud.getProfile(uid)
        if (isAdmin) loadUsers()
    }

    // Guards auto-sync against overlapping runs.
    private var syncing = false

    /**
     * Runs a two-way cloud sync and reports the outcome in [message].
     * When [report] is false (startup sync, fresh sign-up) only a
     * failure is shown, so a normal launch stays quiet.
     */
    private suspend fun runSync(report: Boolean) {
        val result = repo.refreshFromCloud()
        if (!report) {
            if (result.isFailure) {
                _message.value = "Cloud sync nahi ho saka — internet check karein, internet aate hi sync khud ho jayega."
            }
            return
        }
        result.fold(
            onSuccess = { sync ->
                _message.value = if (sync.customersRestored > 0 || sync.historyRestored > 0 || sync.stockRestored) {
                    "Cloud se data wapas aa gaya: ${sync.customersRestored} customers, ${sync.historyRestored} history."
                } else {
                    "Cloud sync ho gaya — sab data pehle se mojood hai."
                }
            },
            onFailure = {
                _message.value = "Cloud sync nahi ho saka — internet check karein aur dobara koshish karein."
            }
        )
    }

    /** Cloud sync on demand: called automatically the moment internet returns (see AutoSyncOnReconnect in MainActivity). */
    fun syncNow() {
        if (syncing) return
        syncing = true
        viewModelScope.launch {
            runSync(report = true)
            syncing = false
        }
    }

    fun signUp(email: String, password: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val result = cloud.signUp(email, password)
            if (result.isSuccess) {
                _isLoggedIn.value = true
                loadProfile()
                runSync(report = false)
                onDone(true)
            } else {
                _message.value = result.exceptionOrNull()?.message ?: "Sign up failed"
                onDone(false)
            }
        }
    }

    fun signIn(email: String, password: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val result = cloud.signIn(email, password)
            if (result.isSuccess) {
                _isLoggedIn.value = true
                loadProfile()
                runSync(report = true)
                onDone(true)
            } else {
                _message.value = result.exceptionOrNull()?.message ?: "Login failed"
                onDone(false)
            }
        }
    }

    fun signOut() {
        cloud.signOut()
        _isLoggedIn.value = false
        _profile.value = null
    }

    fun loadUsers() {
        viewModelScope.launch { _users.value = cloud.getAllUsers() }
    }

    fun createUserByAdmin(email: String, password: String) {
        viewModelScope.launch {
            val result = cloud.createUserByAdmin(email, password)
            if (result.isSuccess) {
                // Firebase Auth replaces the admin's session when creating
                // a user, so the admin signs in again afterwards.
                _message.value = "User created. Please sign in again as admin."
                _isLoggedIn.value = false
            } else {
                _message.value = result.exceptionOrNull()?.message ?: "Could not create user"
            }
            loadUsers()
        }
    }

    fun saveStock(packetsInStock: Int, pricePerDozen: Double, profitPerDozen: Double = 0.0) {
        viewModelScope.launch {
            val current = repo.getStockOnce()
            repo.saveStock(
                current.copy(
                    packetsInStock = packetsInStock,
                    pricePerDozen = pricePerDozen,
                    profitPerDozen = profitPerDozen
                )
            )
            _message.value = "Stock saved"
        }
    }

    fun updateCustomerPhoto(customerId: String, photoPath: String) {
        viewModelScope.launch {
            val result = repo.updateCustomerPhoto(customerId, photoPath)
            _message.value = if (result.isSuccess) "Profile photo updated"
            else result.exceptionOrNull()?.message ?: "Could not update photo"
        }
    }

    fun addExtraPhoto(customerId: String, photoPath: String) {
        viewModelScope.launch {
            val result = repo.addExtraPhoto(customerId, photoPath)
            _message.value = if (result.isSuccess) "Photo added"
            else result.exceptionOrNull()?.message ?: "Could not add photo"
        }
    }

    fun deleteCustomer(customer: Customer) {
        viewModelScope.launch {
            val result = repo.deleteCustomer(customer)
            _message.value = if (result.isSuccess) "Customer deleted: ${customer.name}"
            else result.exceptionOrNull()?.message ?: "Could not delete"
        }
    }

    fun addCustomer(customer: Customer, onDone: () -> Unit, onError: () -> Unit = {}) {
        viewModelScope.launch {
            val result = repo.addCustomer(customer)
            if (result.isSuccess) {
                _message.value = "Saved. Stock deducted, sale added."
                onDone()
            } else {
                _message.value = result.exceptionOrNull()?.message ?: "Could not save"
                onError()
            }
        }
    }

    fun updateCustomer(customer: Customer, onDone: () -> Unit, onError: () -> Unit = {}) {
        viewModelScope.launch {
            val result = repo.updateCustomer(customer)
            if (result.isSuccess) {
                _message.value = "Order updated."
                onDone()
            } else {
                _message.value = result.exceptionOrNull()?.message ?: "Could not update"
                onError()
            }
        }
    }
}
