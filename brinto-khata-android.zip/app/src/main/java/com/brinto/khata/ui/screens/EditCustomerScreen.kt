package com.brinto.khata.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.brinto.khata.ui.KhataViewModel
import com.brinto.khata.util.ImageUtils
import java.io.File

/**
 * Edit Order — opened from the Customer Detail screen's three-dots
 * menu ("Edit order"). Same layout as AddCustomerScreen, pre-filled
 * with the existing customer's data: info fields first, then
 * + / Camera photo options, then Total / Remaining calculation and
 * "Profit in this order". Changing packets / price / paid live-updates
 * the totals. "Update" saves the edited order: total, remaining and
 * profit are recomputed, stock is adjusted for the difference only,
 * and an UPDATED event is written to History.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditCustomerScreen(
    viewModel: KhataViewModel,
    customerId: String,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val context = LocalContext.current
    val stock by viewModel.stock.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val customer = customers.firstOrNull { it.id == customerId }

    // Pre-filled from the existing customer. remember(customer) resets
    // the fields if a different customer is opened.
    var name by remember(customer) { mutableStateOf(customer?.name ?: "") }
    var location by remember(customer) { mutableStateOf(customer?.location ?: "") }
    var phone by remember(customer) { mutableStateOf(customer?.phone ?: "") }
    var packetsText by remember(customer) { mutableStateOf(customer?.packets?.toString() ?: "") }
    var paidText by remember(customer) { mutableStateOf(customer?.paid?.let { if (it % 1.0 == 0.0) it.toInt().toString() else it.toString() } ?: "") }
    var priceText by remember(customer) { mutableStateOf(customer?.unitPrice?.toString() ?: "") }
    var photoPath by remember(customer) { mutableStateOf(customer?.photoPath ?: "") }
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    var error by remember { mutableStateOf("") }
    var permissionNote by remember { mutableStateOf("") }

    val defaultUnitPrice = stock?.pricePerPacket ?: 0.0
    val packets = packetsText.toIntOrNull() ?: 0
    val paid = paidText.toDoubleOrNull() ?: 0.0
    val unitPrice = priceText.toDoubleOrNull() ?: defaultUnitPrice
    val total = packets * unitPrice
    val remaining = total - paid
    // Profit in this order = (packets / 12) * profit per dozen.
    val orderProfit = (packets / 12.0) * (stock?.profitPerDozen ?: 0.0)

    var cameraFile by remember { mutableStateOf<File?>(null) }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            // "image/*" only — see the launcher call below.
            ImageUtils.copyImageToInternalStorage(context, uri)?.let { photoPath = it }
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success: Boolean ->
        if (success) {
            cameraFile?.let { photoPath = it.absolutePath }
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted: Boolean ->
        if (granted) {
            val file = ImageUtils.createCameraImageFile(context)
            cameraFile = file
            val uri = FileProvider.getUriForFile(
                context, "com.brinto.khata.fileprovider", file
            )
            photoUri = uri
            cameraLauncher.launch(uri)
        } else {
            permissionNote = "Camera permission ke baghair photo nahi le sakte. Settings se Camera allow karein."
        }
    }

    val galleryPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted: Boolean ->
        if (granted) {
            galleryLauncher.launch("image/*")
        } else {
            // Android 13+ (API 33+) does not need READ_MEDIA_IMAGES for the
            // system photo picker, but on older phones this permission is needed.
            galleryLauncher.launch("image/*")
        }
    }

    fun requestCamera() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            val file = ImageUtils.createCameraImageFile(context)
            cameraFile = file
            val uri = FileProvider.getUriForFile(
                context, "com.brinto.khata.fileprovider", file
            )
            photoUri = uri
            cameraLauncher.launch(uri)
        } else {
            permissionNote = "Camera se photo lene ke liye Camera permission chahiye."
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    fun requestGallery() {
        val permission = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (ContextCompat.checkSelfPermission(context, permission) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            galleryLauncher.launch("image/*")
        } else {
            permissionNote = "Gallery se photo chunne ke liye gallery / photos permission chahiye. Sirf images allowed hain."
            galleryPermissionLauncher.launch(permission)
        }
    }

    if (permissionNote.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { permissionNote = "" },
            title = { Text("Permission") },
            text = { Text(permissionNote) },
            confirmButton = {
                TextButton(onClick = { permissionNote = "" }) { Text("OK") }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Edit Order") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        if (customer == null) {
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Customer not found — ye customer delete ho chuka ho sakta hai.")
            }
        } else {
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("Name *") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = location, onValueChange = { location = it },
                label = { Text("Location *") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = phone, onValueChange = { phone = it },
                label = { Text("Phone (optional)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = packetsText, onValueChange = { packetsText = it },
                label = { Text("Packets purchased *") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = priceText, onValueChange = { priceText = it },
                label = { Text("Price per packet (Rs) — stock se auto, yahan change kar sakte hain") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Stock price: Rs ${String.format("%.2f", defaultUnitPrice)} per packet " +
                    "(Rs ${stock?.pricePerDozen?.toInt() ?: 0} per dozen). " +
                    "Upar wali price change kar dein to is order par wahi price lagegi.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedTextField(
                value = paidText, onValueChange = { paidText = it },
                label = { Text("Amount Paid (Rs) *") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Photo: right after the information fields — camera icon + gallery (+) icon, images only.
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (photoPath.isNotBlank()) {
                    AsyncImage(
                        model = File(photoPath),
                        contentDescription = "Customer photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(72.dp).clip(CircleShape)
                    )
                }
                Spacer(Modifier.size(12.dp))
                OutlinedButton(onClick = { requestCamera() }) {
                    Icon(Icons.Default.CameraAlt, contentDescription = "Camera")
                    Text(" Camera")
                }
                Spacer(Modifier.size(8.dp))
                OutlinedButton(onClick = { requestGallery() }) {
                    Icon(Icons.Default.Add, contentDescription = "Gallery")
                    Text(" + Gallery")
                }
            }
            Text(
                "Photo optional hai — location / dukaan yaad rakhne ke liye. Sirf images allowed hain.",
                style = MaterialTheme.typography.bodySmall
            )

            // Live totals — shown AFTER the photo options, auto calculated as the user types.
            Text("Total Bill: Rs ${String.format("%.2f", total)}", style = MaterialTheme.typography.titleMedium)
            Text("Remaining: Rs ${String.format("%.2f", remaining)}", style = MaterialTheme.typography.titleMedium)
            Text(
                "Profit in this order: Rs ${String.format("%.2f", orderProfit)}",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )

            if (error.isNotEmpty()) {
                Text(error, color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(4.dp))
            Button(
                onClick = {
                    if (name.isBlank() || location.isBlank() || packets <= 0) {
                        error = "Name, Location aur Packets (0 se zyada) zaroori hain."
                        return@Button
                    }
                    // paidDate / createdAt are handled by the repository:
                    // paidDate changes only if the paid amount changed,
                    // createdAt never changes. An UPDATED event is logged
                    // to History with the new values and today's date.
                    viewModel.updateCustomer(
                        customer.copy(
                            name = name.trim(),
                            location = location.trim(),
                            phone = phone.trim(),
                            packets = packets,
                            unitPrice = unitPrice,
                            total = total,
                            paid = paid,
                            remaining = remaining,
                            photoPath = photoPath,
                            orderProfit = orderProfit
                        )
                    ) { onSaved() }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Update")
            }
            Text(
                "Update karte hi stock packets ke farq ke hisaab se adjust ho jayega aur History mein UPDATED event save ho jayega.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        }
    }
}
