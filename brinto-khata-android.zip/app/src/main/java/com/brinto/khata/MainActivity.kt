package com.brinto.khata

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.People
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.brinto.khata.data.FirestoreRepository
import com.brinto.khata.data.KhataRepository
import com.brinto.khata.ui.KhataViewModel
import com.brinto.khata.ui.screens.AddCustomerScreen
import com.brinto.khata.ui.screens.AdminScreen
import com.brinto.khata.ui.screens.AuthScreen
import com.brinto.khata.ui.screens.CustomerDetailScreen
import com.brinto.khata.ui.screens.EditCustomerScreen
import com.brinto.khata.ui.screens.AnalyticsScreen
import com.brinto.khata.ui.screens.HistoryScreen
import com.brinto.khata.ui.screens.HomeScreen
import com.brinto.khata.ui.screens.StockScreen
import com.brinto.khata.ui.screens.UdhaarScreen
import com.brinto.khata.ui.theme.BrintoKhataTheme
import kotlinx.coroutines.launch

/**
 * Entry point. Login is compulsory: if not logged in, AuthScreen is shown.
 * After login, the home screen has a hamburger menu (top-left, three
 * lines) with: Home, Stock, Udhaar (Borrowed), Users (Admin only), Logout.
 *
 * Routes: auth / home / add / stock / udhaar / admin / history / detail/{customerId} / edit/{customerId}
 * Home, Stock, Udhaar, History, Users (Admin only), Logout are in the drawer.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BrintoKhataTheme {
                BrintoKhataAppContent()
            }
        }
    }
}

@Composable
fun BrintoKhataAppContent() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val app = context.applicationContext as BrintoKhataApp

    val factory = remember {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                val cloud = FirestoreRepository()
                val repo = KhataRepository(app.database, cloud)
                return KhataViewModel(repo, cloud) as T
            }
        }
    }
    val viewModel: KhataViewModel = viewModel(factory = factory)
    val isLoggedIn by viewModel.isLoggedIn.collectAsState()
    val profile by viewModel.profile.collectAsState()

    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    fun navigate(route: String) {
        scope.launch { drawerState.close() }
        navController.navigate(route) {
            launchSingleTop = true
        }
    }

    if (!isLoggedIn) {
        // Login flips isLoggedIn, this composable recomposes and the
        // NavHost below (startDestination = "home") is shown.
        AuthScreen(viewModel = viewModel, onLoggedIn = { })
        return
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    Image(
                        painter = painterResource(id = R.drawable.brinto_logo),
                        contentDescription = "Brinto logo",
                        modifier = Modifier.size(96.dp).clip(RoundedCornerShape(12.dp))
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("Brinto Khata", style = MaterialTheme.typography.titleLarge)
                    Text(
                        profile?.email ?: "",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        "Role: ${profile?.role ?: "user"}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                NavigationDrawerItem(
                    label = { Text("Home / Customers") },
                    icon = { androidx.compose.material3.Icon(Icons.Default.Home, contentDescription = null) },
                    selected = false,
                    onClick = { navigate("home") },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("Stock") },
                    icon = { androidx.compose.material3.Icon(Icons.Default.Inventory, contentDescription = null) },
                    selected = false,
                    onClick = { navigate("stock") },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("Udhaar (Borrowed)") },
                    icon = { androidx.compose.material3.Icon(Icons.Default.MoneyOff, contentDescription = null) },
                    selected = false,
                    onClick = { navigate("udhaar") },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("History") },
                    icon = { androidx.compose.material3.Icon(Icons.Default.History, contentDescription = null) },
                    selected = false,
                    onClick = { navigate("history") },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("Analytics") },
                    icon = { androidx.compose.material3.Icon(Icons.Default.Analytics, contentDescription = null) },
                    selected = false,
                    onClick = { navigate("analytics") },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                if (viewModel.isAdmin) {
                    NavigationDrawerItem(
                        label = { Text("Users (Admin)") },
                        icon = { androidx.compose.material3.Icon(Icons.Default.People, contentDescription = null) },
                        selected = false,
                        onClick = { navigate("admin") },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )
                }
                NavigationDrawerItem(
                    label = { Text("Logout") },
                    icon = { androidx.compose.material3.Icon(Icons.Default.Logout, contentDescription = null) },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        viewModel.signOut()
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
            }
        }
    ) {
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.fillMaxSize()
        ) {
            composable("home") {
                HomeScreen(
                    viewModel = viewModel,
                    drawerState = drawerState,
                    scope = scope,
                    onAddCustomer = { navController.navigate("add") },
                    onCustomerClick = { customerId -> navController.navigate("detail/$customerId") }
                )
            }
            composable("detail/{customerId}") { backStackEntry ->
                val customerId = backStackEntry.arguments?.getString("customerId") ?: ""
                CustomerDetailScreen(
                    viewModel = viewModel,
                    customerId = customerId,
                    onBack = { navController.popBackStack() },
                    onEdit = { navController.navigate("edit/$customerId") },
                    onDeleted = { navController.popBackStack() }
                )
            }
            composable("edit/{customerId}") { backStackEntry ->
                val customerId = backStackEntry.arguments?.getString("customerId") ?: ""
                EditCustomerScreen(
                    viewModel = viewModel,
                    customerId = customerId,
                    onBack = { navController.popBackStack() },
                    onSaved = { navController.popBackStack() }
                )
            }
            composable("history") {
                HistoryScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
            }
            composable("analytics") {
                AnalyticsScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
            }
            composable("add") {
                AddCustomerScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onSaved = { navController.popBackStack() }
                )
            }
            composable("stock") {
                StockScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
            }
            composable("udhaar") {
                UdhaarScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
            }
            composable("admin") {
                AdminScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
            }
        }
    }
}
