# Brinto Khata — Android Code

Bhai, ye **Brinto Khata** ka poora Android code hai — Brinto Washing Powder ke wholesalers ka khata / ledger app.

> **Saaf baat pehle:** Ye **code hai, ready APK file NAHI hai.** Maine yahan compile NAHI kiya — is environment mein Android SDK nahi hai. APK isi code ko **Android Studio** mein khol kar banani paregi (steps neeche hain). Cloud sync ke liye Firebase setup zaroori hai (neeche), warna data sirf phone mein local rahega.

## Ye app kya karti hai

- **Login compulsory hai:** Email (Gmail) + password se Sign Up / Login. Password aap khud chunte hain.
- **Pehla user Admin hota hai.** Admin aur user accounts bana sakta hai (Admin screen > Users).
- **Customer add karein:** Name, Location, Phone (optional), Packets purchased, Amount Paid, Photo (optional).
- **Total aur Remaining auto:** Price per dozen (12 packets) se per-packet price nikalta hai, Total = packets × per-packet price, Remaining = Total − Paid.
- **Stock auto-deduct:** Order add hote hi stock se packets kam ho jate hain aur sale total mein add ho jata hai.
- **Udhaar section:** Jin customers ka Remaining > 0 hai, wo alag list mein dikhte hain.
- **Search:** Upar search bar — Name ya Location se search karein, type karte hi list filter hoti hai.
- **Photo:** Camera icon se photo lein, + icon se gallery se chunein. Sirf images allowed hain.
- **Data safe:** Firebase Auth + Firestore se cloud sync. App delete ho jaye to usi Gmail se dobara login karein — data wapas aa jayega. Offline ke liye Room database bhi hai (phone mein local copy).

## Logo

Logo file is project mein hai:
- `logo.jpg` — project root mein (asal uploaded image)
- `app/src/main/res/drawable/brinto_logo.jpg` — login / splash / header mein use hota hai (`R.drawable.brinto_logo`)

## Firebase setup — zaroori hai, warna cloud sync nahi chalega

1. [Firebase Console](https://console.firebase.google.com/) kholein → **Add project** → naam dein, e.g. `brinto-khata` → Create.
2. Project mein **Add app → Android** → Android package name likhein: **`com.brinto.khata`** → Register app.
3. **google-services.json download karein** aur is project mein **`app/` folder mein** rakh dein (yani `brinto-khata-android/app/google-services.json`). Is file ke baghair cloud sync kaam nahi karega — app phir sirf local (Room) mode mein chalegi.
4. Firebase Console → **Build → Authentication → Sign-in method → Email/Password → Enable** → Save.
5. Firebase Console → **Build → Firestore Database → Create database** → Production mode ya Test mode chunein → location chunein → Enable.
6. Firestore Rules (test ke liye): `rules_version = '2'; service cloud.firestore { match /databases/{database}/documents { match /{document=**} { allow read, write: if request.auth != null; } } }` — production mein isko sakht (strict) karein.

## Android Studio mein kaise kholein

1. Computer par **Android Studio** install karein (free hai, developer.android.com/studio).
2. Is folder `brinto-khata-android` ko **zip se extract** karein.
3. Android Studio kholein → **Open** → `brinto-khata-android` folder chunein. Ya: **New Project → Empty Activity (Compose)**, naam `Brinto Khata`, package `com.brinto.khata`, Minimum SDK **API 26** — phir is project ki files us naye project mein copy kar dein (neeche file list dekhein).
4. **Gradle sync** karein (upar Sync Now). Pehli baar internet chahiye — Gradle dependencies download hongi. App chalane ke liye baad mein internet nahi chahiye, lekin cloud sync ke liye internet chahiye.
5. Phone ko USB se connect karein (USB Debugging ON) ya emulator use karein → **Run ▶** dabayein.

## APK kaise banayein

1. Android Studio mein: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
2. APK yahan milegi: **`app/build/outputs/apk/debug/app-debug.apk`**
3. Us APK ko phone par install karein. Install karte waqt phone "Unknown sources / Play Protect" ka warning dega — **Install anyway** chunna parega, kyunki ye Play Store se nahi hai. Kaam ho jaye to Play Protect dobara **ON** kar dena.

## Test kaise karein (2 steps mein)

1. **Sign Up karein** apni Gmail + password se — aap pehle user hain, is liye aap **Admin** ban jayenge.
2. **Hamburger menu (upar left, three lines) → Stock** kholein → pencil (edit) icon par tap karein → Packets in Stock likhein (e.g. 100) aur Price per dozen (12 packets) likhein (e.g. 1200) → Save Stock.
3. **Home → + button → Add Customer:** Name, Location likhein, Packets e.g. 12, Paid e.g. 500 likhein → Save.
   - Check karein: Total = 12 × (600 ÷ 6 = 100) = Rs 1200, Remaining = 1200 − 500 = Rs 700.
   - Stock check karein: 100 − 12 = 88 packets reh gaye, Total sale = Rs 1200.
4. **Udhaar** kholein — ye customer wahan dikhna chahiye (Remaining 700 > 0).
5. **Search** mein uska naam ya location type karein — list filter honi chahiye.
6. **Admin → Users** mein naya user banayein, phir us email se login karke check karein.

## File list — har feature kahan hai

| Feature | File | Function / Screen |
|---|---|---|
| Login / Sign Up (email + password) | `ui/screens/AuthScreen.kt` | `AuthScreen()` |
| Login compulsory, drawer + navigation | `MainActivity.kt` | `BrintoKhataAppContent()` |
| First user = Admin, user accounts | `data/FirestoreRepository.kt` | `signUp()`, `createUserByAdmin()`, `getAllUsers()`, `setUserRole()` |
| Admin screen (users list, role, create user) | `ui/screens/AdminScreen.kt` | `AdminScreen()` |
| Customer form: Name, Location, Phone (optional), Packets, Paid | `ui/screens/AddCustomerScreen.kt` | `AddCustomerScreen()` |
| Total / Remaining auto | `ui/screens/AddCustomerScreen.kt` + `data/KhataRepository.kt` | `total = packets * unitPrice`, `remaining = total - paid` in `addCustomer()` |
| Price per dozen → per-packet, order price override | `data/Models.kt` (`StockSettings.pricePerPacket`) + `AddCustomerScreen.kt` (price field) | `pricePerPacket = pricePerDozen / 12` |
| Photo: camera + gallery, images only | `ui/screens/AddCustomerScreen.kt` + `util/ImageUtils.kt` | camera / gallery launchers, `GetContent("image/*")`, `TakePicture()` |
| Permissions (Camera, gallery) runtime | `ui/screens/AddCustomerScreen.kt` + `AndroidManifest.xml` | `requestCamera()`, `requestGallery()`, `RequestPermission()` |
| Cloud sync (Firebase Auth + Firestore) | `data/FirestoreRepository.kt` | `saveCustomer()`, `loadCustomers()`, `saveStock()`, `loadStock()` |
| Data survives app deletion (Gmail re-login) | `data/KhataRepository.kt` | `refreshFromCloud()` — login par cloud se Room mein wapas |
| Offline cache (Room) | `data/AppDatabase.kt`, `data/Models.kt` | `CustomerDao`, `StockDao`, `AppDatabase` |
| Hamburger menu (top-left, three lines) | `MainActivity.kt` | `ModalNavigationDrawer`, `HomeScreen` TopAppBar menu icon |
| Stock: packets + price per 6, pencil edit | `ui/screens/StockScreen.kt` | `StockScreen()`, pencil `IconButton` → `editing` mode |
| Stock auto-deduct + sale total | `data/KhataRepository.kt` | `addCustomer()` — stock deduct, `totalPacketsSold`, `totalSalesAmount` |
| Customers list (home) | `ui/screens/HomeScreen.kt` | `HomeScreen()`, `CustomerCard()` |
| Search by Name / Location | `ui/screens/HomeScreen.kt` | search bar + `FilterChip` Name / Location, `filtered` list |
| Udhaar / Borrowed section | `ui/screens/UdhaarScreen.kt` | `UdhaarScreen()` — `remaining > 0` (`KhataRepository.udhaar`) |
| Logo | `app/src/main/res/drawable/brinto_logo.jpg`, `logo.jpg` | `AuthScreen`, `MainActivity` header — `R.drawable.brinto_logo` |
| App theme (blue/red, logo colours) | `ui/theme/Theme.kt` | `BrintoKhataTheme()` |
| Permissions in manifest | `app/src/main/AndroidManifest.xml` | CAMERA, READ_MEDIA_IMAGES, READ_EXTERNAL_STORAGE |

## Tech

Kotlin, Jetpack Compose, Material 3, minSdk 26, targetSdk 34, Room 2.6.1, Firebase BoM 33.7.0 (Auth + Firestore), Navigation Compose, Coil (photo thumbnails). Bluetooth ki zaroorat nahi hai.

## Limits — dobara saaf lafzon mein

- Ye **code hai, ready APK nahi**. Yahan compile nahi hua (Android SDK nahi hai). APK Android Studio mein banegi.
- **google-services.json ke baghair** cloud sync nahi chalega — data sirf phone mein local rahega. Firebase setup upar diye steps se karein.
- Photo sirf phone mein save hoti hai (local file path) — Firestore mein photo upload nahi hoti, is liye doosre phone par photo thumbnail nahi dikhega, baaki data (naam, packets, paisa) sync hoga.
- Admin se user banane par admin ko dobara login karna parega (Firebase Auth ki limit — production mein Cloud Function use karein).
