# Kheera Slice Game

Colorful animated 2D slicing game: tap anywhere to slice the cucumber while the
knife slowly moves left to right. 1000 levels — each level needs one more slice
than the last. Theme music and the "THAK" cut sound are generated in-game with
Web Audio.

The game itself is a single self-contained page in
`app/src/main/assets/game.html`, wrapped in a minimal Android WebView app
(`com.kheera.slice`). Push to `main` to build the debug APK with GitHub Actions.
