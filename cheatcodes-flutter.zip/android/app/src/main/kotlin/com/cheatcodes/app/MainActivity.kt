package com.cheatcodes.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
