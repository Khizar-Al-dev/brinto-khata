import '../models/models.dart';

/// The GTA library. Cheat counts are filled in from the bundled database
/// (assets/data/cheats.json) once research lands; GTA VI stays Coming Soon
/// until verified codes exist — no fake codes, ever.
const List<GameInfo> kGames = [
  GameInfo(
    id: 'gta-3',
    title: 'GTA III',
    shortTitle: 'III',
    year: 2001,
    platforms: ['PC', 'PS2', 'Xbox', 'Mobile'],
    status: GameStatus.available,
    tagline: 'Liberty City. The one that started the 3D era.',
  ),
  GameInfo(
    id: 'vice-city',
    title: 'GTA Vice City',
    shortTitle: 'VC',
    year: 2002,
    platforms: ['PC', 'PS2', 'Xbox', 'Mobile'],
    status: GameStatus.available,
    tagline: 'Neon lights, Ocean Drive, Tommy Vercetti.',
  ),
  GameInfo(
    id: 'san-andreas',
    title: 'GTA San Andreas',
    shortTitle: 'SA',
    year: 2004,
    platforms: ['PC', 'PS2', 'Xbox', 'Mobile'],
    status: GameStatus.available,
    tagline: 'Grove Street. San Andreas. CJ is home.',
  ),
  GameInfo(
    id: 'advance',
    title: 'GTA Advance',
    shortTitle: 'ADV',
    year: 2004,
    platforms: ['GBA'],
    status: GameStatus.available,
    tagline: 'Liberty City on Game Boy Advance.',
  ),
  GameInfo(
    id: 'lcs',
    title: 'GTA Liberty City Stories',
    shortTitle: 'LCS',
    year: 2005,
    platforms: ['PSP', 'PS2', 'Mobile'],
    status: GameStatus.available,
    tagline: 'Toni Cipriani returns to Liberty City.',
  ),
  GameInfo(
    id: 'vcs',
    title: 'GTA Vice City Stories',
    shortTitle: 'VCS',
    year: 2006,
    platforms: ['PSP', 'PS2'],
    status: GameStatus.available,
    tagline: 'Vic Vance. Vice City, two years earlier.',
  ),
  GameInfo(
    id: 'gta-4',
    title: 'GTA IV',
    shortTitle: 'IV',
    year: 2008,
    platforms: ['PC', 'PS3', 'Xbox 360'],
    status: GameStatus.available,
    tagline: 'Niko Bellic. The American Dream, Liberty City.',
  ),
  GameInfo(
    id: 'chinatown-wars',
    title: 'GTA Chinatown Wars',
    shortTitle: 'CW',
    year: 2009,
    platforms: ['DS', 'PSP', 'Mobile'],
    status: GameStatus.available,
    tagline: 'Huang Lee. Top-down chaos in Liberty City.',
  ),
  GameInfo(
    id: 'eflc',
    title: 'GTA Episodes from Liberty City',
    shortTitle: 'EFLC',
    year: 2009,
    platforms: ['PC', 'PS3', 'Xbox 360'],
    status: GameStatus.available,
    tagline: 'The Lost and Damned + The Ballad of Gay Tony.',
  ),
  GameInfo(
    id: 'gta-5',
    title: 'GTA V',
    shortTitle: 'V',
    year: 2013,
    platforms: ['PC', 'PS3', 'PS4', 'PS5', 'Xbox'],
    status: GameStatus.available,
    tagline: 'Michael, Franklin, Trevor. Los Santos.',
  ),
  GameInfo(
    id: 'gta-6',
    title: 'GTA VI',
    shortTitle: 'VI',
    year: 2026,
    platforms: ['PS5', 'Xbox Series X/S'],
    status: GameStatus.available,
    tagline: 'Leonida. Lucia and Jason. Out now on PS5 and Xbox.',
    notice:
        'Cheats unlock only after completing the main story. Activating a cheat disables saving and achievements for that session.',
  ),
];

GameInfo gameById(String id) =>
    kGames.firstWhere((g) => g.id == id, orElse: () => kGames.first);
