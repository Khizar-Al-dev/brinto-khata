import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/models.dart';
import 'games.dart';

/// Loads the bundled, verified cheat database (assets/data/cheats.json).
/// The file is generated from researched, cross-checked codes only.
/// If it is missing or empty, the library shows an honest empty state —
/// never fake codes.
class CheatRepository {
  static final CheatRepository instance = CheatRepository._();
  CheatRepository._();

  List<Cheat> _cheats = [];
  bool _loaded = false;

  Future<void> load() async {
    if (_loaded) return;
    try {
      final raw = await rootBundle.loadString('assets/data/cheats.json');
      final List<dynamic> list = jsonDecode(raw) as List<dynamic>;
      _cheats = list
          .map((e) => Cheat.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      _cheats = [];
    }
    _loaded = true;
  }

  List<Cheat> get all => List.unmodifiable(_cheats);

  int countForGame(String gameId) =>
      _cheats.where((c) => c.gameId == gameId).length;

  List<Cheat> forGame(String gameId, {CheatCategory category = CheatCategory.all}) {
    var list = _cheats.where((c) => c.gameId == gameId).toList();
    if (category != CheatCategory.all) {
      list = list.where((c) => c.category == category).toList();
    }
    return list;
  }

  /// Global smart search across names, codes, combos, phone numbers,
  /// descriptions, categories, platforms and game titles.
  List<Cheat> search(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return [];
    return _cheats.where((c) {
      final game = gameById(c.gameId);
      final haystack = [
        c.name,
        c.keyboardCode ?? '',
        c.psCombo ?? '',
        c.xboxCombo ?? '',
        c.otherCombo ?? '',
        c.phoneNumber ?? '',
        c.description,
        c.category.label,
        c.version,
        ...c.platforms,
        game.title,
        game.shortTitle,
      ].join(' ').toLowerCase();
      return haystack.contains(q);
    }).toList();
  }
}
