import 'package:shared_preferences/shared_preferences.dart';

/// Local favorites (works offline; account sync arrives with Supabase in
/// Phase 2 / Phase 6).
class FavoritesStore {
  static const _key = 'cc_favorites';

  static Future<Set<String>> load() async {
    final p = await SharedPreferences.getInstance();
    return (p.getStringList(_key) ?? <String>[]).toSet();
  }

  static Future<bool> isFavorite(String cheatId) async {
    return (await load()).contains(cheatId);
  }

  static Future<bool> toggle(String cheatId) async {
    final p = await SharedPreferences.getInstance();
    final set = (p.getStringList(_key) ?? <String>[]).toSet();
    final nowFav = !set.contains(cheatId);
    if (nowFav) {
      set.add(cheatId);
    } else {
      set.remove(cheatId);
    }
    await p.setStringList(_key, set.toList());
    return nowFav;
  }
}

/// Recent searches, stored locally.
class RecentSearches {
  static const _key = 'cc_recent_searches';

  static Future<List<String>> load() async {
    final p = await SharedPreferences.getInstance();
    return p.getStringList(_key) ?? <String>[];
  }

  static Future<void> add(String query) async {
    final q = query.trim();
    if (q.isEmpty) return;
    final p = await SharedPreferences.getInstance();
    final list = p.getStringList(_key) ?? <String>[];
    list.remove(q);
    list.insert(0, q);
    await p.setStringList(_key, list.take(10).toList());
  }

  static Future<void> clear() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(_key);
  }
}
