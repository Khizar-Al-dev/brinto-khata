import 'package:shared_preferences/shared_preferences.dart';

/// Authentication sessions.
/// Guest mode works fully offline right now. Email / Google sign-in is wired
/// to Supabase in Phase 2 — the methods below deliberately throw until the
/// Supabase project is configured, so the app never fakes a login.
class AuthService {
  static const _kSession = 'cc_session'; // 'guest' | 'user'
  static const _kName = 'cc_name';
  static const _kEmail = 'cc_email';

  Future<String?> get sessionKind async {
    final p = await SharedPreferences.getInstance();
    return p.getString(_kSession);
  }

  Future<bool> get isGuest async => await sessionKind == 'guest';
  Future<bool> get isLoggedIn async => await sessionKind == 'user';

  Future<String?> get displayName async {
    final p = await SharedPreferences.getInstance();
    return p.getString(_kName);
  }

  Future<String?> get email async {
    final p = await SharedPreferences.getInstance();
    return p.getString(_kEmail);
  }

  Future<void> signInAsGuest() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_kSession, 'guest');
    await p.remove(_kName);
    await p.remove(_kEmail);
  }

  Future<void> signOut() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(_kSession);
    await p.remove(_kName);
    await p.remove(_kEmail);
  }

  // ---- Phase 2: Supabase (not configured yet) ----
  Future<void> signInWithEmail(String email, String password) {
    throw UnimplementedError(
        'Supabase is not configured yet (Phase 2). Use Guest mode for now.');
  }

  Future<void> signUpWithEmail(String name, String email, String password) {
    throw UnimplementedError(
        'Supabase is not configured yet (Phase 2). Use Guest mode for now.');
  }

  Future<void> signInWithGoogle() {
    throw UnimplementedError(
        'Supabase is not configured yet (Phase 2). Use Guest mode for now.');
  }

  Future<void> resetPassword(String email) {
    throw UnimplementedError(
        'Supabase is not configured yet (Phase 2). Use Guest mode for now.');
  }
}
