import 'dart:math';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Subtle floating particles + a soft lime glow — the signature background
/// used on splash, welcome and auth screens. Lightweight: one painter,
/// ~26 dots, no images.
class ParticleBackground extends StatefulWidget {
  const ParticleBackground({super.key});

  @override
  State<ParticleBackground> createState() => _ParticleBackgroundState();
}

class _ParticleBackgroundState extends State<ParticleBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final List<_Dot> _dots;

  @override
  void initState() {
    super.initState();
    final rand = Random(7);
    _dots = List.generate(26, (_) => _Dot(rand));
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 36),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(
          decoration: const BoxDecoration(
            gradient: RadialGradient(
              center: Alignment(0.5, -0.6),
              radius: 1.1,
              colors: [Color(0xFF1E2A12), AppColors.midnight],
            ),
          ),
        ),
        AnimatedBuilder(
          animation: _controller,
          builder: (_, __) => CustomPaint(
            painter: _ParticlePainter(_dots, _controller.value),
            size: Size.infinite,
          ),
        ),
      ],
    );
  }
}

class _Dot {
  final double x;
  final double y;
  final double r;
  final double speed;
  final double opacity;
  final bool lime;

  _Dot(Random rand)
      : x = rand.nextDouble(),
        y = rand.nextDouble(),
        r = 1 + rand.nextDouble() * 2.4,
        speed = 0.008 + rand.nextDouble() * 0.02,
        opacity = 0.15 + rand.nextDouble() * 0.45,
        lime = rand.nextBool();
}

class _ParticlePainter extends CustomPainter {
  final List<_Dot> dots;
  final double t;

  _ParticlePainter(this.dots, this.t);

  @override
  void paint(Canvas canvas, Size size) {
    for (final d in dots) {
      final y = ((d.y - t * d.speed) % 1.0) * size.height;
      final twinkle = 0.6 + 0.4 * sin((t * 6.28) + d.x * 12);
      final paint = Paint()
        ..color = (d.lime ? AppColors.neonLime : AppColors.white)
            .withOpacity(d.opacity * twinkle)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(d.x * size.width, y), d.r, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _ParticlePainter old) => old.t != t;
}
