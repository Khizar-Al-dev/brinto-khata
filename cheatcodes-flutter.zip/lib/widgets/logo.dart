import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Original CHEATCODES mark — neon-lime "CC" badge. No Rockstar artwork,
/// no copied logo: a clean gaming badge built from shapes + type.
class LogoBadge extends StatelessWidget {
  final double size;
  const LogoBadge({super.key, this.size = 72});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * 0.26),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFD6FF6B), AppColors.neonLime, Color(0xFF7FBF1F)],
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.neonLime.withOpacity(0.35),
            blurRadius: 24,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Center(
        child: Text(
          'CC',
          style: TextStyle(
            color: AppColors.midnight,
            fontSize: size * 0.42,
            fontWeight: FontWeight.w900,
            letterSpacing: -1,
          ),
        ),
      ),
    );
  }
}

class CheatCodesLogo extends StatelessWidget {
  final double badgeSize;
  final bool showSubtitle;
  const CheatCodesLogo({super.key, this.badgeSize = 84, this.showSubtitle = true});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        LogoBadge(size: badgeSize),
        const SizedBox(height: 18),
        const Text(
          'CHEATCODES',
          style: TextStyle(
            color: AppColors.white,
            fontSize: 30,
            fontWeight: FontWeight.w900,
            letterSpacing: 3,
          ),
        ),
        if (showSubtitle) ...[
          const SizedBox(height: 6),
          const Text(
            'ULTIMATE GTA CHEATCODES',
            style: TextStyle(
              color: AppColors.neonLime,
              fontSize: 12,
              fontWeight: FontWeight.w700,
              letterSpacing: 4,
            ),
          ),
        ],
      ],
    );
  }
}
