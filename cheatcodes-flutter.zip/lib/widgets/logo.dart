import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// CheatVerse mark — the user's poster logo, with the name and a
/// GTA-style "GTA CHEATCODES" subtitle in the Pricedown font.
class LogoBadge extends StatelessWidget {
  final double size;
  const LogoBadge({super.key, this.size = 72});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * 0.26),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFD6FF6B), AppColors.neonLime, Color(0xFF7FBF1F)],
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.neonLime.withOpacity(0.35),
            blurRadius: 24,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Center(
        child: Text(
          'CV',
          style: TextStyle(
            color: AppColors.midnight,
            fontSize: size * 0.42,
            fontWeight: FontWeight.w900,
            letterSpacing: -1,
          ),
        ),
      ),
    );
  }
}

class CheatCodesLogo extends StatelessWidget {
  final double badgeSize;
  final bool showSubtitle;
  const CheatCodesLogo({super.key, this.badgeSize = 84, this.showSubtitle = true});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Image.asset(
            'assets/images/logo.png',
            width: badgeSize + 90,
            height: badgeSize + 90,
            fit: BoxFit.cover,
          ),
        ),
        const SizedBox(height: 18),
        const Text(
          'CHEATVERSE',
          style: TextStyle(
            color: AppColors.white,
            fontSize: 30,
            fontWeight: FontWeight.w900,
            letterSpacing: 3,
          ),
        ),
        if (showSubtitle) ...[
          const SizedBox(height: 6),
          const Text(
            'GTA CHEATCODES',
            style: TextStyle(
              color: AppColors.neonLime,
              fontSize: 22,
              fontFamily: 'Pricedown',
              letterSpacing: 2,
            ),
          ),
        ],
      ],
    );
  }
}
