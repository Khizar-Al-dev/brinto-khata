import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/models.dart';
import '../services/favorites_store.dart';
import '../theme/app_theme.dart';
import '../utils/routes.dart';

/// The cheat detail card — the most important widget in the app.
/// Order: name, keyboard code, console combos, phone number, description,
/// verification info. Long-press any code row to copy it; the copy button
/// does the same. Never shows a fake code — null fields render as
/// "Not available for this game/version."
class CheatCard extends StatefulWidget {
  final Cheat cheat;
  final bool showGame;
  const CheatCard({super.key, required this.cheat, this.showGame = false});

  @override
  State<CheatCard> createState() => _CheatCardState();
}

class _CheatCardState extends State<CheatCard> {
  bool _fav = false;

  @override
  void initState() {
    super.initState();
    FavoritesStore.isFavorite(widget.cheat.id).then((v) {
      if (mounted) setState(() => _fav = v);
    });
  }

  Future<void> _copy(BuildContext context, String text) async {
    await Clipboard.setData(ClipboardData(text: text));
    HapticFeedback.lightImpact();
    if (context.mounted) showCopiedSnack(context);
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.cheat;
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Text(
                    c.name,
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w800),
                  ),
                ),
                const SizedBox(width: 8),
                _VerifiedChip(verified: c.verified),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  onPressed: () async {
                    final nowFav = await FavoritesStore.toggle(c.id);
                    setState(() => _fav = nowFav);
                  },
                  icon: Icon(
                    _fav ? Icons.favorite : Icons.favorite_border,
                    color: _fav ? AppColors.neonLime : AppColors.steelGrey,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              c.category.label.toUpperCase(),
              style: const TextStyle(
                  color: AppColors.neonLime,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.5),
            ),
            const SizedBox(height: 12),
            if (c.keyboardCode != null)
              _CodeRow(
                label: 'KEYBOARD',
                value: c.keyboardCode!,
                onCopy: () => _copy(context, c.keyboardCode!),
              ),
            if (c.psCombo != null) ...[
              const SizedBox(height: 10),
              _ComboRow(
                label: 'PLAYSTATION',
                combo: c.psCombo!,
                onCopy: () => _copy(context, c.psCombo!),
              ),
            ],
            if (c.xboxCombo != null) ...[
              const SizedBox(height: 10),
              _ComboRow(
                label: 'XBOX',
                combo: c.xboxCombo!,
                onCopy: () => _copy(context, c.xboxCombo!),
              ),
            ],
            if (c.otherCombo != null) ...[
              const SizedBox(height: 10),
              _ComboRow(
                label: 'HANDHELD',
                combo: c.otherCombo!,
                onCopy: () => _copy(context, c.otherCombo!),
              ),
            ],
            if (c.dpadCombo != null) ...[
              const SizedBox(height: 10),
              _ComboRow(
                label: 'D-PAD',
                combo: c.dpadCombo!,
                onCopy: () => _copy(context, c.dpadCombo!),
              ),
            ],
            const SizedBox(height: 10),
            if (c.phoneNumber != null)
              _CodeRow(
                label: 'PHONE',
                value: c.phoneNumber!,
                onCopy: () => _copy(context, c.phoneNumber!),
              )
            else
              const _UnavailableRow(label: 'PHONE'),
            const SizedBox(height: 12),
            Text(c.description, style: const TextStyle(height: 1.45)),
            if (c.unlockRequirement != null) ...[
              const SizedBox(height: 8),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.lock_open,
                      size: 14, color: AppColors.neonLime),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'Unlock: ${c.unlockRequirement!}',
                      style: const TextStyle(
                          color: AppColors.steelGrey, fontSize: 13),
                    ),
                  ),
                ],
              ),
            ],
            const SizedBox(height: 12),
            const Divider(color: AppColors.charcoal, height: 1),
            const SizedBox(height: 10),
            Row(
              children: [
                const Icon(Icons.shield_outlined,
                    size: 14, color: AppColors.steelGrey),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    '${c.verified ? 'Verified' : 'Unverified'}  •  ${c.version}  •  ${c.platforms.join(', ')}',
                    style: const TextStyle(
                        color: AppColors.steelGrey, fontSize: 12),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _VerifiedChip extends StatelessWidget {
  final bool verified;
  const _VerifiedChip({required this.verified});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: verified
            ? AppColors.neonLime.withOpacity(0.15)
            : AppColors.charcoal,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
            color: verified ? AppColors.neonLime : AppColors.steelGrey,
            width: 1),
      ),
      child: Text(
        verified ? 'VERIFIED' : 'UNVERIFIED',
        style: TextStyle(
          color: verified ? AppColors.neonLime : AppColors.steelGrey,
          fontSize: 10,
          fontWeight: FontWeight.w800,
          letterSpacing: 1,
        ),
      ),
    );
  }
}

class _CodeRow extends StatelessWidget {
  final String label;
  final String value;
  final VoidCallback onCopy;
  const _CodeRow(
      {required this.label, required this.value, required this.onCopy});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onLongPress: onCopy,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: AppColors.midnight,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.charcoal),
        ),
        child: Row(
          children: [
            SizedBox(
              width: 84,
              child: Text(label,
                  style: const TextStyle(
                      color: AppColors.steelGrey,
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1)),
            ),
            Expanded(
              child: Text(
                value,
                style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1),
              ),
            ),
            IconButton(
              visualDensity: VisualDensity.compact,
              onPressed: onCopy,
              icon: const Icon(Icons.copy, size: 18),
              tooltip: 'Copy',
            ),
          ],
        ),
      ),
    );
  }
}

class _ComboRow extends StatelessWidget {
  final String label;
  final String combo;
  final VoidCallback onCopy;
  const _ComboRow(
      {required this.label, required this.combo, required this.onCopy});

  @override
  Widget build(BuildContext context) {
    final parts = combo.split(',').map((e) => e.trim()).toList();
    return GestureDetector(
      onLongPress: onCopy,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.midnight,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.charcoal),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                SizedBox(
                  width: 84,
                  child: Text(label,
                      style: const TextStyle(
                          color: AppColors.steelGrey,
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1)),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: onCopy,
                  child: const Row(
                    children: [
                      Icon(Icons.copy, size: 16),
                      SizedBox(width: 4),
                      Text('COPY',
                          style: TextStyle(
                              fontSize: 11, fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: parts
                  .map((p) => Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: AppColors.charcoal,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(p,
                            style: const TextStyle(
                                fontWeight: FontWeight.w700, fontSize: 13)),
                      ))
                  .toList(),
            ),
          ],
        ),
      ),
    );
  }
}

class _UnavailableRow extends StatelessWidget {
  final String label;
  const _UnavailableRow({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.midnight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.charcoal),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 84,
            child: Text(label,
                style: const TextStyle(
                    color: AppColors.steelGrey,
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1)),
          ),
          const Expanded(
            child: Text(
              'Not available for this game/version.',
              style:
                  TextStyle(color: AppColors.steelGrey, fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }
}
