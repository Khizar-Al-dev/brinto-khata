import 'package:flutter/material.dart';

/// Brand palette — CHEATCODES (from the project brief).
class AppColors {
  static const Color midnight = Color(0xFF0B0D0F);
  static const Color charcoal = Color(0xFF15191D);
  static const Color cardSurface = Color(0xFF1B2025);
  static const Color neonLime = Color(0xFFB8F34A);
  static const Color white = Color(0xFFFFFFFF);
  static const Color steelGrey = Color(0xFF9299A1);
}

class AppTheme {
  static ThemeData dark() {
    const ColorScheme scheme = ColorScheme.dark(
      primary: AppColors.neonLime,
      secondary: AppColors.neonLime,
      surface: AppColors.charcoal,
      onPrimary: AppColors.midnight,
      onSurface: AppColors.white,
    );
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.midnight,
      colorScheme: scheme,
      primaryColor: AppColors.neonLime,
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.midnight,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
            color: AppColors.white,
            fontSize: 20,
            fontWeight: FontWeight.w800),
        iconTheme: IconThemeData(color: AppColors.white),
      ),
      cardTheme: CardTheme(
        color: AppColors.cardSurface,
        elevation: 0,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20)),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.charcoal,
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide:
                const BorderSide(color: AppColors.neonLime, width: 1.2)),
        hintStyle: const TextStyle(color: AppColors.steelGrey),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.neonLime,
          foregroundColor: AppColors.midnight,
          textStyle:
              const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14)),
          padding: const EdgeInsets.symmetric(vertical: 16),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.white,
          side: const BorderSide(color: AppColors.steelGrey, width: 1),
          textStyle:
              const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14)),
          padding: const EdgeInsets.symmetric(vertical: 16),
        ),
      ),
      textTheme: const TextTheme(
        displayLarge:
            TextStyle(color: AppColors.white, fontWeight: FontWeight.w900),
        headlineMedium:
            TextStyle(color: AppColors.white, fontWeight: FontWeight.w800),
        titleLarge:
            TextStyle(color: AppColors.white, fontWeight: FontWeight.w800),
        titleMedium:
            TextStyle(color: AppColors.white, fontWeight: FontWeight.w700),
        bodyLarge: TextStyle(color: AppColors.white),
        bodyMedium: TextStyle(color: AppColors.steelGrey),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.charcoal,
        selectedItemColor: AppColors.neonLime,
        unselectedItemColor: AppColors.steelGrey,
        type: BottomNavigationBarType.fixed,
        showUnselectedLabels: true,
        selectedLabelStyle: TextStyle(fontWeight: FontWeight.w700),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: AppColors.charcoal,
        selectedColor: AppColors.neonLime,
        labelStyle: const TextStyle(color: AppColors.white),
        secondaryLabelStyle: const TextStyle(color: AppColors.midnight),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20)),
      ),
      snackBarTheme: const SnackBarThemeData(
        backgroundColor: AppColors.neonLime,
        contentTextStyle: TextStyle(
            color: AppColors.midnight, fontWeight: FontWeight.w800),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(12))),
      ),
    );
  }
}
