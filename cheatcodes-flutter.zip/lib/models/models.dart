/// Core data models for CHEATCODES.

enum GameStatus { available, underReview, comingSoon }

extension GameStatusLabel on GameStatus {
  String get label {
    switch (this) {
      case GameStatus.available:
        return 'Available';
      case GameStatus.underReview:
        return 'Under Review';
      case GameStatus.comingSoon:
        return 'Coming Soon';
    }
  }
}

enum CheatCategory {
  all,
  weapons,
  healthArmor,
  vehicles,
  police,
  weather,
  character,
  gameplay,
  special,
}

extension CheatCategoryLabel on CheatCategory {
  String get label {
    switch (this) {
      case CheatCategory.all:
        return 'All Cheats';
      case CheatCategory.weapons:
        return 'Weapons';
      case CheatCategory.healthArmor:
        return 'Health & Armor';
      case CheatCategory.vehicles:
        return 'Vehicles';
      case CheatCategory.police:
        return 'Police & Wanted';
      case CheatCategory.weather:
        return 'Weather';
      case CheatCategory.character:
        return 'Character';
      case CheatCategory.gameplay:
        return 'Gameplay';
      case CheatCategory.special:
        return 'Special';
    }
  }

  static CheatCategory fromKey(String key) {
    return CheatCategory.values.firstWhere(
      (c) => c.name == key,
      orElse: () => CheatCategory.special,
    );
  }
}

class GameInfo {
  final String id;
  final String title;
  final String shortTitle;
  final int year;
  final List<String> platforms;
  final GameStatus status;
  final String tagline;
  final String? notice;
  final String? coverAsset;

  const GameInfo({
    required this.id,
    required this.title,
    required this.shortTitle,
    required this.year,
    required this.platforms,
    required this.status,
    required this.tagline,
    this.notice,
    this.coverAsset,
  });
}

class Cheat {
  final String id;
  final String gameId;
  final String name;
  final CheatCategory category;
  final String? keyboardCode;
  final String? psCombo;
  final String? xboxCombo;
  final String? otherCombo;
  final String? dpadCombo;
  final String? unlockRequirement;
  final String? phoneNumber;
  final String description;
  final bool verified;
  final String version;
  final List<String> platforms;
  final String source;

  const Cheat({
    required this.id,
    required this.gameId,
    required this.name,
    required this.category,
    this.keyboardCode,
    this.psCombo,
    this.xboxCombo,
    this.otherCombo,
    this.dpadCombo,
    this.unlockRequirement,
    this.phoneNumber,
    required this.description,
    required this.verified,
    required this.version,
    required this.platforms,
    required this.source,
  });

  factory Cheat.fromJson(Map<String, dynamic> j) {
    return Cheat(
      id: j['id'] as String,
      gameId: j['gameId'] as String,
      name: j['name'] as String,
      category: CheatCategoryLabel.fromKey(j['category'] as String? ?? 'special'),
      keyboardCode: j['keyboardCode'] as String?,
      psCombo: j['psCombo'] as String?,
      xboxCombo: j['xboxCombo'] as String?,
      otherCombo: j['otherCombo'] as String?,
      dpadCombo: j['dpadCombo'] as String?,
      unlockRequirement: j['unlockRequirement'] as String?,
      phoneNumber: j['phoneNumber'] as String?,
      description: j['description'] as String? ?? '',
      verified: j['verified'] as bool? ?? false,
      version: j['version'] as String? ?? '',
      platforms: (j['platforms'] as List<dynamic>? ?? [])
          .map((e) => e.toString())
          .toList(),
      source: j['source'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'gameId': gameId,
        'name': name,
        'category': category.name,
        'keyboardCode': keyboardCode,
        'psCombo': psCombo,
        'xboxCombo': xboxCombo,
        'otherCombo': otherCombo,
        'dpadCombo': dpadCombo,
        'unlockRequirement': unlockRequirement,
        'phoneNumber': phoneNumber,
        'description': description,
        'verified': verified,
        'version': version,
        'platforms': platforms,
        'source': source,
      };

  /// Plain-text form used when the user copies a combo (e.g. long-press).
  String get psCopyText => psCombo ?? '';
  String get xboxCopyText => xboxCombo ?? '';
  String get dpadCopyText => dpadCombo ?? '';
}
