import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../theme/app_theme.dart';
import '../utils/routes.dart';
import '../widgets/animated_background.dart';
import '../widgets/logo.dart';
import 'welcome_screen.dart';

/// Animated splash: logo scales + fades in over the particle background,
/// then glides to the welcome screen.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 2200), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          AppRoutes.fade(const WelcomeScreen()),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.midnight,
      body: Stack(
        fit: StackFit.expand,
        children: [
          const ParticleBackground(),
          Center(
            child: const CheatCodesLogo(badgeSize: 110)
                .animate()
                .scale(
                  begin: const Offset(0.7, 0.7),
                  end: const Offset(1, 1),
                  duration: 700.ms,
                  curve: Curves.easeOutBack,
                )
                .fadeIn(duration: 600.ms),
          ),
          Positioned(
            bottom: 48,
            left: 0,
            right: 0,
            child: const SizedBox(
              width: 22,
              height: 22,
              child: Center(
                child: CircularProgressIndicator(
                  color: AppColors.neonLime,
                  strokeWidth: 2.5,
                ),
              ),
            ).animate().fadeIn(delay: 500.ms, duration: 500.ms),
          ),
        ],
      ),
    );
  }
}
