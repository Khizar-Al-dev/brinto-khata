import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../data/cheat_repository.dart';
import '../models/models.dart';
import '../services/auth_service.dart';
import '../theme/app_theme.dart';
import '../widgets/cheat_card.dart';

/// One game's profile: cover, platforms, verified count, in-game search,
/// category chips that instantly filter the cheat list.
/// GTA VI shows "CHEAT CODES COMING SOON" + Notify Me — no fake codes.
class GameDetailScreen extends StatefulWidget {
  final GameInfo game;
  const GameDetailScreen({super.key, required this.game});

  @override
  State<GameDetailScreen> createState() => _GameDetailScreenState();
}

class _GameDetailScreenState extends State<GameDetailScreen> {
  final _repo = CheatRepository.instance;
  CheatCategory _category = CheatCategory.all;
  String _query = '';
  bool _notifyMe = false;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _repo.load().then((_) {
      if (mounted) setState(() => _loaded = true);
    });
    SharedPreferences.getInstance().then((p) {
      if (mounted) {
        setState(
            () => _notifyMe = p.getBool('cc_notify_gta6') ?? false);
      }
    });
  }

  List<Cheat> get _filtered {
    var list = _repo.forGame(widget.game.id, category: _category);
    final q = _query.trim().toLowerCase();
    if (q.isNotEmpty) {
      list = list.where((c) {
        final hay = [
          c.name,
          c.keyboardCode ?? '',
          c.psCombo ?? '',
          c.xboxCombo ?? '',
          c.phoneNumber ?? '',
          c.description,
        ].join(' ').toLowerCase();
        return hay.contains(q);
      }).toList();
    }
    return list;
  }

  Future<void> _toggleNotify() async {
    final isUser = await AuthService().isLoggedIn;
    if (!isUser) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text(
                  'Notify Me ke liye login zaroori hai — Guest mode mein available nahi.')),
        );
      }
      return;
    }
    final p = await SharedPreferences.getInstance();
    final next = !_notifyMe;
    await p.setBool('cc_notify_gta6', next);
    if (mounted) {
      setState(() => _notifyMe = next);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(next
                ? 'Done! GTA VI cheats aate hi aap ko notify karenge.'
                : 'Notify Me band kar diya.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final game = widget.game;
    final comingSoon = game.status == GameStatus.comingSoon;
    final count = _repo.countForGame(game.id);
    final cheats = _filtered;

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 220,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(game.title,
                  style: const TextStyle(fontWeight: FontWeight.w900)),
              background: Hero(
                tag: 'game-cover-${game.id}',
                child: game.coverAsset != null
                    ? Image.asset(
                        game.coverAsset!,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) =>
                            const SizedBox.shrink(),
                      )
                    : Container(
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [Color(0xFF2E4A12), AppColors.midnight],
                          ),
                        ),
                        child: Center(
                          child: Text(
                            game.shortTitle,
                            style: TextStyle(
                              fontSize: 96,
                              fontWeight: FontWeight.w900,
                              color: AppColors.white.withOpacity(0.9),
                            ),
                          ),
                        ),
                      ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(game.tagline,
                      style: const TextStyle(
                          color: AppColors.steelGrey, height: 1.5)),
                  const SizedBox(height: 10),
                  Text(game.platforms.join('  •  '),
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  Text(
                    comingSoon
                        ? 'Verified cheats: Coming Soon'
                        : '$count verified cheat codes',
                    style: const TextStyle(color: AppColors.neonLime),
                  ),
                  if (game.notice != null) ...[
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: AppColors.charcoal,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                            color: AppColors.neonLime.withOpacity(0.4)),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.info_outline,
                              size: 18, color: AppColors.neonLime),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(game.notice!,
                                style:
                                    const TextStyle(height: 1.5)),
                          ),
                        ],
                      ),
                    ),
                  ],
                  if (comingSoon) ...[
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppColors.charcoal,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                            color: AppColors.neonLime.withOpacity(0.4)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('CHEAT CODES COMING SOON',
                              style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  color: AppColors.neonLime)),
                          const SizedBox(height: 8),
                          const Text(
                            'We are waiting for authentic and verified cheat codes. No fake codes will ever be shown here.',
                            style: TextStyle(height: 1.5),
                          ),
                          const SizedBox(height: 12),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: _toggleNotify,
                              child: Text(_notifyMe
                                  ? 'NOTIFY ME ✓  (ON)'
                                  : 'NOTIFY ME'),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                  if (!comingSoon) ...[
                    const SizedBox(height: 16),
                    TextField(
                      onChanged: (v) => setState(() => _query = v),
                      decoration: InputDecoration(
                        hintText: 'Search within ${game.title}…',
                        prefixIcon: const Icon(Icons.search),
                        suffixIcon: _query.isEmpty
                            ? null
                            : IconButton(
                                icon: const Icon(Icons.clear),
                                onPressed: () =>
                                    setState(() => _query = ''),
                              ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      height: 40,
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        children: CheatCategory.values.map((cat) {
                          final selected = _category == cat;
                          return Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: ChoiceChip(
                              label: Text(cat.label),
                              selected: selected,
                              onSelected: (_) =>
                                  setState(() => _category = cat),
                              selectedColor: AppColors.neonLime,
                              labelStyle: TextStyle(
                                color: selected
                                    ? AppColors.midnight
                                    : AppColors.white,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          if (!comingSoon)
            _loaded
                ? cheats.isEmpty
                    ? const SliverToBoxAdapter(
                        child: Padding(
                          padding: EdgeInsets.all(32),
                          child: Column(
                            children: [
                              Icon(Icons.search_off,
                                  size: 48, color: AppColors.steelGrey),
                              SizedBox(height: 12),
                              Text(
                                'Koi cheat nahi mila. Verified codes research se add ho rahe hain.',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: AppColors.steelGrey),
                              ),
                            ],
                          ),
                        ),
                      )
                    : SliverList(
                        delegate: SliverChildBuilderDelegate(
                          (context, i) => CheatCard(cheat: cheats[i]),
                          childCount: cheats.length,
                        ),
                      )
                : const SliverToBoxAdapter(
                    child: Padding(
                      padding: EdgeInsets.all(32),
                      child: Center(
                          child: CircularProgressIndicator(
                              color: AppColors.neonLime)),
                    ),
                  ),
          const SliverToBoxAdapter(child: SizedBox(height: 24)),
        ],
      ),
    );
  }
}
