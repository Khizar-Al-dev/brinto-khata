import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../data/cheat_repository.dart';
import '../data/games.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../utils/routes.dart';
import '../widgets/logo.dart';
import 'game_detail_screen.dart';

/// Home: logo + search bar + "EXPLORE GTA GAMES" + 2-column game grid.
/// Cards animate in staggered; tapping a card glides to its game profile
/// with a Hero cover transition.
class HomeScreen extends StatefulWidget {
  final VoidCallback onOpenSearch;
  const HomeScreen({super.key, required this.onOpenSearch});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _repo = CheatRepository.instance;

  @override
  void initState() {
    super.initState();
    _repo.load().then((_) {
      if (mounted) setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
                child: Row(
                  children: [
                    const LogoBadge(size: 40),
                    const SizedBox(width: 10),
                    const Text(
                      'CHEATCODES',
                      style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 18,
                          letterSpacing: 2),
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: widget.onOpenSearch,
                      icon: const Icon(Icons.search, size: 26),
                    ),
                  ],
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 6),
                child: GestureDetector(
                  onTap: widget.onOpenSearch,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 14),
                    decoration: BoxDecoration(
                      color: AppColors.charcoal,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.search, color: AppColors.steelGrey),
                        SizedBox(width: 10),
                        Text('Search cheats, games, codes…',
                            style: TextStyle(color: AppColors.steelGrey)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(20, 18, 20, 12),
                child: Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(
                        text: 'EXPLORE ',
                        style: TextStyle(
                            fontSize: 24, fontWeight: FontWeight.w900),
                      ),
                      TextSpan(
                        text: 'GTA GAMES',
                        style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w900,
                            color: AppColors.neonLime),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              sliver: SliverGrid(
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 14,
                  crossAxisSpacing: 14,
                  childAspectRatio: 0.78,
                ),
                delegate: SliverChildBuilderDelegate(
                  (context, i) {
                    final game = kGames[i];
                    final count = _repo.countForGame(game.id);
                    return _GameCard(game: game, cheatCount: count, index: i);
                  },
                  childCount: kGames.length,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

const List<List<Color>> _coverGradients = [
  [Color(0xFF2E4A12), Color(0xFF0B0D0F)],
  [Color(0xFF0E3A4A), Color(0xFF0B0D0F)],
  [Color(0xFF4A2E12), Color(0xFF0B0D0F)],
  [Color(0xFF3A2E4A), Color(0xFF0B0D0F)],
  [Color(0xFF123A2E), Color(0xFF0B0D0F)],
];

class _GameCard extends StatelessWidget {
  final GameInfo game;
  final int cheatCount;
  final int index;
  const _GameCard(
      {required this.game, required this.cheatCount, required this.index});

  @override
  Widget build(BuildContext context) {
    final gradient = _coverGradients[index % _coverGradients.length];
    final comingSoon = game.status == GameStatus.comingSoon;
    return GestureDetector(
      onTap: () => Navigator.of(context).push(
        AppRoutes.slideFade(GameDetailScreen(game: game)),
      ),
      child: Card(
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Hero(
                tag: 'game-cover-${game.id}',
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: gradient,
                    ),
                  ),
                  child: Stack(
                    children: [
                      Center(
                        child: Text(
                          game.shortTitle,
                          style: TextStyle(
                            fontSize: 54,
                            fontWeight: FontWeight.w900,
                            color: AppColors.white.withOpacity(0.92),
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                      Positioned(
                        top: 10,
                        right: 10,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: comingSoon
                                ? AppColors.neonLime
                                : AppColors.midnight.withOpacity(0.7),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            comingSoon ? 'COMING SOON' : '${game.year}',
                            style: TextStyle(
                              color: comingSoon
                                  ? AppColors.midnight
                                  : AppColors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    game.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 15),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    game.platforms.join(' • '),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        color: AppColors.steelGrey, fontSize: 12),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.bolt,
                          size: 14, color: AppColors.neonLime),
                      const SizedBox(width: 4),
                      Text(
                        comingSoon
                            ? 'Cheats coming soon'
                            : '$cheatCount verified cheats',
                        style: const TextStyle(
                            fontSize: 12, fontWeight: FontWeight.w700),
                      ),
                      const Spacer(),
                      const Icon(Icons.arrow_forward,
                          size: 16, color: AppColors.neonLime),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    )
        .animate()
        .fadeIn(delay: (index * 60).ms, duration: 400.ms)
        .slideY(begin: 0.12, end: 0, duration: 400.ms,
            curve: Curves.easeOutCubic);
  }
}
