import 'dart:async';
import 'package:flutter/material.dart';
import '../data/cheat_repository.dart';
import '../models/models.dart';
import '../services/favorites_store.dart';
import '../theme/app_theme.dart';
import '../widgets/cheat_card.dart';

/// Global smart search: names, codes, combos, phone numbers, descriptions,
/// categories, platforms and game titles — with recent searches, suggestions
/// and a no-results state.
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _repo = CheatRepository.instance;
  final _ctrl = TextEditingController();
  Timer? _debounce;
  List<Cheat> _results = [];
  List<String> _recent = [];
  bool _searched = false;

  @override
  void initState() {
    super.initState();
    _repo.load();
    RecentSearches.load().then((r) {
      if (mounted) setState(() => _recent = r);
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _ctrl.dispose();
    super.dispose();
  }

  void _onQuery(String q) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 250), () {
      final results = _repo.search(q);
      setState(() {
        _results = results;
        _searched = q.trim().isNotEmpty;
      });
      if (q.trim().isNotEmpty) {
        RecentSearches.add(q).then((_) => RecentSearches.load().then((r) {
              if (mounted) setState(() => _recent = r);
            }));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('SEARCH CHEATS')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _ctrl,
              onChanged: _onQuery,
              decoration: InputDecoration(
                hintText: 'Try "Tank", "Weapons", "PAINKILLER"…',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _ctrl.text.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _ctrl.clear();
                          setState(() {
                            _results = [];
                            _searched = false;
                          });
                        },
                      ),
              ),
            ),
          ),
          if (!_searched) ...[
            if (_recent.isNotEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    const Text('RECENT SEARCHES',
                        style: TextStyle(
                            fontWeight: FontWeight.w800,
                            color: AppColors.steelGrey,
                            fontSize: 12)),
                    const Spacer(),
                    GestureDetector(
                      onTap: () async {
                        await RecentSearches.clear();
                        setState(() => _recent = []);
                      },
                      child: const Text('Clear',
                          style: TextStyle(color: AppColors.neonLime)),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: _recent
                    .map((r) => ListTile(
                          leading: const Icon(Icons.history,
                              color: AppColors.steelGrey),
                          title: Text(r),
                          onTap: () {
                            _ctrl.text = r;
                            _onQuery(r);
                          },
                        ))
                    .toList(),
              ),
            ),
          ] else
            Expanded(
              child: _results.isEmpty
                  ? const Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.search_off,
                              size: 48, color: AppColors.steelGrey),
                          SizedBox(height: 12),
                          Text('No cheats found.',
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700)),
                          SizedBox(height: 6),
                          Text(
                            'Try another name, code or game.',
                            style:
                                TextStyle(color: AppColors.steelGrey),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      itemCount: _results.length,
                      itemBuilder: (context, i) =>
                          CheatCard(cheat: _results[i], showGame: true),
                    ),
            ),
        ],
      ),
    );
  }
}
