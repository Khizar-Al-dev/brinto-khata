import 'package:flutter/material.dart';
import '../data/cheat_repository.dart';
import '../models/models.dart';
import '../services/favorites_store.dart';
import '../theme/app_theme.dart';
import '../widgets/cheat_card.dart';

/// Saved favorite cheats (stored locally, works offline).
class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  final _repo = CheatRepository.instance;
  List<Cheat> _favs = [];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    await _repo.load();
    final ids = await FavoritesStore.load();
    if (mounted) {
      setState(() {
        _favs =
            _repo.all.where((c) => ids.contains(c.id)).toList();
        _loaded = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('FAVORITES')),
      body: !_loaded
          ? const Center(
              child: CircularProgressIndicator(color: AppColors.neonLime))
          : _favs.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(32),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.favorite_border,
                            size: 48, color: AppColors.steelGrey),
                        SizedBox(height: 12),
                        Text('No favorites yet.',
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w700)),
                        SizedBox(height: 6),
                        Text(
                          'Tap the heart on any cheat card to save it here.',
                          textAlign: TextAlign.center,
                          style:
                              TextStyle(color: AppColors.steelGrey),
                        ),
                      ],
                    ),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _refresh,
                  color: AppColors.neonLime,
                  child: ListView.builder(
                    itemCount: _favs.length,
                    itemBuilder: (context, i) =>
                        CheatCard(cheat: _favs[i], showGame: true),
                  ),
                ),
    );
  }
}
