import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../services/auth_service.dart';
import '../theme/app_theme.dart';
import '../utils/routes.dart';
import '../widgets/animated_background.dart';
import '../widgets/logo.dart';
import 'auth_screen.dart';
import 'main_shell.dart';

/// First-run entrance: logo + subtitle over the animated background,
/// then Login / Sign Up / Guest + Google Sign-In. Never opens the library
/// directly.
class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  Future<void> _continueAsGuest(BuildContext context) async {
    await AuthService().signInAsGuest();
    if (context.mounted) {
      Navigator.of(context).pushReplacement(
        AppRoutes.fade(const MainShell()),
      );
    }
  }

  Future<void> _google(BuildContext context) async {
    try {
      await AuthService().signInWithGoogle();
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString())),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.midnight,
      body: Stack(
        fit: StackFit.expand,
        children: [
          const ParticleBackground(),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                children: [
                  const Spacer(flex: 2),
                  const CheatCodesLogo()
                      .animate()
                      .fadeIn(duration: 600.ms)
                      .slideY(begin: -0.12, end: 0, duration: 600.ms,
                          curve: Curves.easeOutCubic),
                  const SizedBox(height: 14),
                  const Text(
                    'Every verified cheat. Every GTA.\nOne app.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: AppColors.steelGrey, fontSize: 15, height: 1.5),
                  ).animate().fadeIn(delay: 200.ms, duration: 500.ms),
                  const Spacer(flex: 3),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => Navigator.of(context).push(
                        AppRoutes.slideFade(const AuthScreen(startLogin: true)),
                      ),
                      child: const Text('LOGIN'),
                    ),
                  ).animate().fadeIn(delay: 300.ms).slideY(begin: 0.15, end: 0),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: AppColors.neonLime),
                        foregroundColor: AppColors.neonLime,
                      ),
                      onPressed: () => Navigator.of(context).push(
                        AppRoutes.slideFade(const AuthScreen(startLogin: false)),
                      ),
                      child: const Text('SIGN UP / CONTINUE WITH EMAIL'),
                    ),
                  ).animate().fadeIn(delay: 400.ms).slideY(begin: 0.15, end: 0),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: TextButton(
                      onPressed: () => _continueAsGuest(context),
                      child: const Text(
                        'CONTINUE AS GUEST',
                        style: TextStyle(
                            color: AppColors.white,
                            fontWeight: FontWeight.w800),
                      ),
                    ),
                  ).animate().fadeIn(delay: 500.ms),
                  const SizedBox(height: 16),
                  const Row(
                    children: [
                      Expanded(child: Divider(color: AppColors.charcoal)),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 12),
                        child: Text('OR',
                            style: TextStyle(
                                color: AppColors.steelGrey,
                                fontSize: 12,
                                fontWeight: FontWeight.w700)),
                      ),
                      Expanded(child: Divider(color: AppColors.charcoal)),
                    ],
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () => _google(context),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 22,
                            height: 22,
                            decoration: const BoxDecoration(
                              color: AppColors.white,
                              shape: BoxShape.circle,
                            ),
                            child: const Center(
                              child: Text('G',
                                  style: TextStyle(
                                      color: AppColors.midnight,
                                      fontWeight: FontWeight.w900,
                                      fontSize: 14)),
                            ),
                          ),
                          const SizedBox(width: 10),
                          const Text('CONTINUE WITH GOOGLE'),
                        ],
                      ),
                    ),
                  ).animate().fadeIn(delay: 600.ms).slideY(begin: 0.15, end: 0),
                  const SizedBox(height: 28),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
