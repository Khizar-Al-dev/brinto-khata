import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../theme/app_theme.dart';
import '../utils/routes.dart';
import 'welcome_screen.dart';

/// Profile: account, membership, settings, logout.
/// Pro membership + Google Play Billing arrive in Phase 7 — the Pro card
/// below is clearly labelled as coming soon, never a fake purchase.
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  String? _name;
  String? _email;
  bool _guest = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final auth = AuthService();
    final guest = await auth.isGuest;
    final name = await auth.displayName;
    final email = await auth.email;
    if (mounted) {
      setState(() {
        _guest = guest;
        _name = name;
        _email = email;
      });
    }
  }

  Future<void> _logout() async {
    await AuthService().signOut();
    if (mounted) {
      Navigator.of(context).pushAndRemoveUntil(
        AppRoutes.fade(const WelcomeScreen()),
        (_) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final displayName = _guest ? 'Guest Player' : (_name ?? 'Player');
    final initial = displayName.isNotEmpty
        ? displayName[0].toUpperCase()
        : 'G';
    return Scaffold(
      appBar: AppBar(title: const Text('PROFILE')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 32,
                backgroundColor: AppColors.neonLime,
                child: Text(initial,
                    style: const TextStyle(
                        color: AppColors.midnight,
                        fontSize: 28,
                        fontWeight: FontWeight.w900)),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(displayName,
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.w800)),
                    Text(_guest ? 'Guest account' : (_email ?? ''),
                        style: const TextStyle(color: AppColors.steelGrey)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text('FREE PLAN',
                          style: TextStyle(
                              fontWeight: FontWeight.w900,
                              color: AppColors.neonLime)),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppColors.neonLime.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Text('ACTIVE',
                            style: TextStyle(
                                color: AppColors.neonLime,
                                fontSize: 11,
                                fontWeight: FontWeight.w800)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Public cheat database, basic search and favorites.',
                    style: TextStyle(color: AppColors.steelGrey),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('CHEATCODES PRO',
                      style: TextStyle(fontWeight: FontWeight.w900)),
                  const SizedBox(height: 8),
                  const Text(
                    'Ad-free, unlimited favorites, offline database, premium themes, advanced filters, personal collections.',
                    style: TextStyle(
                        color: AppColors.steelGrey, height: 1.5),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                              content: Text(
                                  'Pro membership Phase 7 mein Google Play Billing se aayega.')),
                        );
                      },
                      child: const Text('UPGRADE TO PRO — COMING SOON'),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          ListTile(
            leading: const Icon(Icons.download_outlined),
            title: const Text('Offline database'),
            subtitle: const Text('Cheats are bundled in the app — no internet needed to read them.'),
          ),
          const Divider(color: AppColors.charcoal),
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('About CHEATCODES'),
            subtitle: const Text('Version 1.0.0 — verified cheats only.'),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: _logout,
              child: const Text('LOGOUT'),
            ),
          ),
        ],
      ),
    );
  }
}
