import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../services/auth_service.dart';
import '../theme/app_theme.dart';
import '../utils/routes.dart';
import '../widgets/animated_background.dart';
import '../widgets/logo.dart';
import 'main_shell.dart';

/// Login + Sign Up with full validation and independent password-visibility
/// toggles. Email/Google auth is wired to Supabase in Phase 2 — until then
/// the screen is honest about it and Guest mode is one tap away.
class AuthScreen extends StatefulWidget {
  final bool startLogin;
  const AuthScreen({super.key, required this.startLogin});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  late bool _isLogin;
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();
  bool _showPass = false;
  bool _showConfirm = false;
  bool _loading = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _isLogin = widget.startLogin;
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _passCtrl.dispose();
    _confirmCtrl.dispose();
    super.dispose();
  }

  String? _emailValidator(String? v) {
    if (v == null || v.trim().isEmpty) return 'Email zaroori hai';
    final ok = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(v.trim());
    return ok ? null : 'Sahi email format likhein';
  }

  String? _passValidator(String? v) {
    if (v == null || v.isEmpty) return 'Password zaroori hai';
    if (v.length < 8) return 'Password kam se kam 8 characters ka ho';
    return null;
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final auth = AuthService();
      if (_isLogin) {
        await auth.signInWithEmail(_emailCtrl.text.trim(), _passCtrl.text);
      } else {
        await auth.signUpWithEmail(
            _nameCtrl.text.trim(), _emailCtrl.text.trim(), _passCtrl.text);
      }
      if (mounted) {
        Navigator.of(context).pushReplacement(
          AppRoutes.fade(const MainShell()),
        );
      }
    } catch (e) {
      setState(() {
        _error = e.toString().replaceAll('UnimplementedError: ', '');
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _guest() async {
    await AuthService().signInAsGuest();
    if (mounted) {
      Navigator.of(context).pushReplacement(
        AppRoutes.fade(const MainShell()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.midnight,
      appBar: AppBar(backgroundColor: Colors.transparent),
      body: Stack(
        fit: StackFit.expand,
        children: [
          const ParticleBackground(),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Center(child: LogoBadge(size: 64)),
                    const SizedBox(height: 20),
                    Text(
                      _isLogin ? 'WELCOME BACK' : 'CREATE ACCOUNT',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                          fontSize: 24, fontWeight: FontWeight.w900),
                    ).animate().fadeIn(duration: 400.ms),
                    const SizedBox(height: 6),
                    Text(
                      _isLogin
                          ? 'Login karke apne favorites aur collections sync karein'
                          : 'Free account banayein — favorites aur sync ke liye',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: AppColors.steelGrey),
                    ),
                    const SizedBox(height: 28),
                    if (!_isLogin)
                      TextFormField(
                        controller: _nameCtrl,
                        textCapitalization: TextCapitalization.words,
                        decoration:
                            const InputDecoration(hintText: 'Full name'),
                        validator: (v) => (v == null || v.trim().isEmpty)
                            ? 'Naam zaroori hai'
                            : null,
                      ),
                    if (!_isLogin) const SizedBox(height: 14),
                    TextFormField(
                      controller: _emailCtrl,
                      keyboardType: TextInputType.emailAddress,
                      decoration:
                          const InputDecoration(hintText: 'Email address'),
                      validator: _emailValidator,
                    ),
                    const SizedBox(height: 14),
                    TextFormField(
                      controller: _passCtrl,
                      obscureText: !_showPass,
                      decoration: InputDecoration(
                        hintText: 'Password',
                        suffixIcon: IconButton(
                          icon: Icon(_showPass
                              ? Icons.visibility
                              : Icons.visibility_off),
                          onPressed: () =>
                              setState(() => _showPass = !_showPass),
                        ),
                      ),
                      validator: _passValidator,
                    ),
                    if (!_isLogin) ...[
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: _confirmCtrl,
                        obscureText: !_showConfirm,
                        decoration: InputDecoration(
                          hintText: 'Confirm password',
                          suffixIcon: IconButton(
                            icon: Icon(_showConfirm
                                ? Icons.visibility
                                : Icons.visibility_off),
                            onPressed: () => setState(
                                () => _showConfirm = !_showConfirm),
                          ),
                        ),
                        validator: (v) => v != _passCtrl.text
                            ? 'Passwords match nahi kar rahe'
                            : null,
                      ),
                    ],
                    if (_isLogin)
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          onPressed: () async {
                            try {
                              await AuthService()
                                  .resetPassword(_emailCtrl.text.trim());
                            } catch (e) {
                              if (mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                      content: Text(e
                                          .toString()
                                          .replaceAll(
                                              'UnimplementedError: ', ''))),
                                );
                              }
                            }
                          },
                          child: const Text('Forgot Password?',
                              style: TextStyle(color: AppColors.neonLime)),
                        ),
                      ),
                    const SizedBox(height: 8),
                    if (_error != null)
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFF3A1D1D),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(_error!,
                            style: const TextStyle(color: Color(0xFFFF9A9A))),
                      ),
                    if (_error != null) const SizedBox(height: 12),
                    ElevatedButton(
                      onPressed: _loading ? null : _submit,
                      child: _loading
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                  color: AppColors.midnight, strokeWidth: 2.5))
                          : Text(_isLogin ? 'LOGIN' : 'CREATE ACCOUNT'),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          _isLogin
                              ? 'Account nahi hai? '
                              : 'Pehle se account hai? ',
                          style:
                              const TextStyle(color: AppColors.steelGrey),
                        ),
                        GestureDetector(
                          onTap: () => setState(() {
                            _isLogin = !_isLogin;
                            _error = null;
                          }),
                          child: Text(
                            _isLogin ? 'Sign Up' : 'Login',
                            style: const TextStyle(
                                color: AppColors.neonLime,
                                fontWeight: FontWeight.w800),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    TextButton(
                      onPressed: _guest,
                      child: const Text('Continue as Guest',
                          style: TextStyle(color: AppColors.white)),
                    ),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
